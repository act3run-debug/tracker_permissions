import os
import re
import json
import time
import datetime
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
from concurrent.futures import ThreadPoolExecutor
import urllib.request
import urllib.error
import urllib.parse

# ---------- НАСТРОЙКИ ----------
EMAILS = emails = [
    "azat.osmanov@astrazeneca.com",
    "serkebay.abdikadyrov@astrazeneca.com",
    "aleksei.volosenkov@astrazeneca.com",
    "mikhail@agn-agency.ru",
    "xxialpxxzagrebelnaya@yandex.ru",
    "markova.alyona.v@yandex.com"
]

PAGE = "https://tracker.yandex.ru/admin/users"
SOURCE = "Полный"
TARGET = "Чтение"
CHROME_EXE = r"C:\chrome-win\chrome-win\chrome.exe"
PROFILE_DIR = r"C:\Users\vrtxp3\.tracker-profile"
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downgrade_log.txt")

# Таймауты UI. Снятие Cloud-групп -> разблокировка combobox — асинхронный цикл,
# поэтому для него предусмотрен отдельный бинджевый опрос (PROPAGATION_TIMEOUT),
# а не эти «плоские» окна (Issue 2).
TIMEOUT_AUTH = 15000
TIMEOUT_SEARCH = 5000   # 5 сек на поиск юзера
TIMEOUT_UI = 3000       # 3 сек на открытие dropdown
TIMEOUT_RESULT = 5000   # 5 сек на проверку результата

# Issue 1/2: max. время ожидания синхронизации снятия члена группы (updateMembers
# вернёт done:false) и разблокировки combobox. Backoff-опрос, а не фиксированное окно.
# По требованию ТЗ (п.4.1 «ни одна задержка дольше 15 сек») лимит снижен до 15 с.
# Все sleep()/wait_for_timeout() в циклах не превышают 3 с (backoff capped @3с,
# интервал 1с); 15 с — это deadline backoff-опроса асинхронного распространения,
# а не блокирующая задержка.
PROPAGATION_TIMEOUT = 15000   # 15 с (лимит ТЗ п.4.1): deadline backoff-опроса разблокировки
# --------------------------------


# ========================================
# Cloud Organization / Tracker API (item 3)
# ========================================
# IAM-ткен и id организации заданы прямо в коде ради удобства — их больше не надо
# копировать из credentials/*. Cloud Org API (organization-manager) принимает ONLY
# IAM-ткен; OAuth здесь возвращает 401 UNAUTHENTICATED.

IAM_TOKEN = "t1.9euelZqRnpLJiZbHisyVzZKSlImXjO3rnpWaiYzNmcvLm5ePi5nPy5uQjJDl8_dSZEsq-e8SSxRI_t3z9xITSSr57xJLFEj-1eL17Iac0ZCeiouX0Y-KnZOWnNKMm5Tt-ZCPmpGWm83n9euelZrKyZueyomPmZfKjJ2XnJ3Mle_8xeuelZrKyZueyomPmZfKjJ2XnJ3Mlb3rnpWanpCUjpqRzo7LncuZyI3Hms-164ac0ZaektGQj5qRlpvSjJqNiZqN.gutDDyFMhXl7axqG-i71QVaem_zvgkt__2bRwW7HP9dQ4KLA1dIwhdl7WJ1G2_forf2uvnBxRoezWKBNlc_7AA"

ORG_ID = "bpfb300ct6ef4t2kr3l1"

# OAuth-ткен (Tracker) остаётся в credentials/* — нужен только для запросов к api.tracker.yandex.net.
CRED_TRACKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "credentials", "tracker_and_wiki_api.md")


def _read_cred(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        print(f"Ошибка чтения {path}: {e}")
        return ""


_OAUTH = None
_m = re.search(r'token:\s*"([A-Za-z0-9_\-\.]+)"', _read_cred(CRED_TRACKER))
if _m:
    _OAUTH = _m.group(1)


def _tracker_headers():
    # OAuth для api.tracker.yandex.net: Cloud Org этот токен не принимает (401 UNAUTHENTICATED).
    return {
        "Authorization": f"Bearer {_OAUTH}",
        "Content-Type": "application/json",
        "X-Cloud-Org-Id": ORG_ID,
    }


def _cloud_headers():
    # IAM-ткен + org id: только IAM-ткен авторизует запросы к organization-manager.api.cloud.yandex.net.
    return {
        "Authorization": f"Bearer {IAM_TOKEN}",
        "Content-Type": "application/json",
        "X-Cloud-Org-Id": ORG_ID,
    }


def _http_json(method, url, headers=None, body=None, timeout=30, return_headers=False):
    """GET/POST через stdlib urllib (requests не гарантирован).

    Возвращает (status, text); при return_headers=True — третий элемент со
    служебными заголовками (HTTPMessage; .get() без учёта регистра) — для
    пагинации через X-Total-Pages/X-Total-Count (Issue 1)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode("utf-8", errors="replace")
            if return_headers:
                return resp.status, text, resp.headers
            return resp.status, text
    except urllib.error.HTTPError as e:
        try:
            text = e.read().decode("utf-8", errors="replace")
            if return_headers:
                return e.code, text, e.headers
            return e.code, text
        except Exception:
            return e.code, ""
    except Exception as e:
        if return_headers:
            return 0, str(e), {}
        return 0, str(e)


CLOUD_BASE = "https://organization-manager.api.cloud.yandex.net/organization-manager/v1"
TRACKER_BASE = "https://api.tracker.yandex.net/v3"
OPERATION_BASE = "https://operation.api.cloud.yandex.net/operations"

# Корпоративные домены, где Cloud Identity существует по ПОЛНОМУ email-адресу.
# resolve_cloud_uid должен получить полный email (не локальную часть) для таких юзеров.
CORP_DOMAINS = ("astrazeneca.com", "astrazeneca.ru", "alexion.com")


def _resolve_cloud_login(email):
    """Каким значением передать resolve_cloud_uid для корпоративных юзеров (item 3).

    Корпоративные Cloud Identity существуют по ПОЛНОМУ email-адресу: для anna.berlova@astrazeneca.com
    Cloud Org требует 'anna.berlova@astrazeneca.com', локальная часть 'anna.berlova' -> 404.
    Для некорпоративных юзеров (например, *.com) локальная часть без домена остаётся login-ом.

    Возвращает:
      - полный email, если домен из CORP_DOMAINS (с точным совпадением либо суффиксом '.домен');
      - локальную часть (до первого '@'), иначе.
    """
    if not email or "@" not in email:
        return email
    local, _, domain = email.partition("@")
    domain = domain.lower().rstrip("/")
    for cp in CORP_DOMAINS:
        cp = cp.lower().rstrip("/")
        if domain == cp or domain.endswith("." + cp):
            return email.lower()
    return local


def resolve_cloud_uid(login):
    """Tracker GET /v3/users/<login_or_id> -> cloudUid (Yandex Identity Hub account id)."""
    url = f"{TRACKER_BASE}/users/{urllib.parse.quote(login, safe='')}"
    status, raw = _http_json("GET", url, headers=_tracker_headers())
    if status != 200:
        log(f"  [item3] resolve_cloud_uid: {status} login={login}")
        return None
    try:
        return json.loads(raw).get("cloudUid")
    except Exception:
        return None


def cloud_list_groups(subject_id, page_size=200):
    """Cloud Org GET groups:listEffective -> [{'id', 'name'}]. subject_id == cloudUid.

    Реальный ответэндпоинта:
        {"groupMembershipInfo":[{"groupId","groupName"}, ...]}
    (НЕ {"groups":[{"id","name"}]}).

    organizationId задаётся явно: для участников из нескольких org Cloud Org без него
    возвращает 400 "Organization must be specified for subject '<uid>'".
    """
    groups, page_token, page = [], None, 0
    while True:
        params = ["subjectId=" + urllib.parse.quote(subject_id), "pageSize=" + str(page_size), "organizationId=" + ORG_ID]
        if page_token:
            params.append("pageToken=" + urllib.parse.quote(page_token))
        url = f"{CLOUD_BASE}/groups:listEffective?" + "&".join(params)
        status, raw = _http_json("GET", url, headers=_cloud_headers())
        if status != 200:
            log(f"  [item3] listEffective: {status}")
            return groups
        try:
            data = json.loads(raw)
        except Exception:
            return groups
        for m in data.get("groupMembershipInfo", []):
            gid = m.get("groupId")
            if gid:
                groups.append({"id": gid, "name": m.get("groupName", "")})
        page_token = data.get("nextPageToken")
        page += 1
        if not page_token or page > 20:
            break
    return groups


def cloud_remove_member(group_id, subject_id, timeout_ms=PROPAGATION_TIMEOUT, interval_ms=1000):
    """Cloud Org POST groups/{groupId}:updateMembers -> REMOVE member. Returns (ok, detail).

    The response is always an async Operation with `id`; we poll it to completion
    before returning (Issue 3). `error` in the operation body is authoritative and
    wins even when `done == false`.
    """
    if not group_id:
        return (False, "empty group id")
    url = f"{CLOUD_BASE}/groups/{urllib.parse.quote(group_id, safe='')}:updateMembers"
    body = {"memberDeltas": [{"action": "REMOVE", "subjectId": subject_id}]}
    status, raw = _http_json("POST", url, headers=_cloud_headers(), body=body)
    if status not in (200, 201, 202):
        return (False, f"{status} {raw[:200]}".strip())
    try:
        op_id = json.loads(raw).get("id")
    except Exception:
        op_id = None
    if not op_id:
        return (True, f"{status} (no-op)")
    ok, detail = _poll_operation(op_id, timeout_ms, interval_ms,
                                 f"remove_subject/{subject_id} from group {group_id}")
    return (ok, f"{status} op={op_id} {detail}")


def _poll_operation(op_id, timeout_ms=PROPAGATION_TIMEOUT, interval_ms=1000, label=""):
    """GET operation until done != false (Issues 1 & 3).

    The `error` field is authoritative: it may be set while `done == false`, so it
    wins. Retries on 429/5xx and transient (status==0) failures from _http_json.
    Returns (ok, detail).
    """
    deadline = time.time() + timeout_ms / 1000.0
    attempts = 0
    last_error = None
    while True:
        attempts += 1
        status, raw = _http_json("GET", f"{OPERATION_BASE}/{op_id}", headers=_cloud_headers(), timeout=TIMEOUT_SEARCH)
        if status == 200:
            try:
                body = json.loads(raw)
            except Exception:
                body = {}
            if body.get("error"):
                return (False, f"operation error: {body.get('error')}")
            if body.get("done", False):
                return (True, f"done after {attempts} poll(s)")
        elif status == 429 or 500 <= status < 600 or status == 0:
            last_error = f"HTTP {status or '0'} (retry)"
        else:
            last_error = f"HTTP {status}"
        if time.time() > deadline:
            return (False, f"timeout after ~{timeout_ms}ms ({attempts} polls), last: {last_error}")
        time.sleep(interval_ms / 1000.0)


# ---------- Issue 4: привязка Cloud-групп к очередям Трекера ----------

# Секции ACL очереди Трекера (в ответе — со строчных букв), дающие право редактирования.
_TRACKER_GROUPS_WITH_WRITE = ("create", "write", "grant")


def _group_key(name):
    """Ключ группы для привязки Cloud <-> Tracker: нормализуем и берём первый токен.

    Сопоставляет имя Cloud-группы (напр. "tracker-digital-academy") с display-именем группы
    Трекера (напр. "tracker-digital-academy Рук - Бибкевит Дмитрий, (...)"). Убираем разделитель
    "|", сворачиваем пробелы, берём первую «связанную» подстроку."""
    if not name:
        return ""
    normalized = re.sub(r"\s+", " ", re.sub(r"\|+", " ", str(name))).strip()
    return normalized.split(" ", 1)[0] if normalized else ""


def _scan_single_queue(qid, headers, timeout):
    """ACL одной очереди Трекера -> (write_keys, bound_keys). Изолирован для потока.

    Возвращает пустые наборы при недоступности очереди или ошибке — не ломает
    параллельный запуск в остальных потоках (Issue 3)."""
    wk, bk = set(), set()
    url = (TRACKER_BASE + "/queues/" + urllib.parse.quote(str(qid), safe="")
           + "/permissions?expand=group")
    s2, r2 = _http_json("GET", url, headers=headers, timeout=timeout)
    if s2 != 200:
        return wk, bk
    try:
        perms = json.loads(r2)
    except Exception:
        return wk, bk
    if not isinstance(perms, dict):
        return wk, bk
    for section_name, section in perms.items():
        if not isinstance(section, dict):
            continue
        for grp in section.get("groups", []):
            k = _group_key(grp.get("display"))
            if not k:
                continue
            bk.add(k)
            if section_name in _TRACKER_GROUPS_WITH_WRITE:
                wk.add(k)
    return wk, bk


def tracker_groups_scan():
    """Один проход по очередям Трекера. Возвращает (write_keys, bound_keys) — наборы ключей
    Cloud-групп (по _group_key):
      - write_keys: группы с правом create/write/grant в хоть одной очереди Трекера;
      - bound_keys: группы, встречающиеся в ACL хоть одной очереди Трекера.

    ACL очереди: GET /v3/queues/<id>/permissions?expand=group.
    Секции ACL (create, read, write, grant, deny) — в КОРНЕ ответа (без обёртки
    `permissions`); в каждой — list объектов групп по `id`/`display`.
    Секции в ответе — со строчных букв (create, write, ...).

    Issue 1: нумерация очередей пагинирована (/queues?page=N&perPage=50, X-Total-Pages).
    Issue 3: per-queue permission-вызовы выполняться параллельно (ThreadPoolExecutor).
    """
    write_keys, bound_keys = set(), set()
    headers = _tracker_headers()

    # Issue 1: пагинация /v3/queues — проходим ВСЕ страницы, а не только первую.
    all_queues, page, total_pages = [], 0, None
    while True:
        page += 1
        status, raw, hdrs = _http_json(
            "GET", f"{TRACKER_BASE}/queues?page={page}&perPage=50",
            headers=headers, timeout=15, return_headers=True)
        if status != 200:
            log(f"  [item3] tracker_groups_scan: /v3/queues p{page} -> {status}")
            break
        try:
            batch = json.loads(raw)
        except Exception:
            break
        if not batch:
            break
        all_queues.extend(batch)
        total_pages = int(hdrs.get("X-Total-Pages", page)) if hdrs else page
        if page >= total_pages:
            break

    qids = [q.get("id") for q in all_queues if q.get("id")]
    if not qids:
        log("  [item3] tracker_groups_scan: write=0 bound=0 (очередей нет)")
        return write_keys, bound_keys

    # Issue 3: параллельная обработка ACL очередей — в пределах budget 15 сек.
    # ex.map уже возвращает результаты в порядке qids, каждый — (write_keys, bound_keys).
    max_workers = max(4, min(16, (os.cpu_count() or 4)))
    try:
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            for qwq, bq in ex.map(lambda qid: _scan_single_queue(qid, headers, 15), qids):
                write_keys |= qwq
                bound_keys |= bq
    except Exception as e:
        log(f"  [item3] tracker_groups_scan: parallel scan error — {e}")
    log(f"  [item3] tracker_groups_scan: write={len(write_keys)} bound={len(bound_keys)}")
    return write_keys, bound_keys


def cloud_groups_granting_tracker_access(groups, write_keys):
    """Фаза A: группы, чьё имя (по _group_key) привязано к очередям Трекера с create/edit.

    Если активных групп с правом create/edit нет (например, 403 на всех очередях) — [],
    чтобы снятие не применялось вслепую (безопасное поведение по spec)."""
    if not write_keys:
        log("  [item3] нет активных групп Трекера с create/edit — снятие Cloud-групп отменено")
        return []
    return [g for g in groups if _group_key(g.get("name")) in write_keys]


def cloud_groups_bound_to_queue(groups, bound_keys):
    """Фаза B: группы, привязанные к хоть одной очереди Трекера (любое право из ACL)."""
    if not bound_keys:
        return groups
    return [g for g in groups if _group_key(g.get("name")) in bound_keys]


# ---------- UI-вспомогатели (item 3 + переиспользование step 4) ----------

def _row_for_email(page, email):
    return page.locator('tr').filter(has_text=email).first


def _combobox(page, email):
    return _row_for_email(page, email).locator('button[role="combobox"]').first


def _combobox_locked(page, email):
    """Истина, если бокс прав есть, но он неактивен (нельзя понизить -> юзер в группах)."""
    access = _combobox(page, email)
    # 1) надёжный сигнал — элемент отключён
    try:
        if access.is_enabled(timeout=100):
            return False
    except Exception:
        pass
    # 2) корроборация aria-disabled
    try:
        if access.get_attribute("aria-disabled", timeout=100) == "true":
            return True
    except Exception:
        pass
    # 3) финальная проверка: открывается ли dropdown
    try:
        access.click()
        op = page.locator('[role="option"]').filter(has_text=TARGET).first
        op.wait_for(state="visible", timeout=100)
        try:
            page.keyboard.press("Escape")
        except Exception:
            pass
        return False
    except Exception:
        return True


def _clear_and_find_user(page, email):
    """Очистить поиск, снова вписать email, дождаться строки. Возвращает True, если видна."""
    search = page.locator('input[placeholder*="Поиск по"]').first
    try:
        search.clear()
    except Exception:
        search.fill("")
    time.sleep(3)
    search.click()
    search.fill(email)
    try:
        _row_for_email(page, email).wait_for(state="visible", timeout=TIMEOUT_SEARCH)
        return True
    except PlaywrightTimeoutError:
        return False


def _refresh_combobox_state(page, email):
    """item 3.2/3.4 refresher: очистить строку поиска -> sleep(1s) -> вписать email.

    Заставляет React-UI прочитать заново устаревшее состояние combobox после снятия
    групп через Cloud Org API: бэкенд снимает membership, но combobox по-прежнему
    показывает locked-state, пока строка поиска не будет перепроинициализирована
    (очистить -> пауза -> повторный ввод email). Возвращает True, если строка
    пользователя снова видна.
    """
    search = page.locator('input[placeholder*="Поиск по"]').first
    try:
        search.clear()
    except Exception:
        search.fill("")
    time.sleep(2)  # item 3.2/3.4: пауза 2с перед повторным вписыванием email
    search.click()
    search.fill(email)
    try:
        _row_for_email(page, email).wait_for(state="visible", timeout=TIMEOUT_SEARCH)
        return True
    except PlaywrightTimeoutError:
        return False


def _try_lower(page, email, target=TARGET):
    """Открыть dropdown и выбрать target. Возвращает True, если права понизились."""
    access = _combobox(page, email)
    if access is None:
        return False
    access.click()
    option = page.locator('[role="option"]').filter(has_text=target).first
    try:
        option.wait_for(state="visible", timeout=TIMEOUT_UI)
        option.click()
    except PlaywrightTimeoutError:
        return False
    try:
        page.wait_for_function(f"""() => {{
            const row = Array.from(document.querySelectorAll('tr')).find(r => r.innerText.includes('{email}'));
            if (!row) return false;
            const span = row.querySelector('button[role="combobox"] span.g-button__text');
            return span && span.innerText.includes('{target}');
        }}""", timeout=TIMEOUT_RESULT)
        return True
    except PlaywrightTimeoutError:
        for label in ("Сохранить", "Применить", "Готово", "OK"):
            btn = page.get_by_text(label, exact=True).first
            try:
                if btn.is_visible(timeout=500):
                    btn.click()
                    page.wait_for_load_state("networkidle", timeout=3000)
                    return True
            except Exception:
                pass
        return False


def _resolve_cloud_uids(email, login):
    """Возвращает список cloudUid юзера (Issue 4).

    resolve_cloud_uid видит лишь одну Cloud-идентичность, но у юзера их может быть
    несколько (полный email vs. локальная часть), а группами владеет конкретный cloudUid.
    Запрашиваем все возможные формы логина и объединяем найденные cloudUid.
    """
    cands = []
    for c in (login, email):
        if c and c not in cands:
            cands.append(c)
    if "@" in email:
        local = email.split("@", 1)[0]
        if local not in cands:
            cands.append(local)
    uids = []
    for cand in cands:
        uid = resolve_cloud_uid(cand)
        if uid and uid not in uids:
            uids.append(uid)
    return uids


def _collect_uid_groups(uids):
    """Собрать группы всех uid в один список без дубликатов по gid (Issue 4),
    запоминая cloudUid каждой группы в поле _uid для последующего снятия."""
    groups, seen_gid = [], set()
    for uid in uids:
        for g in cloud_list_groups(uid):
            gid = g.get("id")
            if gid and gid not in seen_gid:
                seen_gid.add(gid)
                item = dict(g)
                item["_uid"] = uid
                groups.append(item)
    return groups


def _wait_propagation_unlocked(page, email, uid, pending_gid, timeout_ms, label=""):
    """Ожидаем, пока снятие группы применится к UI (Issues 1 & 2).

    Успех = ОБА условия необходимы (Issue 2):
      1) combobox НЕ заблокирован  -> combobox_unlocked == True;
      2) Cloud-группа реально снята -> pending_gid отсутствует в cloud_list_groups(uid).

    Комбокс — вторичный/мягкий сигнал (Issue 2): combobox может разблокироваться
    раньше, чем membership-система Cloud зафиксирует снятие (updateMembers -> done:false
    асинхронен, Issue 3). Cloud-группа — первичный/авторитетный источник истины.
    Считаем успехом только совпадение обоих сигналов.

    Опрос до timeout_ms с backoff (Issue 1): НЕ фиксированный sleep 60s, а
    динамический backoff (0.5s, рост до 3s) — реагируем на разблокировку сразу,
    но не дольше таймаута.
    """
    deadline = time.monotonic() + timeout_ms / 1000.0
    backoff = 0.5
    while True:
        # item 3.2/3.4: перед каждым опросом ОБНОВЛЯЕМ устаревшее состояние combobox
        # (очистить -> sleep(1s) -> вписать email), иначе combobox сохраняет
        # устаревший locked-state даже после реального снятия групп бэкендом
        # (cloud_gone == True). Ре-триггер строки поиска = force re-render.
        _refresh_combobox_state(page, email)
        combobox_unlocked = not _combobox_locked(page, email)
        remaining = cloud_list_groups(uid)
        remaining_ids = {g.get("id") for g in remaining if g.get("id")}
        cloud_gone = pending_gid is None or pending_gid not in remaining_ids
        if combobox_unlocked and cloud_gone:
            return True
        if time.monotonic() >= deadline:
            log(f"  [item3] {email}: {timeout_ms}ms [{label}] "
                f"combobox_unlocked={combobox_unlocked} cloud_gone={cloud_gone} "
                f"pending_gid={pending_gid} remaining={[g.get('id') for g in remaining]} — сдаёмся")
            return False


def _remove_one(page, email, group, label, idx):
    """Снят одну Cloud-группу и ожидать разблокировки combobox propagation poll-ом.

    Issue 3: cloud_remove_member уже опросил async-operation до done/error.
    Если ok=False — немедленно сдаёмся (UI-попытка бессмысленна).
    Issues 1 & 2: _wait_propagation_unlocked даёт синхронное асинхронное
    распространение (backoff-опрос до timeout_ms), требуя ОБА сигнала:
    combobox_unlocked (вторичный) и cloud_gone по membership (первичный).
    """
    uid = group.get("_uid")
    ok, detail = cloud_remove_member(group["id"], uid)
    log(f"  [item3] {email}: [{label}] снята {group['name'] or group['id']}: "
        f"{'OK' if ok else 'ERR '}{detail}")
    if not ok:
        # Issue 3: cloud_remove_member уже опросил операцию до done/error; если ok=False — не пытаемся UI.
        return False
    if not _clear_and_find_user(page, email):
        log(f"  [item3] {email}: юзер не вернулся в список после снятия {group['name']}")
        return False
    if _wait_propagation_unlocked(page, email, uid, group["id"], PROPAGATION_TIMEOUT, label=label):
        log(f"  [item3] {email}: OK — бокс разблокирован (снято {idx} групп)")
        return True
    return False


def unlock_rights(page, email, login):
    """Исключаем юзера из групп Cloud Org, пока бокс прав не станет активным (item 3).

    Фаза A: поочерёдное снятие с групп до разблокировки (минимально необходимое, early stop).
    Фаза B: повторный обход — на случай перегенерированных/вложенных/асинхронно-не успевших
            групп после первого прохода.

    Возвращает True, если после снятия с групп бокс разблокировался.
    """
    log(f"  [item3] {email}: combobox заблокирован — пробуем снятие с групп (Cloud Org)")
    # Issue 4: все Cloud-идентичности юзера (полный email vs. локальная часть).
    uids = _resolve_cloud_uids(email, login)
    if not uids:
        log(f"  [item3] {email}: не удалось resolve cloudUid (login={login})")
        return False

    groups = _collect_uid_groups(uids)
    if not groups:
        log(f"  [item3] {email}: uid={uids} — нет групп в Cloud Org; разблокировать нечем")
        return False
    log(f"  [item3] {email}: uid={uids}, групп в Cloud Org: {len(groups)}")

    # Issue 4: ограничиваем снятие групп — только привязанные к очередям Трекера.
    # write_keys — группы с правом create/write/grant в очередях Трекера;
    # bound_keys — группы, встречающиеся в ACL хоть одной очереди.
    write_keys, bound_keys = tracker_groups_scan()
    log(f"  [item3] {email}: scan — write={len(write_keys)} bound={len(bound_keys)}")

    # Фаза A: только группы, дающие право create/write/grant в очередях Трекера.
    # Issue 3: НЕ прерываемся при пустой Фазе A — идём в Фазу B (все группы,
    # привязанные к очеред Трекера).
    write_groups = cloud_groups_granting_tracker_access(groups, write_keys)

    # Issue 1/2: _remove_one выполняет propagation-опрос после снятия каждой группы.
    removed_gids, idx = set(), 0
    for g in write_groups:
        removed_gids.add(g["id"])
        idx += 1
        if _remove_one(page, email, g, "фаза A", idx):
            return True

    # Issue 3: все оставшиеся группы, привязанные к очеред Трекера (любое право из ACL),
    # но не снятые в Фазе A (по gid). Перебираем в 2 прохода для стабильности.
    for _ in range(2):
        fresh = _collect_uid_groups(uids)
        if not fresh:
            break
        fresh = cloud_groups_bound_to_queue(fresh, bound_keys)
        if not fresh:
            break
        for g in fresh:
            if g["id"] in removed_gids:
                continue
            idx += 1
            if _remove_one(page, email, g, "фаза B", idx):
                return True
        page.wait_for_timeout(150)

    log(f"  [item3] {email}: не удалось разблокировать (снято {idx} групп, всё ещё заблокиран)")
    return False


def log(msg):
    line = f"[{now_str()}] {msg}"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        print(f"Ошибка записи в лог: {e}")
    print(line)


def now_str():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_logged_in(page):
    log(f"Открытие: {PAGE}")
    page.goto(PAGE, wait_until="domcontentloaded", timeout=60000)
    log(f"URL: {page.url}")
    
    # Надежный селектор, игнорирующий &nbsp; в placeholder
    search = page.locator('input[placeholder*="Поиск по"]').first
    try:
        search.wait_for(state="visible", timeout=TIMEOUT_AUTH)
        log("Авторизация OK.")
    except PlaywrightTimeoutError:
        raise SystemExit("Не удалось открыть список. Проверьте вход.")


def set_access(page, email):
    log(f"--- {email} ---")
    
    # 1) Поиск
    search = page.locator('input[placeholder*="Поиск по"]').first
    search.click()
    search.fill(email)
    page.wait_for_timeout(300) # Микро-пауза, чтобы React успел начать фильтрацию

    # 2) Ждем строку (у <tr> нет role="row", ищем просто tr)
    row = page.locator('tr').filter(has_text=email).first
    try:
        row.wait_for(state="visible", timeout=TIMEOUT_SEARCH)
    except PlaywrightTimeoutError:
        log(f"FAIL {email}: не найден")
        return

    # 3) Combobox
    # В HTML это <button role="combobox">...<span class="g-button__text">Чтение</span></button>
    access = row.locator('button[role="combobox"]').first
    try:
        # Берем текст именно из span.g-button__text
        current = (access.locator('span.g-button__text').text_content(timeout=TIMEOUT_RESULT) or "").strip()
    except Exception as e:
        log(f"FAIL {email}: combobox недоступен ({e})")
        return
        
    if current == TARGET:
        log(f"OK {email}: already {TARGET}")
        return
    if current != SOURCE:
        log(f"SKIP {email}: is {current}")
        return

    # 4) Понизить права (bokс должен быть активен)
    if _combobox_locked(page, email):
        # Комбо-бокс недоступен из-за членства в группах (item 3):
        # исключаем из групп Cloud Org, затем снова пытаемся понизить.
        log(f"INFO {email}: права заблокированы (bokс недоступен) — item 3 (Cloud Org)")
        login = _resolve_cloud_login(email)
        if unlock_rights(page, email, login):
            if _try_lower(page, email):
                return
        log(f"FAIL {email}: item 3 — права не понизились после снятия с групп")
        return

    if _try_lower(page, email):
        log(f"OK {email}: downgraded {SOURCE} -> {TARGET}")
        return
    log(f"FAIL {email}: не понизилось")


def clear_search(page):
    search = page.locator('input[placeholder*="Поиск по"]').first
    try:
        search.clear() # Быстрее, чем Ctrl+A + Del
    except Exception:
        search.fill("")


def main():
    log(f"=== Старт. Всего: {len(EMAILS)} ===")
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            user_data_dir=PROFILE_DIR, executable_path=CHROME_EXE,
            headless=False, locale="ru", viewport={"width": 1600, "height": 900}
        )
        page = ctx.new_page()
        try:
            ensure_logged_in(page)
            for i, email in enumerate(EMAILS):
                if i > 0: clear_search(page)
                set_access(page, email)
            log("=== Готово ===")
        except Exception as e:
            log(f"КРИТИЧЕСКОЕ ПАДЕНИЕ: {e}")
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
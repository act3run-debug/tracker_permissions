import time
import subprocess
import os
from playwright.sync_api import sync_playwright, expect

AUTOMATION_PROFILE = r"C:\Users\kvfv307\AppData\Local\ChromeAutomation"
TARGET_USER = "hongnhung.vu@astrazeneca.com"
CDP_PORT = 9222

EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

# === Универсальные селекторы (RU + EN) ===
SHOW_MORE_SELECTORS = [
    "button[aria-label*='скрыт']",
    "button[aria-label*='Показать еще']",
    "button[aria-label*='hidden managers']",
    "button:has-text('Показать еще')",
    "button:has-text('Show')",
]

VIEW_PROFILE_SELECTORS = [
    "button[aria-label*='View profile']",
    "button[aria-label*='Просмотреть профиль']",
    "button[aria-label*='просмотреть профиль']",
    "button[aria-label*='Посмотреть профиль']",
    "button:has-text('View profile')",
    "button:has-text('Просмотреть профиль')",
    "button:has-text('Посмотреть профиль')",
]

EMAIL_SELECTORS = [
    "button[aria-label^='Email:']",
    "button[aria-label^='Электронная почта:']",
    "button[aria-label*='Email:']",
    "button[aria-label*='почта:']",
    "button[aria-label*='@']",
]

BACK_SELECTORS = [
    "button[data-testid='NavigationBackButton']",
    "button[aria-label='Back']",
    "button[aria-label='Назад']",
    "button[title='Back']",
    "button[title='Назад']",
]

ORG_SELECTORS = [
    "#LPC_Header_TabBar_Organization",
    "button[name='Organization']",
    "[data-content='Organization']",
]


def find_element_anywhere(page, selectors, timeout=15000):
    """Быстрый поиск элемента по списку селекторов в page и всех iframe'ах."""
    if isinstance(selectors, str):
        selectors = [selectors]
    
    deadline = time.time() + timeout / 1000
    while time.time() < deadline:
        for selector in selectors:
            try:
                candidate = page.locator(selector)
                if candidate.count() > 0:
                    return candidate.first, page, selector
            except:
                pass
            for frame in page.frames:
                try:
                    candidate = frame.locator(selector)
                    if candidate.count() > 0:
                        return candidate.first, frame, selector
                except:
                    continue
        time.sleep(0.2)
    return None, None, None


def wait_for_any(page, selectors, timeout=15000):
    return find_element_anywhere(page, selectors, timeout)


def expand_all_managers(page, container):
    """Разворачивает всех менеджеров. Вызывается каждый раз, когда список мог свернуться."""
    max_iterations = 15
    for iteration in range(max_iterations):
        btn, _, matched = find_element_anywhere(page, SHOW_MORE_SELECTORS, timeout=500)
        if not btn:
            if iteration == 0:
                print("  ✓ Все менеджеры уже развёрнуты")
            else:
                print(f"  ✓ Все менеджеры развёрнуты (итераций: {iteration})")
            break
        
        print(f"  Нажимаю 'Показать ещё' (итерация {iteration + 1})")
        btn.scroll_into_view_if_needed()
        btn.click(force=True)


def extract_hierarchy(page, container):
    """Извлекает иерархию с гарантированным поиском менеджера при перезапуске."""
    hierarchy = []
    
    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
        state='visible', timeout=20000
    )
    print("  ✓ Список менеджеров появился")
    
    expand_all_managers(page, container)
    
    processed = 0
    while True:
        managers = container.locator("ol button[id^='org-explorer-manager-']")
        total = managers.count()
        if processed >= total:
            break
        
        i = processed
        try:
            # Получаем свежую ссылку на менеджера
            manager_btn = managers.nth(i)
            aria_label = manager_btn.get_attribute("aria-label") or ""
            name = aria_label.split(",")[0] if "," in aria_label else f"Manager_{i}"
            print(f"\n  [{i+1}/{total}] Обрабатываю: {name}")
            
            # 1. Клик на руководителя
            manager_btn.scroll_into_view_if_needed()
            manager_btn.click(force=True)
            time.sleep(0.5)
            
            # 2. Ожидаем и кликаем "Просмотреть профиль"
            print("    Ожидаю 'Просмотреть профиль'...")
            view_btn, _, matched = wait_for_any(page, VIEW_PROFILE_SELECTORS, timeout=15000)
            if not view_btn:
                raise Exception("Кнопка 'Просмотреть профиль' не появилась")
            
            expect(view_btn).to_be_visible(timeout=5000)
            view_btn.scroll_into_view_if_needed()
            view_btn.click(force=True)
            time.sleep(0.5)
            
            # 3. Ожидаем email и ПРОВЕРЯЕМ на совпадение с TARGET_USER
            print("    Ожидаю email...")
            email_btn, _, matched = wait_for_any(page, EMAIL_SELECTORS, timeout=15000)
            if not email_btn:
                raise Exception("Email не появился в профиле")
            
            expect(email_btn).to_be_visible(timeout=5000)
            
            email = email_btn.get_attribute("aria-label")
            email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()
            
            retry_count = 0
            max_retries = 3
            
            # Если email совпадает с целевым, перезапускаем открытие профиля ЗАНОВО
            while email.lower() == TARGET_USER.lower() and retry_count < max_retries:
                print(f"    ⚠ Email совпадает с целевым! Сбрасываю состояние и открываю профиль заново... (попытка {retry_count + 1}/{max_retries})")
                
                # a) Возвращаемся назад, чтобы закрыть залипшую карточку
                back_btn, _, _ = wait_for_any(page, BACK_SELECTORS, timeout=10000)
                if back_btn:
                    back_btn.click(force=True)
                    time.sleep(1)
                
                # b) Ждём возврата к списку
                container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                    state='visible', timeout=10000
                )
                
                # c) КРИТИЧЕСКИ ВАЖНО: Снова разворачиваем список, если он свернулся
                expand_all_managers(page, container)
                
                # d) КРИТИЧЕСКИ ВАЖНО: ЗАНОВО находим нужного менеджера по индексу (i)
                # Это гарантирует, что мы кликнем на правильного человека, даже если DOM перестроился
                managers = container.locator("ol button[id^='org-explorer-manager-']")
                manager_btn = managers.nth(i)
                
                # e) Снова открываем его профиль
                print(f"    Повторно открываю профиль: {name}")
                manager_btn.scroll_into_view_if_needed()
                manager_btn.click(force=True)
                time.sleep(1)
                
                view_btn_retry, _, _ = wait_for_any(page, VIEW_PROFILE_SELECTORS, timeout=10000)
                if view_btn_retry:
                    view_btn_retry.scroll_into_view_if_needed()
                    view_btn_retry.click(force=True)
                    time.sleep(1.5) # Даём время на рендер новой карточки
                    
                    email_btn_retry, _, _ = wait_for_any(page, EMAIL_SELECTORS, timeout=10000)
                    if email_btn_retry:
                        email = email_btn_retry.get_attribute("aria-label")
                        email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()
                
                retry_count += 1
            
            # Финальная проверка после всех попыток
            if email.lower() == TARGET_USER.lower():
                print(f"    ✗ КРИТИЧЕСКАЯ ОШИБКА: Не удалось получить корректный email для {name} после {max_retries} попыток.")
                hierarchy.append({"name": name, "email": "ERROR_RETRIEVING_EMAIL"})
            else:
                print(f"    ✓ Email: {email}")
                hierarchy.append({"name": name, "email": email})
            
            time.sleep(0.5)
            
            # 4. Клик назад (гарантированно возвращаемся к списку)
            print("    Возвращаюсь назад к списку...")
            back_btn_final, _, _ = wait_for_any(page, BACK_SELECTORS, timeout=10000)
            if back_btn_final:
                back_btn_final.click(force=True)
                time.sleep(0.5)
            
            # Ждём возврата к списку
            container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                state='visible', timeout=10000
            )
            
            # После возврата список мог свернуться — разворачиваем перед следующей итерацией
            expand_all_managers(page, container)
            
            processed += 1
            
        except Exception as e:
            print(f"    ✗ Ошибка: {e}")
            try:
                back_btn, _, _ = find_element_anywhere(page, BACK_SELECTORS, timeout=5000)
                if back_btn:
                    back_btn.click(force=True)
                    time.sleep(0.5)
                    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                        state='visible', timeout=10000
                    )
                    expand_all_managers(page, container)
            except Exception as rec_err:
                print(f"    ⚠ Не удалось восстановиться: {rec_err}")
    
    return hierarchy


# ==================== ОСНОВНОЙ СКРИПТ ====================

playwright = sync_playwright().start()
browser = None

try:
    try:
        browser = playwright.chromium.connect_over_cdp(f"http://localhost:{CDP_PORT}")
        print(f"✓ Подключился к уже запущенному Edge (порт {CDP_PORT})")
    except Exception:
        print("Запускаю новый браузер Edge...")
        edge_path = next((p for p in EDGE_PATHS if os.path.exists(p)), None)
        if not edge_path:
            raise Exception("Edge не найден!")
        
        subprocess.Popen([
            edge_path, f"--user-data-dir={AUTOMATION_PROFILE}",
            f"--remote-debugging-port={CDP_PORT}", "--no-first-run",
            "--no-default-browser-check", "--start-maximized",
        ])
        time.sleep(5)
        browser = playwright.chromium.connect_over_cdp(f"http://localhost:{CDP_PORT}")
        print("✓ Подключился к новому браузеру Edge")
    
    contexts = browser.contexts
    context = contexts[0] if contexts else browser.new_context()
    page = context.pages[0] if context.pages else context.new_page()
    
    current_url = page.url
    if "teams.microsoft.com" in current_url:
        print(f"✓ Teams уже открыт. Использую существующую страницу.")
        time.sleep(2)
    else:
        print("Открываю Teams...")
        page.goto("https://teams.microsoft.com/v2/")
        page.wait_for_load_state("domcontentloaded")
        time.sleep(5)
    
    print("\nПроверяю готовность Teams...")
    try:
        page.wait_for_selector("input#ms-searchux-input", timeout=20000)
        print("✓ Teams готов")
    except:
        input("Авторизуйся в Teams и нажми Enter для продолжения...")
    
    input("Убедись, что Teams готов, и нажми Enter для старта...")
    
    print(f"\nИщу пользователя: {TARGET_USER}")
    search_input = page.wait_for_selector("input#ms-searchux-input", timeout=20000)
    search_input.click()
    time.sleep(0.5)
    
    search_input.fill(TARGET_USER)
    time.sleep(1.5)
    
    page.keyboard.press("ArrowDown")
    time.sleep(0.5)
    page.keyboard.press("ArrowDown")
    time.sleep(0.5)
    page.keyboard.press("Enter")

    print("Ожидаю открытия чата...")
    time.sleep(0.5)
    page.wait_for_selector("ul[data-tid='chat-topic-menu'] div[data-person-mri]", timeout=15000)
    print("✓ Чат открыт")
    
    print("Открываю карточку профиля собеседника...")
    profile_trigger = page.wait_for_selector("ul[data-tid='chat-topic-menu'] div[data-person-mri]", timeout=20000)
    profile_trigger.click()
    
    print("Ожидаю появления вкладки Organization...")
    org_tab, container, matched = find_element_anywhere(page, ORG_SELECTORS, timeout=15000)
    
    if not org_tab:
        for frame in [page] + page.frames:
            try:
                candidate = frame.get_by_role("tab", name="Organization")
                if candidate.count() > 0:
                    org_tab = candidate.first
                    container = frame
                    matched = "role='tab'"
                    break
            except:
                continue
    
    if not org_tab:
        raise Exception("Вкладка Organization не появилась!")
    
    print(f"  ✓ Вкладка найдена: {matched}")
    expect(org_tab).to_be_visible(timeout=10000)
    org_tab.click(force=True)
    
    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(state='visible', timeout=15000)
    print("✓ Вкладка Organization загружена")
    
    print("\nНачинаю извлечение иерархии...")
    hierarchy = extract_hierarchy(page, container)
    
    print("\n" + "=" * 60)
    print("ИТОГОВАЯ ИЕРАРХИЯ РУКОВОДИТЕЛЕЙ:")
    print("=" * 60)
    for i, person in enumerate(hierarchy, 1):
        print(f"{i}. {person['name']}")
        print(f"   Email: {person['email']}")
    print(f"\nВсего: {len(hierarchy)} руководителей")
    
    print("\nЗакрываю карточку профиля собеседника (Esc)...")
    page.keyboard.press("Escape")
    time.sleep(0.5)
    print("✓ Карточка закрыта")

except Exception as e:
    print(f"\n✗ ОШИБКА: {e}")
    import traceback
    traceback.print_exc()

finally:
    print("\nСкрипт завершается, браузер Edge остается открытым.")
    try:
        playwright.stop()
    except:
        pass
    input("\nНажми Enter для выхода из консоли...")
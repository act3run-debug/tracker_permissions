from pathlib import Path

base = Path(__file__).resolve().parent

files = [
    base / "output_outlook_fired.txt",
    base / "fired_in_180.txt",
]

out = base / "output.txt"

seen = set()
emails = []

for path in files:
    text = path.read_text(encoding="utf-8-sig", errors="ignore")
    for line in text.splitlines():
        email = line.strip()
        if not email:
            continue

        key = email.lower()
        if key not in seen:
            seen.add(key)
            emails.append(email)

out.write_text(
    "\n".join(emails) + ("\n" if emails else ""),
    encoding="utf-8"
)
from pathlib import Path

file_path = Path(__file__).resolve().parent / "dismissed.txt"

emails = [
    line.strip()
    for line in file_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]

if not emails:
    print("[]")
else:
    print("[")
    for email in emails:
        print(f"    {email!r},")
    print("]")
from pathlib import Path
import ast

base = Path(__file__).parent

def load_emails(path):
    """Парсит список email, устойчив к проблемам с форматом."""
    with open(path, encoding='utf-8') as f:
        content = f.read()
    try:
        return ast.literal_eval(content)
    except:
        # Fallback: извлекаем все строки с @
        import re
        return re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', content)

dismissed = set(load_emails(base / 'dismissed.txt'))
for_reading = load_emails(base / 'for_reading.txt')

result = [e for e in for_reading if e not in dismissed]

with open(base / 'output.txt', 'w', encoding='utf-8') as f:
    f.write('[\n')
    for email in result:
        f.write(f'    "{email}",\n')
    f.write(']\n')

print(f"Осталось: {len(result)} email(ов) из {len(for_reading)}")
from pathlib import Path

file_path = Path(__file__).resolve().parent / "devorsed_2_for_run.txt"

with open(file_path, encoding="utf-8") as f:
    emails = [line.strip() for line in f if line.strip()]

print("[")
for email in emails:
    print(f"    {email!r},")
print("]")
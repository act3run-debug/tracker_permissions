# -*- coding: utf-8 -*-
"""Клиент Cloud Identity Hub (Yandex Cloud Organization Manager API).

Реализует минимальный набор для удаления участников организации по email:
листинг организаций, листинг участников (email -> subjectId) и удаление
membership'а с опросом long-running operation.

См. api_documentation/cloud_organization_api.md.
"""

from __future__ import annotations

import os

import requests

from modules.logging_conf import log

# {{ api-host }} для IAM-токена = api.cloud.yandex.net (см. research + 
# рабочий код в tracker_permissions).
DEFAULT_BASE_URL = "https://organization-manager.api.cloud.yandex.net"
DEFAULT_PAGE_SIZE = 1000


class IdentityHubError(RuntimeError):
    """Ошибка при обращении к Cloud Identity Hub."""


def load_iam_token(path: str) -> str:
    """Читает IAM-токен из cred-файла вида ``IAM-token: <token>``."""
    if not os.path.exists(path):
        raise IdentityHubError(f"Файл учётных данных не найден: {path}")
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("IAM-token:"):
                token = line.split(":", 1)[1].strip()
                if token:
                    return token
    raise IdentityHubError(f"IAM-токен не найден в {path}")


class IdentityHub:
    def __init__(
        self,
        iam_token: str,
        base_url: str = DEFAULT_BASE_URL,
        *,
        timeout: int = 60,
    ):
        self.iam_token = iam_token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {iam_token}",
                "Content-Type": "application/json",
            }
        )

    def _request(self, method: str, path: str, **kwargs):
        url = f"{self.base_url}{path}"
        resp = self.session.request(
            method, url, timeout=self.timeout, **kwargs
        )
        if resp.status_code != 200:
            raise IdentityHubError(
                f"{method} {path} -> {resp.status_code}: {resp.text[:500]}"
            )
        return resp.json()

    # --------------------------------------------------------------
    # Организации
    # --------------------------------------------------------------
    def list_organizations(self) -> list:
        data = self._request(
            "GET", "/organization-manager/v1/organizations"
        )
        return data.get("organizations", [])

    def get_organization_id(self, org_name: str | None = None) -> str:
        orgs = self.list_organizations()
        if not orgs:
            raise IdentityHubError("В организации нет ни одной Cloud Organization")
        org = orgs[0]
        if len(orgs) > 1 and org_name:
            for candidate in orgs:
                if candidate.get("name") == org_name:
                    org = candidate
                    break
            else:
                log.warning(
                    "Организация '%s' не найдена — используется первая из %d",
                    org_name,
                    len(orgs),
                )
        if len(orgs) > 1:
            log.warning(
                "Найдено организаций: %d, используется id=%s name=%s",
                len(orgs),
                org.get("id"),
                org.get("name"),
            )
        org_id = org.get("id")
        if not org_id:
            raise IdentityHubError("Не удалось определить id организации")
        return org_id

    # --------------------------------------------------------------
    # Участники организации
    # --------------------------------------------------------------
    def list_members(self, org_id: str) -> dict:
        """Словарь {email(нижний регистр): subjectId}."""
        result: dict = {}
        token = ""
        while True:
            params = {"pageSize": DEFAULT_PAGE_SIZE}
            if token:
                params["pageToken"] = token
            path = f"/organization-manager/v1/organizations/{org_id}/users"
            data = self._request("GET", path, params=params)
            for user in data.get("users", []):
                claims = user.get("subjectClaims") or {}
                email = (claims.get("email") or "").lower()
                sub = claims.get("sub")
                if email and sub:
                    result[email] = sub
            token = data.get("nextPageToken")
            if not token:
                break
        return result

    def get_subject_id(self, org_id: str, email: str) -> str | None:
        return self.list_members(org_id).get(email.lower())

    # --------------------------------------------------------------
    # Удаление участников
    # --------------------------------------------------------------
    def delete_user(self, org_id: str, subject_id: str) -> dict:
        """Удаляет membership пользователя.

        DELETE возвращает long-running operation. Если операцию удалось
        опросить — ждём её завершения (или проверяем ошибку); если endpoint
        недоступен (404) или операция не успела завершиться — считаем, что
        запрос принят к обработке (участник уже удаляется на стороне сервиса).
        """
        path = f"/organization-manager/v1/organizations/{org_id}/users/{subject_id}"
        operation = self._request("DELETE", path)
        op_id = operation.get("id")
        if not op_id:
            # Короткий ответ без операции (редко для Delete).
            return operation
        resolved = self._fetch_operation(org_id, op_id)
        if resolved:
            if resolved.get("done"):
                if resolved.get("error"):
                    raise IdentityHubError(
                        f"Operation {op_id} завершилась ошибкой: {resolved['error']}"
                    )
                log.info("Operation %s завершена", op_id)
                return resolved
            log.warning(
                "Operation %s не завершена — принимаем удаление как выполненное (участник удаляется на стороне сервиса)",
                op_id,
            )
        else:
            log.warning(
                "Operation %s недоступна для опроса — принимаем удаление как выполненное",
                op_id,
            )
        return operation

    def _fetch_operation(self, org_id: str, op_id: str) -> dict | None:
        """Возвращает объект Operation или None, если endpoint недоступен.

        Пробует org-scoped эндпоинт, затем global-эндпоинт Organization Manager.
        """
        candidates = [
            f"/organization-manager/v1/organizations/{org_id}/operations/{op_id}",
            f"/organization-manager/v1/operations/{op_id}",
        ]
        for path in candidates:
            try:
                return self._request("GET", path)
            except IdentityHubError as exc:
                log.debug("Опрос операции %s через %s: %s", op_id, path, exc)
        return None

    def delete_users(
        self,
        org_id: str,
        emails: list,
        *,
        dry_run: bool = False,
    ) -> tuple[list, list]:
        """
        Удаляет список email.

        Возвращает (успешные, неудачные). При dry_run удаления не выполняются.
        """
        by_email = self.list_members(org_id)
        success: list = []
        failed: list = []
        for email in emails:
            subject_id = by_email.get(email.lower())
            if not subject_id:
                log.warning(
                    "%s: не найден среди участников — пропущен", email
                )
                failed.append(email)
                continue
            if dry_run:
                log.info("%s (subjectId=%s): был бы удалён (dry-run)", email, subject_id)
                success.append(email)
                continue
            try:
                self.delete_user(org_id, subject_id)
                log.info("%s (subjectId=%s) удалён из организации", email, subject_id)
                success.append(email)
            except IdentityHubError as exc:
                log.error("%s: ошибка удаления — %s", email, exc)
                failed.append(email)
        return success, failed

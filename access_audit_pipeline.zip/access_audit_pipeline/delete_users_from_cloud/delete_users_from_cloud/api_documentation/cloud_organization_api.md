# Yandex Cloud Organization API

<!-- source: https://yandex.cloud/en/organization/api-ref/index -->
<!-- file: index.md -->

---
editable: false
---

# Identity Hub API: REST reference

This API reference is organized by resource. Actions are performed by sending HTTP requests to resource URLs or making RPC calls. For more information about API architecture, see [API Concepts]({{ api-url-prefix }}/api-design-guide/).

**Interface definitions** available at [GitHub](https://github.com/yandex-cloud/cloudapi/tree/master/yandex/cloud/organizationmanager/v1).

**Service URL**: `https://organization-manager.{{ api-host }}`

#|
||Service | Description ||
|| [Group](Group/index.md) | A set of methods for managing groups. ||
|| [MfaEnforcement](MfaEnforcement/index.md) | a set of methods for managing MFA enforcements ||
|| [Operation](Operation/index.md) | A set of methods for managing operations for asynchronous API requests. ||
|| [Organization](Organization/index.md) | A set of methods for managing Organization resources. ||
|| [OsLogin](OsLogin/index.md) |  ||
|| [SshCertificate](SshCertificate/index.md) |  ||
|| [User](User/index.md) | A set of methods for managing Organization users. ||
|| [UserSshKey](UserSshKey/index.md) |  ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/convertAllToBasic -->
<!-- file: Group/convertAllToBasic.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups:convertAllToBasic
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        subjectContainerId:
          description: |-
            **string**
            Required field. Id of the subject container for which all external groups will be converted to basic (not external) groups.
            To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
            or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - subjectContainerId
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Group.ConvertAllToBasic

Converts all groups that belongs to subject container from external to basic (not external).

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups:convertAllToBasic
```

## Body parameters {#yandex.cloud.organizationmanager.v1.ConvertAllToBasicGroupsRequest}

```json
{
  "subjectContainerId": "string"
}
```

#|
||Field | Description ||
|| subjectContainerId | **string**

Required field. Id of the subject container for which all external groups will be converted to basic (not external) groups.
To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/convertToExternal -->
<!-- file: Group/convertToExternal.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}:convertToExternal
    method: post
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the Group resource to convert to external.
            To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        subjectContainerId:
          description: |-
            **string**
            Required field. Id of the subject container that external group belongs to.
            Combination of subject_container_id and external_id must be unique.
            To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
            or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.
            The maximum string length in characters is 50.
          type: string
        externalId:
          description: |-
            **string**
            Required field. Id of the group from external system.
            Combination of subject_container_id and external_id must be unique
            The maximum string length in characters is 1024.
          type: string
        makeEditor:
          description: |-
            **boolean**
            If true, then subject that performs conversion of group will be assigned to role that allows modification of group as external group.
          type: boolean
      required:
        - subjectContainerId
        - externalId
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Group.ConvertToExternal

Converts single basic (not external) group to external. Precondition: group must be basic.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}:convertToExternal
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the Group resource to convert to external.
To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.ConvertToExternalGroupRequest}

```json
{
  "subjectContainerId": "string",
  "externalId": "string",
  "makeEditor": "boolean"
}
```

#|
||Field | Description ||
|| subjectContainerId | **string**

Required field. Id of the subject container that external group belongs to.
Combination of subject_container_id and external_id must be unique.
To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.

The maximum string length in characters is 50. ||
|| externalId | **string**

Required field. Id of the group from external system.
Combination of subject_container_id and external_id must be unique

The maximum string length in characters is 1024. ||
|| makeEditor | **boolean**

If true, then subject that performs conversion of group will be assigned to role that allows modification of group as external group. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/create -->
<!-- file: Group/create.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the organization to create a group in.
            To get the organization ID, use a [yandex.cloud.organizationmanager.v1.OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.
            The maximum string length in characters is 50.
          type: string
        name:
          description: |-
            **string**
            Required field. Name of the group.
            The name must be unique within the organization.
            Value must match the regular expression ` [a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])? `.
          pattern: '[a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])?'
          type: string
        description:
          description: |-
            **string**
            Description of the group.
            The maximum string length in characters is 256.
          type: string
        labels:
          description: |-
            **object** (map<**string**, **string**>)
            Resource labels as `key:value` pairs.
            The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource.
          type: object
          additionalProperties:
            type: string
            pattern: '[-_0-9a-z]*'
            maxLength: 63
          propertyNames:
            type: string
            pattern: '[a-z][-_0-9a-z]*'
            maxLength: 63
            minLength: 1
          maxProperties: 64
      required:
        - organizationId
        - name
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Group.Create

Creates a group in the specified organization.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/groups
```

## Body parameters {#yandex.cloud.organizationmanager.v1.CreateGroupRequest}

```json
{
  "organizationId": "string",
  "name": "string",
  "description": "string",
  "labels": "object"
}
```

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the organization to create a group in.
To get the organization ID, use a [yandex.cloud.organizationmanager.v1.OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.

The maximum string length in characters is 50. ||
|| name | **string**

Required field. Name of the group.
The name must be unique within the organization.

Value must match the regular expression ` [a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])? `. ||
|| description | **string**

Description of the group.

The maximum string length in characters is 256. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs.

The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/createExternal -->
<!-- file: Group/createExternal.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the organization to create a group in.
            To get the organization ID, use a [yandex.cloud.organizationmanager.v1.OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.
            The maximum string length in characters is 50.
          type: string
        name:
          description: |-
            **string**
            Required field. Name of the group.
            The name must be unique within the organization.
            Value must match the regular expression ` [a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])? `.
          pattern: '[a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])?'
          type: string
        description:
          description: |-
            **string**
            Description of the group.
            The maximum string length in characters is 256.
          type: string
        subjectContainerId:
          description: |-
            **string**
            Required field. Id of the subject container that external group belongs to.
            Combination of subject_container_id and external_id must be unique.
            To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
            or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.
            The maximum string length in characters is 50.
          type: string
        externalId:
          description: |-
            **string**
            Required field. Id of the group from external system.
            Combination of subject_container_id and external_id must be unique
            The maximum string length in characters is 1024.
          type: string
        makeEditor:
          description: |-
            **boolean**
            If true, then creator of group will be assigned to role that allows modification of group as external group.
          type: boolean
        labels:
          description: |-
            **object** (map<**string**, **string**>)
            Resource labels as `key:value` pairs.
            The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource.
          type: object
          additionalProperties:
            type: string
            pattern: '[-_0-9a-z]*'
            maxLength: 63
          propertyNames:
            type: string
            pattern: '[a-z][-_0-9a-z]*'
            maxLength: 63
            minLength: 1
          maxProperties: 64
      required:
        - organizationId
        - name
        - subjectContainerId
        - externalId
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Group.CreateExternal

Creates an external group.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups
```

## Body parameters {#yandex.cloud.organizationmanager.v1.CreateExternalGroupRequest}

```json
{
  "organizationId": "string",
  "name": "string",
  "description": "string",
  "subjectContainerId": "string",
  "externalId": "string",
  "makeEditor": "boolean",
  "labels": "object"
}
```

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the organization to create a group in.
To get the organization ID, use a [yandex.cloud.organizationmanager.v1.OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.

The maximum string length in characters is 50. ||
|| name | **string**

Required field. Name of the group.
The name must be unique within the organization.

Value must match the regular expression ` [a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])? `. ||
|| description | **string**

Description of the group.

The maximum string length in characters is 256. ||
|| subjectContainerId | **string**

Required field. Id of the subject container that external group belongs to.
Combination of subject_container_id and external_id must be unique.
To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.

The maximum string length in characters is 50. ||
|| externalId | **string**

Required field. Id of the group from external system.
Combination of subject_container_id and external_id must be unique

The maximum string length in characters is 1024. ||
|| makeEditor | **boolean**

If true, then creator of group will be assigned to role that allows modification of group as external group. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs.

The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/delete -->
<!-- file: Group/delete.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}
    method: delete
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the group to delete.
            To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.Delete

Deletes the specified group.

## HTTP request

```
DELETE https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the group to delete.
To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/get -->
<!-- file: Group/get.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}
    method: get
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the Group resource to return.
            To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.Get

Returns the specified Group resource.
To get the list of available Group resources, make a [List](/docs/organization/api-ref/Group/list#List) request.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the Group resource to return.
To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.Group}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "organizationId": "string",
  "createdAt": "string",
  "name": "string",
  "description": "string",
  "subjectContainerId": "string",
  "externalId": "string",
  "labels": "object"
}
```

A Group resource.
For more information, see [Groups](/docs/organization/operations/manage-groups).

#|
||Field | Description ||
|| id | **string**

ID of the group. ||
|| organizationId | **string**

ID of the organization that the group belongs to. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| name | **string**

Name of the group. ||
|| description | **string**

Description of the group. ||
|| subjectContainerId | **string**

Id of the subject container that external group belongs to. It is set if group is external. ||
|| externalId | **string**

Id of the group from external system. It is set if group is external. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/index -->
<!-- file: Group/index.md -->

---
editable: false
---

# Identity Hub API, REST: Group

A set of methods for managing groups.

## Methods

#|
||Method | Description ||
|| [Get](get.md) | Returns the specified Group resource. ||
|| [ResolveExternal](resolveExternal.md) | Returns external group by subject container and external id ||
|| [List](list.md) | Retrieves the list of group resources. ||
|| [ListExternal](listExternal.md) | Retrieves the list of external group linked subject container ||
|| [Create](create.md) | Creates a group in the specified organization. ||
|| [CreateExternal](createExternal.md) | Creates an external group. ||
|| [Update](update.md) | Updates the specified group. ||
|| [ConvertToExternal](convertToExternal.md) | Converts single basic (not external) group to external. Precondition: group must be basic. ||
|| [ConvertAllToBasic](convertAllToBasic.md) | Converts all groups that belongs to subject container from external to basic (not external). ||
|| [Delete](delete.md) | Deletes the specified group. ||
|| [ListOperations](listOperations.md) | Lists operations for the specified group. ||
|| [ListMembers](listMembers.md) | List group active members. ||
|| [UpdateMembers](updateMembers.md) | Update group members. ||
|| [ListAccessBindings](listAccessBindings.md) | Lists access bindings for the specified group. ||
|| [SetAccessBindings](setAccessBindings.md) | Sets access bindings for the specified group. ||
|| [UpdateAccessBindings](updateAccessBindings.md) | Updates access bindings for the specified group. ||
|| [ListEffective](listEffective.md) | Returns groups that the subject belongs to within a specific organization. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/list -->
<!-- file: Group/list.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups
    method: get
    path: null
    query:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the organization to list groups in.
            To get the organization ID, use a [yandex.cloud.organizationmanager.v1.OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.
            The maximum string length in characters is 50.
          type: string
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`,
            the service returns a [ListGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
        filter:
          description: |-
            **string**
            A filter expression that filters resources listed in the response.
            The expression must specify:
            1. The field name. Currently you can use filtering only on the [Group.name](#yandex.cloud.organizationmanager.v1.Group) field.
            2. An `=` operator.
            3. The value in double quotes (`"`). Must be 3-63 characters long and match the regular expression `[a-z][-a-z0-9]{1,61}[a-z0-9]`.
            The maximum string length in characters is 1000.
          type: string
      required:
        - organizationId
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.List

Retrieves the list of group resources.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/groups
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListGroupsRequest}

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the organization to list groups in.
To get the organization ID, use a [yandex.cloud.organizationmanager.v1.OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.

The maximum string length in characters is 50. ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`,
the service returns a [ListGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|| filter | **string**

A filter expression that filters resources listed in the response.
The expression must specify:
1. The field name. Currently you can use filtering only on the [Group.name](#yandex.cloud.organizationmanager.v1.Group) field.
2. An `=` operator.
3. The value in double quotes (`"`). Must be 3-63 characters long and match the regular expression `[a-z][-a-z0-9]{1,61}[a-z0-9]`.

The maximum string length in characters is 1000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListGroupsResponse}

**HTTP Code: 200 - OK**

```json
{
  "groups": [
    {
      "id": "string",
      "organizationId": "string",
      "createdAt": "string",
      "name": "string",
      "description": "string",
      "subjectContainerId": "string",
      "externalId": "string",
      "labels": "object"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| groups[] | **[Group](#yandex.cloud.organizationmanager.v1.Group)**

List of Group resources. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListGroupsRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListGroupsRequest), use
the `nextPageToken` as the value
for the [ListGroupsRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListGroupsRequest) query parameter
in the next list request. Each subsequent list request will have its own
`nextPageToken` to continue paging through the results. ||
|#

## Group {#yandex.cloud.organizationmanager.v1.Group}

A Group resource.
For more information, see [Groups](/docs/organization/operations/manage-groups).

#|
||Field | Description ||
|| id | **string**

ID of the group. ||
|| organizationId | **string**

ID of the organization that the group belongs to. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| name | **string**

Name of the group. ||
|| description | **string**

Description of the group. ||
|| subjectContainerId | **string**

Id of the subject container that external group belongs to. It is set if group is external. ||
|| externalId | **string**

Id of the group from external system. It is set if group is external. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/listAccessBindings -->
<!-- file: Group/listAccessBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{resourceId}:listAccessBindings
    method: get
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource to list access bindings for.
            To get the resource ID, use a corresponding List request.
            For example, use the [yandex.cloud.resourcemanager.v1.CloudService.List](/docs/resource-manager/api-ref/Cloud/list#List) request to get the Cloud resource ID.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page that should be returned. If the number of available
            results is larger than `pageSize`,
            the service returns a [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 100.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.ListAccessBindings

Lists access bindings for the specified group.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{resourceId}:listAccessBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource to list access bindings for.
To get the resource ID, use a corresponding List request.
For example, use the [yandex.cloud.resourcemanager.v1.CloudService.List](/docs/resource-manager/api-ref/Cloud/list#List) request to get the Cloud resource ID.

The maximum string length in characters is 64. ||
|#

## Query parameters {#yandex.cloud.access.ListAccessBindingsRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page that should be returned. If the number of available
results is larger than `pageSize`,
the service returns a [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.access.ListAccessBindingsResponse}

**HTTP Code: 200 - OK**

```json
{
  "accessBindings": [
    {
      "roleId": "string",
      "subject": {
        "id": "string",
        "type": "string"
      }
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| accessBindings[] | **[AccessBinding](#yandex.cloud.access.AccessBinding)**

List of access bindings for the specified resource. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListAccessBindingsRequest.pageSize](#yandex.cloud.access.ListAccessBindingsRequest), use
the `nextPageToken` as the value
for the [ListAccessBindingsRequest.pageToken](#yandex.cloud.access.ListAccessBindingsRequest) query parameter
in the next list request. Each subsequent list request will have its own
`nextPageToken` to continue paging through the results. ||
|#

## AccessBinding {#yandex.cloud.access.AccessBinding}

#|
||Field | Description ||
|| roleId | **string**

Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the `subject`.

The maximum string length in characters is 64. ||
|| subject | **[Subject](#yandex.cloud.access.Subject)**

Required field. Identity for which access binding is being created.
It can represent an account with a unique ID or several accounts with a system identifier. ||
|#

## Subject {#yandex.cloud.access.Subject}

#|
||Field | Description ||
|| id | **string**

Required field. ID of the subject.
It can contain one of the following values:oauth
* `allAuthenticatedUsers`: A special public group that represents anyone
who is authenticated. It can be used only if the `type` is `system`.
* `allUsers`: A special public group that represents anyone. No authentication is required.
For example, you don't need to specify the IAM token in an API query.
It can be used only if the `type` is `system`.
* `group:organization:<id>:users`: A special system group that represents all members of organization
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `group:federation:<id>:users`: A special system group that represents all users of federation
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `<cloud generated id>`: An identifier that represents a user account.
It can be used only if the `type` is `userAccount`, `federatedUser` or `serviceAccount`.

The maximum string length in characters is 100. ||
|| type | **string**

Required field. Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex or Yandex Connect, added to Yandex Cloud.
* `serviceAccount`: A service account. This type represents the [yandex.cloud.iam.v1.ServiceAccount](/docs/iam/api-ref/ServiceAccount/get#yandex.cloud.iam.v1.ServiceAccount) resource.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
* `system`: System group. This type represents several accounts with a common system identifier.
For more information, see [Subject to which the role is assigned](/docs/iam/concepts/access-control/#subject).

The maximum string length in characters is 100. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/listEffective -->
<!-- file: Group/listEffective.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups:listEffective
    method: get
    path: null
    query:
      type: object
      properties:
        subjectId:
          description: |-
            **string**
            Required field. ID of the subject to list groups for.
            The maximum string length in characters is 50.
          type: string
        organizationId:
          description: |-
            **string**
            The ID of the organization to scope the group search to.
            If omitted and the subject belongs to a single organization,
            that organization's ID will be used automatically.
            The maximum string length in characters is 50.
          type: string
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`, the service returns a [ListEffectiveResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListEffectiveResponse)
            that can be used to get the next page of results in subsequent list requests.
            Acceptable values are 0 to 1000, inclusive. Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListEffectiveResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListEffectiveResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
        filter:
          description: |-
            **string**
            A filter expression that filters resources listed in the response.
            The expression supports the following operations:
            - `=` for exact match: `name = 'example-name'`
            - `IN` for multiple values: `id IN ('id1', 'id2')`
            - `contains` for domain substring search: `name contains 'example'`
            - `AND` for combining conditions: `name contains 'my-group' AND name contains 'name'`
            Available fields for filtering:
            - `id` - group ID
            - `name` - group name
            Must be 1-1000 characters long.
            The maximum string length in characters is 1000.
          type: string
      required:
        - subjectId
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.ListEffective

Returns groups that the subject belongs to within a specific organization.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/groups:listEffective
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListEffectiveRequest}

#|
||Field | Description ||
|| subjectId | **string**

Required field. ID of the subject to list groups for.

The maximum string length in characters is 50. ||
|| organizationId | **string**

The ID of the organization to scope the group search to.
If omitted and the subject belongs to a single organization,
that organization's ID will be used automatically.

The maximum string length in characters is 50. ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`, the service returns a [ListEffectiveResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListEffectiveResponse)
that can be used to get the next page of results in subsequent list requests.
Acceptable values are 0 to 1000, inclusive. Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListEffectiveResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListEffectiveResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|| filter | **string**

A filter expression that filters resources listed in the response.
The expression supports the following operations:
- `=` for exact match: `name = 'example-name'`
- `IN` for multiple values: `id IN ('id1', 'id2')`
- `contains` for domain substring search: `name contains 'example'`
- `AND` for combining conditions: `name contains 'my-group' AND name contains 'name'`
Available fields for filtering:
- `id` - group ID
- `name` - group name
Must be 1-1000 characters long.

The maximum string length in characters is 1000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListEffectiveResponse}

**HTTP Code: 200 - OK**

```json
{
  "groupMembershipInfo": [
    {
      "groupId": "string",
      "groupName": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| groupMembershipInfo[] | **[GroupMembershipInfo](#yandex.cloud.organizationmanager.v1.GroupMembershipInfo)**

List of group membership information.
Contains groups where the specified subject is a member. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListEffectiveRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListEffectiveRequest), use the `nextPageToken` as the value
for the [ListEffectiveRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListEffectiveRequest) query parameter in the next list request.
Each subsequent list request will have its own `nextPageToken` to continue paging through the results. ||
|#

## GroupMembershipInfo {#yandex.cloud.organizationmanager.v1.GroupMembershipInfo}

#|
||Field | Description ||
|| groupId | **string**

ID of the group the subject is a member of. ||
|| groupName | **string**

Name of the group the subject is a member of. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/listExternal -->
<!-- file: Group/listExternal.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups
    method: get
    path: null
    query:
      type: object
      properties:
        subjectContainerId:
          description: |-
            **string**
            Required field. Id of the subject container that external group belongs to.
            To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
            or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.
            The maximum string length in characters is 50.
          type: string
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`,
            the service returns a [ListExternalGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListExternalGroupsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListExternalGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListExternalGroupsResponse)
            returned by a previous list external request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
        filter:
          description: |-
            **string**
            A filter expression that filters resources listed in the response.
            The expression must specify:
            1. The fields name or id. Currently you can use filtering only on the [Group.name](#yandex.cloud.organizationmanager.v1.Group) or [Group.id](#yandex.cloud.organizationmanager.v1.Group) fields.
            2. An `=` operator.
            3. The value in double quotes (`"`). Must be 3-63 characters long and match the regular expression `[a-z][-a-z0-9]{1,61}[a-z0-9]`.
            The maximum string length in characters is 1000.
          type: string
      required:
        - subjectContainerId
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.ListExternal

Retrieves the list of external group linked subject container

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListExternalGroupsRequest}

#|
||Field | Description ||
|| subjectContainerId | **string**

Required field. Id of the subject container that external group belongs to.
To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.

The maximum string length in characters is 50. ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`,
the service returns a [ListExternalGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListExternalGroupsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListExternalGroupsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListExternalGroupsResponse)
returned by a previous list external request to get the next page of results.

The maximum string length in characters is 2000. ||
|| filter | **string**

A filter expression that filters resources listed in the response.
The expression must specify:
1. The fields name or id. Currently you can use filtering only on the [Group.name](#yandex.cloud.organizationmanager.v1.Group) or [Group.id](#yandex.cloud.organizationmanager.v1.Group) fields.
2. An `=` operator.
3. The value in double quotes (`"`). Must be 3-63 characters long and match the regular expression `[a-z][-a-z0-9]{1,61}[a-z0-9]`.

The maximum string length in characters is 1000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListExternalGroupsResponse}

**HTTP Code: 200 - OK**

```json
{
  "groups": [
    {
      "id": "string",
      "organizationId": "string",
      "createdAt": "string",
      "name": "string",
      "description": "string",
      "subjectContainerId": "string",
      "externalId": "string",
      "labels": "object"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| groups[] | **[Group](#yandex.cloud.organizationmanager.v1.Group)**

List of External group resources. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListExternalGroupsRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListExternalGroupsRequest), use
the `nextPageToken` as the value
for the [ListExternalGroupsRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListExternalGroupsRequest) query parameter
in the next list request. Each subsequent list request will have its own
`nextPageToken` to continue paging through the results. ||
|#

## Group {#yandex.cloud.organizationmanager.v1.Group}

A Group resource.
For more information, see [Groups](/docs/organization/operations/manage-groups).

#|
||Field | Description ||
|| id | **string**

ID of the group. ||
|| organizationId | **string**

ID of the organization that the group belongs to. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| name | **string**

Name of the group. ||
|| description | **string**

Description of the group. ||
|| subjectContainerId | **string**

Id of the subject container that external group belongs to. It is set if group is external. ||
|| externalId | **string**

Id of the group from external system. It is set if group is external. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/listMembers -->
<!-- file: Group/listMembers.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}:listMembers
    method: get
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the Group resource to list members for.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`, the service returns a [ListGroupMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupMembersResponse)
            that can be used to get the next page of results in subsequent list requests.
            Acceptable values are 0 to 1000, inclusive. Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListGroupMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupMembersResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.ListMembers

List group active members.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}:listMembers
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the Group resource to list members for.

The maximum string length in characters is 50. ||
|#

## Query parameters {#yandex.cloud.organizationmanager.v1.ListGroupMembersRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`, the service returns a [ListGroupMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupMembersResponse)
that can be used to get the next page of results in subsequent list requests.
Acceptable values are 0 to 1000, inclusive. Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListGroupMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupMembersResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListGroupMembersResponse}

**HTTP Code: 200 - OK**

```json
{
  "members": [
    {
      "subjectId": "string",
      "subjectType": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| members[] | **[GroupMember](#yandex.cloud.organizationmanager.v1.GroupMember)**

List of members for the specified group. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListGroupMembersRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListGroupMembersRequest), use the `nextPageToken` as the value
for the [ListGroupMembersRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListGroupMembersRequest) query parameter in the next list request.
Each subsequent list request will have its own `nextPageToken` to continue paging through the results. ||
|#

## GroupMember {#yandex.cloud.organizationmanager.v1.GroupMember}

#|
||Field | Description ||
|| subjectId | **string**

ID of the subject. ||
|| subjectType | **string**

Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex, added to Yandex Cloud.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/listOperations -->
<!-- file: Group/listOperations.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}/operations
    method: get
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the Group resource to list operations for.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`, the service returns a [ListGroupOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupOperationsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListGroupOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupOperationsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.ListOperations

Lists operations for the specified group.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}/operations
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the Group resource to list operations for.

The maximum string length in characters is 50. ||
|#

## Query parameters {#yandex.cloud.organizationmanager.v1.ListGroupOperationsRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`, the service returns a [ListGroupOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupOperationsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListGroupOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListGroupOperationsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListGroupOperationsResponse}

**HTTP Code: 200 - OK**

```json
{
  "operations": [
    {
      "id": "string",
      "description": "string",
      "createdAt": "string",
      "createdBy": "string",
      "modifiedAt": "string",
      "done": "boolean",
      "metadata": "object",
      // Includes only one of the fields `error`, `response`
      "error": {
        "code": "integer",
        "message": "string",
        "details": [
          "object"
        ]
      },
      "response": "object"
      // end of the list of possible fields
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| operations[] | **[Operation](#yandex.cloud.operation.Operation)**

List of operations for the specified group. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListGroupOperationsRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListGroupOperationsRequest), use the `nextPageToken` as the value
for the [ListGroupOperationsRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListGroupOperationsRequest) query parameter in the next list request.
Each subsequent list request will have its own `nextPageToken` to continue paging through the results. ||
|#

## Operation {#yandex.cloud.operation.Operation}

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/resolveExternal -->
<!-- file: Group/resolveExternal.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups/{subjectContainerId}/{externalId}
    method: get
    path:
      type: object
      properties:
        subjectContainerId:
          description: |-
            **string**
            Required field. Id of the subject container that external group belongs to
            To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
            or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.
            The maximum string length in characters is 50.
          type: string
        externalId:
          description: |-
            **string**
            Required field. Id of the group from external system
            The maximum string length in characters is 1024.
          type: string
      required:
        - subjectContainerId
        - externalId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: Group.ResolveExternal

Returns external group by subject container and external id

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/external_groups/{subjectContainerId}/{externalId}
```

## Path parameters

#|
||Field | Description ||
|| subjectContainerId | **string**

Required field. Id of the subject container that external group belongs to
To get subject container, use a [yandex.cloud.organizationmanager.v1.saml.FederationService.List](/docs/organization/saml/api-ref/Federation/list#List) request
or [yandex.cloud.organizationmanager.v1.idp.UserpoolService.List](/docs/organization/idp/api-ref/Userpool/list#List) request.

The maximum string length in characters is 50. ||
|| externalId | **string**

Required field. Id of the group from external system

The maximum string length in characters is 1024. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.Group}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "organizationId": "string",
  "createdAt": "string",
  "name": "string",
  "description": "string",
  "subjectContainerId": "string",
  "externalId": "string",
  "labels": "object"
}
```

A Group resource.
For more information, see [Groups](/docs/organization/operations/manage-groups).

#|
||Field | Description ||
|| id | **string**

ID of the group. ||
|| organizationId | **string**

ID of the organization that the group belongs to. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| name | **string**

Name of the group. ||
|| description | **string**

Description of the group. ||
|| subjectContainerId | **string**

Id of the subject container that external group belongs to. It is set if group is external. ||
|| externalId | **string**

Id of the group from external system. It is set if group is external. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/setAccessBindings -->
<!-- file: Group/setAccessBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{resourceId}:setAccessBindings
    method: post
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access bindings are being set.
            To get the resource ID, use a corresponding List request.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessBindings:
          description: |-
            **[AccessBinding](#yandex.cloud.access.AccessBinding)**
            Access bindings to be set. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings).
            The maximum number of elements is 1000.
          type: array
          items:
            $ref: '#/definitions/AccessBinding'
      additionalProperties: false
    definitions:
      Subject:
        type: object
        properties:
          id:
            description: |-
              **string**
              subject id
            type: string
          type:
            description: |-
              **string**
              subject type
            type: string
      AccessBinding:
        type: object
        properties:
          roleId:
            description: |-
              **string**
              Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the [subject](#yandex.cloud.access.AccessBinding).
              The maximum string length in characters is 64.
            type: string
          subject:
            description: |-
              **[Subject](#yandex.cloud.access.Subject)**
              Required field. Identity for which access binding is being created.
              It can represent an account with a unique ID or several accounts with a system identifier.
            $ref: '#/definitions/Subject'
        required:
          - roleId
          - subject
---

# Identity Hub API, REST: Group.SetAccessBindings

Sets access bindings for the specified group.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{resourceId}:setAccessBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access bindings are being set.
To get the resource ID, use a corresponding List request.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.SetAccessBindingsRequest}

```json
{
  "accessBindings": [
    {
      "roleId": "string",
      "subject": {
        "id": "string",
        "type": "string"
      }
    }
  ]
}
```

#|
||Field | Description ||
|| accessBindings[] | **[AccessBinding](#yandex.cloud.access.AccessBinding)**

Access bindings to be set. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings).

The maximum number of elements is 1000. ||
|#

## AccessBinding {#yandex.cloud.access.AccessBinding}

#|
||Field | Description ||
|| roleId | **string**

Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the `subject`.

The maximum string length in characters is 64. ||
|| subject | **[Subject](#yandex.cloud.access.Subject)**

Required field. Identity for which access binding is being created.
It can represent an account with a unique ID or several accounts with a system identifier. ||
|#

## Subject {#yandex.cloud.access.Subject}

#|
||Field | Description ||
|| id | **string**

Required field. ID of the subject.
It can contain one of the following values:oauth
* `allAuthenticatedUsers`: A special public group that represents anyone
who is authenticated. It can be used only if the `type` is `system`.
* `allUsers`: A special public group that represents anyone. No authentication is required.
For example, you don't need to specify the IAM token in an API query.
It can be used only if the `type` is `system`.
* `group:organization:<id>:users`: A special system group that represents all members of organization
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `group:federation:<id>:users`: A special system group that represents all users of federation
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `<cloud generated id>`: An identifier that represents a user account.
It can be used only if the `type` is `userAccount`, `federatedUser` or `serviceAccount`.

The maximum string length in characters is 100. ||
|| type | **string**

Required field. Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex or Yandex Connect, added to Yandex Cloud.
* `serviceAccount`: A service account. This type represents the [yandex.cloud.iam.v1.ServiceAccount](/docs/iam/api-ref/ServiceAccount/get#yandex.cloud.iam.v1.ServiceAccount) resource.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
* `system`: System group. This type represents several accounts with a common system identifier.
For more information, see [Subject to which the role is assigned](/docs/iam/concepts/access-control/#subject).

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/update -->
<!-- file: Group/update.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}
    method: patch
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the Group resource to update.
            To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        updateMask:
          description: |-
            **string** (field-mask)
            A comma-separated names off ALL fields to be updated.
            Only the specified fields will be changed. The others will be left untouched.
            If the field is specified in `` updateMask `` and no value for that field was sent in the request,
            the field's value will be reset to the default. The default value for most fields is null or 0.
            If `` updateMask `` is not sent in the request, all fields' values will be updated.
            Fields specified in the request will be updated to provided values.
            The rest of the fields will be reset to the default.
          type: string
          format: field-mask
        name:
          description: |-
            **string**
            Name of the group.
            The name must be unique within the organization.
            Value must match the regular expression ` |[a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])? `.
          pattern: '|[a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])?'
          type: string
        description:
          description: |-
            **string**
            Description of the group.
            The maximum string length in characters is 256.
          type: string
        labels:
          description: |-
            **object** (map<**string**, **string**>)
            Resource labels as `key:value` pairs.
            The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource.
          type: object
          additionalProperties:
            type: string
            pattern: '[-_0-9a-z]*'
            maxLength: 63
          propertyNames:
            type: string
            pattern: '[a-z][-_0-9a-z]*'
            maxLength: 63
            minLength: 1
          maxProperties: 64
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Group.Update

Updates the specified group.

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the Group resource to update.
To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateGroupRequest}

```json
{
  "updateMask": "string",
  "name": "string",
  "description": "string",
  "labels": "object"
}
```

#|
||Field | Description ||
|| updateMask | **string** (field-mask)

A comma-separated names off ALL fields to be updated.
Only the specified fields will be changed. The others will be left untouched.
If the field is specified in `` updateMask `` and no value for that field was sent in the request,
the field's value will be reset to the default. The default value for most fields is null or 0.

If `` updateMask `` is not sent in the request, all fields' values will be updated.
Fields specified in the request will be updated to provided values.
The rest of the fields will be reset to the default. ||
|| name | **string**

Name of the group.
The name must be unique within the organization.

Value must match the regular expression ``` |[a-zA-Z]([-a-zA-Z0-9._-]{0,61}[a-zA-Z0-9])? ```. ||
|| description | **string**

Description of the group.

The maximum string length in characters is 256. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `key:value` pairs.

The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/updateAccessBindings -->
<!-- file: Group/updateAccessBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{resourceId}:updateAccessBindings
    method: post
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access bindings are being updated.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessBindingDeltas:
          description: |-
            **[AccessBindingDelta](#yandex.cloud.access.AccessBindingDelta)**
            Updates to access bindings.
            The number of elements must be in the range 1-1000.
          type: array
          items:
            $ref: '#/definitions/AccessBindingDelta'
      additionalProperties: false
    definitions:
      Subject:
        type: object
        properties:
          id:
            description: |-
              **string**
              subject id
            type: string
          type:
            description: |-
              **string**
              subject type
            type: string
      AccessBinding:
        type: object
        properties:
          roleId:
            description: |-
              **string**
              Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the [subject](#yandex.cloud.access.AccessBinding).
              The maximum string length in characters is 64.
            type: string
          subject:
            description: |-
              **[Subject](#yandex.cloud.access.Subject)**
              Required field. Identity for which access binding is being created.
              It can represent an account with a unique ID or several accounts with a system identifier.
            $ref: '#/definitions/Subject'
        required:
          - roleId
          - subject
      AccessBindingDelta:
        type: object
        properties:
          action:
            description: |-
              **enum** (AccessBindingAction)
              Required field. The action that is being performed on an access binding.
              - `ADD`: Addition of an access binding.
              - `REMOVE`: Removal of an access binding.
            type: string
            enum:
              - ACCESS_BINDING_ACTION_UNSPECIFIED
              - ADD
              - REMOVE
          accessBinding:
            description: |-
              **[AccessBinding](#yandex.cloud.access.AccessBinding)**
              Required field. Access binding. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings).
            $ref: '#/definitions/AccessBinding'
        required:
          - action
          - accessBinding
---

# Identity Hub API, REST: Group.UpdateAccessBindings

Updates access bindings for the specified group.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{resourceId}:updateAccessBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access bindings are being updated.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.UpdateAccessBindingsRequest}

```json
{
  "accessBindingDeltas": [
    {
      "action": "string",
      "accessBinding": {
        "roleId": "string",
        "subject": {
          "id": "string",
          "type": "string"
        }
      }
    }
  ]
}
```

#|
||Field | Description ||
|| accessBindingDeltas[] | **[AccessBindingDelta](#yandex.cloud.access.AccessBindingDelta)**

Updates to access bindings.

The number of elements must be in the range 1-1000. ||
|#

## AccessBindingDelta {#yandex.cloud.access.AccessBindingDelta}

#|
||Field | Description ||
|| action | **enum** (AccessBindingAction)

Required field. The action that is being performed on an access binding.

- `ADD`: Addition of an access binding.
- `REMOVE`: Removal of an access binding. ||
|| accessBinding | **[AccessBinding](#yandex.cloud.access.AccessBinding)**

Required field. Access binding. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings). ||
|#

## AccessBinding {#yandex.cloud.access.AccessBinding}

#|
||Field | Description ||
|| roleId | **string**

Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the `subject`.

The maximum string length in characters is 64. ||
|| subject | **[Subject](#yandex.cloud.access.Subject)**

Required field. Identity for which access binding is being created.
It can represent an account with a unique ID or several accounts with a system identifier. ||
|#

## Subject {#yandex.cloud.access.Subject}

#|
||Field | Description ||
|| id | **string**

Required field. ID of the subject.
It can contain one of the following values:oauth
* `allAuthenticatedUsers`: A special public group that represents anyone
who is authenticated. It can be used only if the `type` is `system`.
* `allUsers`: A special public group that represents anyone. No authentication is required.
For example, you don't need to specify the IAM token in an API query.
It can be used only if the `type` is `system`.
* `group:organization:<id>:users`: A special system group that represents all members of organization
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `group:federation:<id>:users`: A special system group that represents all users of federation
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `<cloud generated id>`: An identifier that represents a user account.
It can be used only if the `type` is `userAccount`, `federatedUser` or `serviceAccount`.

The maximum string length in characters is 100. ||
|| type | **string**

Required field. Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex or Yandex Connect, added to Yandex Cloud.
* `serviceAccount`: A service account. This type represents the [yandex.cloud.iam.v1.ServiceAccount](/docs/iam/api-ref/ServiceAccount/get#yandex.cloud.iam.v1.ServiceAccount) resource.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
* `system`: System group. This type represents several accounts with a common system identifier.
For more information, see [Subject to which the role is assigned](/docs/iam/concepts/access-control/#subject).

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Group/updateMembers -->
<!-- file: Group/updateMembers.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}:updateMembers
    method: post
    path:
      type: object
      properties:
        groupId:
          description: |-
            **string**
            Required field. ID of the group to update.
            To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - groupId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        memberDeltas:
          description: |-
            **[MemberDelta](#yandex.cloud.organizationmanager.v1.MemberDelta)**
            Updates to group members.
            The number of elements must be in the range 1-1000.
          type: array
          items:
            $ref: '#/definitions/MemberDelta'
      additionalProperties: false
    definitions:
      MemberDelta:
        type: object
        properties:
          action:
            description: |-
              **enum** (MemberAction)
              Required field. The action that is being performed on a group member.
              - `ADD`: Addition of a group member.
              - `REMOVE`: Removal of a group member.
            type: string
            enum:
              - MEMBER_ACTION_UNSPECIFIED
              - ADD
              - REMOVE
          subjectId:
            description: |-
              **string**
              Required field. ID of the subject that is being added or removed from a group.
              Subject type can be one of following values:
              * `userAccount`: An account on Yandex, added to Yandex Cloud.
              * `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
              The maximum string length in characters is 50.
            type: string
        required:
          - action
          - subjectId
---

# Identity Hub API, REST: Group.UpdateMembers

Update group members.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/groups/{groupId}:updateMembers
```

## Path parameters

#|
||Field | Description ||
|| groupId | **string**

Required field. ID of the group to update.
To get the group ID, use a [GroupService.List](/docs/organization/api-ref/Group/list#List) request.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateGroupMembersRequest}

```json
{
  "memberDeltas": [
    {
      "action": "string",
      "subjectId": "string"
    }
  ]
}
```

#|
||Field | Description ||
|| memberDeltas[] | **[MemberDelta](#yandex.cloud.organizationmanager.v1.MemberDelta)**

Updates to group members.

The number of elements must be in the range 1-1000. ||
|#

## MemberDelta {#yandex.cloud.organizationmanager.v1.MemberDelta}

#|
||Field | Description ||
|| action | **enum** (MemberAction)

Required field. The action that is being performed on a group member.

- `ADD`: Addition of a group member.
- `REMOVE`: Removal of a group member. ||
|| subjectId | **string**

Required field. ID of the subject that is being added or removed from a group.
Subject type can be one of following values:
* `userAccount`: An account on Yandex, added to Yandex Cloud.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/activate -->
<!-- file: MfaEnforcement/activate.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:activate
    method: patch
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.Activate

activates the specified MFA enforcement

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:activate
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/create -->
<!-- file: MfaEnforcement/create.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. organization id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
        acrId:
          description: |-
            **string**
            Required field. acr id for the MFA enforcement. one of 'any-mfa', 'any-except-sms' or 'phr',
            specification https://yandex.cloud/en/docs/organization/concepts/mfa?utm_referrer=https%3A%2F%2Fa.yandex-team.ru%2F#mfa-factors
            The maximum string length in characters is 50.
          type: string
        ttl:
          description: |-
            **string** (duration)
            Required field. the period during which the entered MFA factor will be considered valid and the
            corresponding acr will be regarded as satisfied
          type: string
          format: duration
        status:
          description: |-
            **enum** (Status)
            Required field. the MFA enforcement status
            - `STATUS_ACTIVE`: active
            - `STATUS_INACTIVE`: inactive
          type: string
          enum:
            - STATUS_UNSPECIFIED
            - CREATING
            - ACTIVE
            - SUSPENDED
            - DELETING
        applyAt:
          description: |-
            **string** (date-time)
            the MFA enforcement application start time
            String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
            `0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.
            To work with values in this field, use the APIs described in the
            [Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
            In some languages, built-in datetime utilities do not support nanosecond precision (9 digits).
          type: string
          format: date-time
        enrollWindow:
          description: |-
            **string** (duration)
            Required field. the MFA enforcement enroll window
          type: string
          format: duration
        name:
          description: |-
            **string**
            Required field. the MFA enforcement name
            Value must match the regular expression ` [a-z]([-a-z0-9]{0,61}[a-z0-9])? `.
          pattern: '[a-z]([-a-z0-9]{0,61}[a-z0-9])?'
          type: string
        description:
          description: |-
            **string**
            the MFA enforcement description
            The maximum string length in characters is 256.
          type: string
      required:
        - organizationId
        - acrId
        - ttl
        - status
        - enrollWindow
        - name
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.Create

creates an MFA enforcement in the specified organization

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements
```

## Body parameters {#yandex.cloud.organizationmanager.v1.CreateMfaEnforcementRequest}

```json
{
  "organizationId": "string",
  "acrId": "string",
  "ttl": "string",
  "status": "string",
  "applyAt": "string",
  "enrollWindow": "string",
  "name": "string",
  "description": "string"
}
```

#|
||Field | Description ||
|| organizationId | **string**

Required field. organization id of the MFA enforcement

The maximum string length in characters is 50. ||
|| acrId | **string**

Required field. acr id for the MFA enforcement. one of 'any-mfa', 'any-except-sms' or 'phr',
specification https://yandex.cloud/en/docs/organization/concepts/mfa?utm_referrer=https%3A%2F%2Fa.yandex-team.ru%2F#mfa-factors

The maximum string length in characters is 50. ||
|| ttl | **string** (duration)

Required field. the period during which the entered MFA factor will be considered valid and the
corresponding acr will be regarded as satisfied ||
|| status | **enum** (Status)

Required field. the MFA enforcement status

- `STATUS_ACTIVE`: active
- `STATUS_INACTIVE`: inactive ||
|| applyAt | **string** (date-time)

the MFA enforcement application start time

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| enrollWindow | **string** (duration)

Required field. the MFA enforcement enroll window ||
|| name | **string**

Required field. the MFA enforcement name

Value must match the regular expression ` [a-z]([-a-z0-9]{0,61}[a-z0-9])? `. ||
|| description | **string**

the MFA enforcement description

The maximum string length in characters is 256. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/deactivate -->
<!-- file: MfaEnforcement/deactivate.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:deactivate
    method: patch
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.Deactivate

deactivates the specified MFA enforcement

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:deactivate
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/delete -->
<!-- file: MfaEnforcement/delete.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}
    method: delete
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.Delete

deletes the specified MFA enforcement

## HTTP request

```
DELETE https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/get -->
<!-- file: MfaEnforcement/get.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}
    method: get
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.Get

returns the specified MFA enforcement

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.MfaEnforcement}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "organizationId": "string",
  "acrId": "string",
  "ttl": "string",
  "status": "string",
  "applyAt": "string",
  "enrollWindow": "string",
  "name": "string",
  "description": "string",
  "createdAt": "string"
}
```

MFA enforcement resource

#|
||Field | Description ||
|| id | **string**

id of the MFA enforcement ||
|| organizationId | **string**

organization id of the MFA enforcement ||
|| acrId | **string**

acr id of the MFA enforcement ||
|| ttl | **string** (duration)

the period during which the entered MFA factor is considered valid and the
corresponding acr is regarded as satisfied ||
|| status | **enum** (MfaEnforcementStatus)

MFA enforcement status

- `MFA_ENFORCEMENT_STATUS_ACTIVE`
- `MFA_ENFORCEMENT_STATUS_INACTIVE`
- `MFA_ENFORCEMENT_STATUS_DELETING` ||
|| applyAt | **string** (date-time)

the MFA enforcement application start time.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| enrollWindow | **string** (duration)

the time window during which the user is allowed to create an MFA profile.
this window is measured relative to the MFA enforcement application start time
and the user's most recent successful authentication that falls under the rule
(or the user's creation time, if there has been no authentication). ||
|| name | **string**

name of the MFA enforcement ||
|| description | **string**

description of the MFA enforcement ||
|| createdAt | **string** (date-time)

creation timestamp

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/index -->
<!-- file: MfaEnforcement/index.md -->

---
editable: false
---

# Identity Hub API, REST: MfaEnforcement

a set of methods for managing MFA enforcements

## Methods

#|
||Method | Description ||
|| [Create](create.md) | creates an MFA enforcement in the specified organization ||
|| [Update](update.md) | updates the specified MFA enforcement ||
|| [Activate](activate.md) | activates the specified MFA enforcement ||
|| [Deactivate](deactivate.md) | deactivates the specified MFA enforcement ||
|| [Delete](delete.md) | deletes the specified MFA enforcement ||
|| [Get](get.md) | returns the specified MFA enforcement ||
|| [List](list.md) | returns MFA enforcements for the specified organization ||
|| [UpdateAudience](updateAudience.md) | updates specified MFA enforcement's audience ||
|| [ListAudience](listAudience.md) | returns specified MFA enforcement's audience ||
|| [UpdateExcludedAudience](updateExcludedAudience.md) | updates specified MFA enforcement's excluded audience ||
|| [ListExcludedAudience](listExcludedAudience.md) | returns specified MFA enforcement's excluded audience ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/list -->
<!-- file: MfaEnforcement/list.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements
    method: get
    path: null
    query:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. organization id
            The maximum string length in characters is 50.
          type: string
        pageSize:
          description: |-
            **string** (int64)
            the maximum number of results per page to return
            Acceptable values are 0 to 1000, inclusive.
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            page token
            The maximum string length in characters is 2000.
          type: string
      required:
        - organizationId
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.List

returns MFA enforcements for the specified organization

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListMfaEnforcementsRequest}

#|
||Field | Description ||
|| organizationId | **string**

Required field. organization id

The maximum string length in characters is 50. ||
|| pageSize | **string** (int64)

the maximum number of results per page to return

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

page token

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListMfaEnforcementsResponse}

**HTTP Code: 200 - OK**

```json
{
  "mfaEnforcements": [
    {
      "id": "string",
      "organizationId": "string",
      "acrId": "string",
      "ttl": "string",
      "status": "string",
      "applyAt": "string",
      "enrollWindow": "string",
      "name": "string",
      "description": "string",
      "createdAt": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| mfaEnforcements[] | **[MfaEnforcement](#yandex.cloud.organizationmanager.v1.MfaEnforcement)**

list of MFA enforcements for the specified organization ||
|| nextPageToken | **string**

token to get the next page of results ||
|#

## MfaEnforcement {#yandex.cloud.organizationmanager.v1.MfaEnforcement}

MFA enforcement resource

#|
||Field | Description ||
|| id | **string**

id of the MFA enforcement ||
|| organizationId | **string**

organization id of the MFA enforcement ||
|| acrId | **string**

acr id of the MFA enforcement ||
|| ttl | **string** (duration)

the period during which the entered MFA factor is considered valid and the
corresponding acr is regarded as satisfied ||
|| status | **enum** (MfaEnforcementStatus)

MFA enforcement status

- `MFA_ENFORCEMENT_STATUS_ACTIVE`
- `MFA_ENFORCEMENT_STATUS_INACTIVE`
- `MFA_ENFORCEMENT_STATUS_DELETING` ||
|| applyAt | **string** (date-time)

the MFA enforcement application start time.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| enrollWindow | **string** (duration)

the time window during which the user is allowed to create an MFA profile.
this window is measured relative to the MFA enforcement application start time
and the user's most recent successful authentication that falls under the rule
(or the user's creation time, if there has been no authentication). ||
|| name | **string**

name of the MFA enforcement ||
|| description | **string**

description of the MFA enforcement ||
|| createdAt | **string** (date-time)

creation timestamp

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/listAudience -->
<!-- file: MfaEnforcement/listAudience.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:listAudience
    method: get
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            the maximum number of results per page to return
            Acceptable values are 0 to 1000, inclusive.
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            page token
            The maximum string length in characters is 2000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.ListAudience

returns specified MFA enforcement's audience

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:listAudience
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Query parameters {#yandex.cloud.organizationmanager.v1.ListAudienceRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

the maximum number of results per page to return

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

page token

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListAudienceResponse}

**HTTP Code: 200 - OK**

```json
{
  "subjects": [
    {
      "id": "string",
      "type": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| subjects[] | **[Subject](#yandex.cloud.organizationmanager.v1.ListAudienceResponse.Subject)**

MFA enforcement's audience ||
|| nextPageToken | **string**

token to get the next page of results ||
|#

## Subject {#yandex.cloud.organizationmanager.v1.ListAudienceResponse.Subject}

#|
||Field | Description ||
|| id | **string**

subject id ||
|| type | **string**

subject type ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/listExcludedAudience -->
<!-- file: MfaEnforcement/listExcludedAudience.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:listExcludedAudience
    method: get
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            the maximum number of results per page to return
            Acceptable values are 0 to 1000, inclusive.
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            page token
            The maximum string length in characters is 2000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.ListExcludedAudience

returns specified MFA enforcement's excluded audience

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:listExcludedAudience
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Query parameters {#yandex.cloud.organizationmanager.v1.ListExcludedAudienceRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

the maximum number of results per page to return

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

page token

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListExcludedAudienceResponse}

**HTTP Code: 200 - OK**

```json
{
  "subjects": [
    {
      "id": "string",
      "type": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| subjects[] | **[Subject](#yandex.cloud.organizationmanager.v1.ListExcludedAudienceResponse.Subject)**

MFA enforcement's audience ||
|| nextPageToken | **string**

token to get the next page of results ||
|#

## Subject {#yandex.cloud.organizationmanager.v1.ListExcludedAudienceResponse.Subject}

#|
||Field | Description ||
|| id | **string**

subject id ||
|| type | **string**

subject type ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/update -->
<!-- file: MfaEnforcement/update.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}
    method: patch
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        acrId:
          description: |-
            **string**
            acr id for the MFA enforcement. one of 'any-mfa', 'any-except-sms' or 'phr',
            specification https://yandex.cloud/en/docs/organization/concepts/mfa?utm_referrer=https%3A%2F%2Fa.yandex-team.ru%2F#mfa-factors
            The maximum string length in characters is 50.
          type: string
        ttl:
          description: |-
            **string** (duration)
            the period during which the entered MFA factor will be considered valid and the
            corresponding acr will be regarded as satisfied
          type: string
          format: duration
        status:
          description: |-
            **enum** (Status)
            the MFA enforcement status
            - `STATUS_ACTIVE`: active
            - `STATUS_INACTIVE`: inactive
          type: string
          enum:
            - STATUS_UNSPECIFIED
            - CREATING
            - ACTIVE
            - SUSPENDED
            - DELETING
        applyAt:
          description: |-
            **string** (date-time)
            the MFA enforcement application start time
            String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
            `0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.
            To work with values in this field, use the APIs described in the
            [Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
            In some languages, built-in datetime utilities do not support nanosecond precision (9 digits).
          type: string
          format: date-time
        enrollWindow:
          description: |-
            **string** (duration)
            the MFA enforcement enroll window
          type: string
          format: duration
        updateMask:
          description: |-
            **string** (field-mask)
            A comma-separated names off ALL fields to be updated.
            Only the specified fields will be changed. The others will be left untouched.
            If the field is specified in `` updateMask `` and no value for that field was sent in the request,
            the field's value will be reset to the default. The default value for most fields is null or 0.
            If `` updateMask `` is not sent in the request, all fields' values will be updated.
            Fields specified in the request will be updated to provided values.
            The rest of the fields will be reset to the default.
          type: string
          format: field-mask
        name:
          description: |-
            **string**
            the MFA enforcement name
            Value must match the regular expression ` |[a-z]([-a-z0-9]{0,61}[a-z0-9])? `.
          pattern: '|[a-z]([-a-z0-9]{0,61}[a-z0-9])?'
          type: string
        description:
          description: |-
            **string**
            the MFA enforcement description
            The maximum string length in characters is 256.
          type: string
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: MfaEnforcement.Update

updates the specified MFA enforcement

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateMfaEnforcementRequest}

```json
{
  "acrId": "string",
  "ttl": "string",
  "status": "string",
  "applyAt": "string",
  "enrollWindow": "string",
  "updateMask": "string",
  "name": "string",
  "description": "string"
}
```

#|
||Field | Description ||
|| acrId | **string**

acr id for the MFA enforcement. one of 'any-mfa', 'any-except-sms' or 'phr',
specification https://yandex.cloud/en/docs/organization/concepts/mfa?utm_referrer=https%3A%2F%2Fa.yandex-team.ru%2F#mfa-factors

The maximum string length in characters is 50. ||
|| ttl | **string** (duration)

the period during which the entered MFA factor will be considered valid and the
corresponding acr will be regarded as satisfied ||
|| status | **enum** (Status)

the MFA enforcement status

- `STATUS_ACTIVE`: active
- `STATUS_INACTIVE`: inactive ||
|| applyAt | **string** (date-time)

the MFA enforcement application start time

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| enrollWindow | **string** (duration)

the MFA enforcement enroll window ||
|| updateMask | **string** (field-mask)

A comma-separated names off ALL fields to be updated.
Only the specified fields will be changed. The others will be left untouched.
If the field is specified in `` updateMask `` and no value for that field was sent in the request,
the field's value will be reset to the default. The default value for most fields is null or 0.

If `` updateMask `` is not sent in the request, all fields' values will be updated.
Fields specified in the request will be updated to provided values.
The rest of the fields will be reset to the default. ||
|| name | **string**

the MFA enforcement name

Value must match the regular expression ``` |[a-z]([-a-z0-9]{0,61}[a-z0-9])? ```. ||
|| description | **string**

the MFA enforcement description

The maximum string length in characters is 256. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/updateAudience -->
<!-- file: MfaEnforcement/updateAudience.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:updateAudience
    method: patch
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        audienceDeltas:
          description: |-
            **[AudienceDelta](#yandex.cloud.organizationmanager.v1.AudienceDelta)**
            MFA enforcement's audience to update
            The number of elements must be in the range 1-1000.
          type: array
          items:
            $ref: '#/definitions/AudienceDelta'
      additionalProperties: false
    definitions:
      AudienceDelta:
        type: object
        properties:
          action:
            description: |-
              **enum** (Action)
              Required field. action to perform
              - `ADD`: Group mapping item is to be added
              - `REMOVE`: Group mapping item is to be removed
            type: string
            enum:
              - ACTION_UNSPECIFIED
              - ADD
              - REMOVE
          subjectId:
            description: |-
              **string**
              Required field. subject id
              The maximum string length in characters is 100.
            type: string
        required:
          - action
          - subjectId
---

# Identity Hub API, REST: MfaEnforcement.UpdateAudience

updates specified MFA enforcement's audience

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:updateAudience
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateAudienceRequest}

```json
{
  "audienceDeltas": [
    {
      "action": "string",
      "subjectId": "string"
    }
  ]
}
```

#|
||Field | Description ||
|| audienceDeltas[] | **[AudienceDelta](#yandex.cloud.organizationmanager.v1.AudienceDelta)**

MFA enforcement's audience to update

The number of elements must be in the range 1-1000. ||
|#

## AudienceDelta {#yandex.cloud.organizationmanager.v1.AudienceDelta}

#|
||Field | Description ||
|| action | **enum** (Action)

Required field. action to perform

- `ACTION_ADD`: add subject to audience
- `ACTION_REMOVE`: remove subject from audience ||
|| subjectId | **string**

Required field. subject id

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/MfaEnforcement/updateExcludedAudience -->
<!-- file: MfaEnforcement/updateExcludedAudience.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:updateExcludedAudience
    method: patch
    path:
      type: object
      properties:
        mfaEnforcementId:
          description: |-
            **string**
            Required field. id of the MFA enforcement
            The maximum string length in characters is 50.
          type: string
      required:
        - mfaEnforcementId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        audienceDeltas:
          description: |-
            **[AudienceDelta](#yandex.cloud.organizationmanager.v1.AudienceDelta)**
            updated MFA enforcement's excluded audience
            The number of elements must be in the range 1-1000.
          type: array
          items:
            $ref: '#/definitions/AudienceDelta'
      additionalProperties: false
    definitions:
      AudienceDelta:
        type: object
        properties:
          action:
            description: |-
              **enum** (Action)
              Required field. action to perform
              - `ADD`: Group mapping item is to be added
              - `REMOVE`: Group mapping item is to be removed
            type: string
            enum:
              - ACTION_UNSPECIFIED
              - ADD
              - REMOVE
          subjectId:
            description: |-
              **string**
              Required field. subject id
              The maximum string length in characters is 100.
            type: string
        required:
          - action
          - subjectId
---

# Identity Hub API, REST: MfaEnforcement.UpdateExcludedAudience

updates specified MFA enforcement's excluded audience

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/mfaEnforcements/{mfaEnforcementId}:updateExcludedAudience
```

## Path parameters

#|
||Field | Description ||
|| mfaEnforcementId | **string**

Required field. id of the MFA enforcement

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateExcludedAudienceRequest}

```json
{
  "audienceDeltas": [
    {
      "action": "string",
      "subjectId": "string"
    }
  ]
}
```

#|
||Field | Description ||
|| audienceDeltas[] | **[AudienceDelta](#yandex.cloud.organizationmanager.v1.AudienceDelta)**

updated MFA enforcement's excluded audience

The number of elements must be in the range 1-1000. ||
|#

## AudienceDelta {#yandex.cloud.organizationmanager.v1.AudienceDelta}

#|
||Field | Description ||
|| action | **enum** (Action)

Required field. action to perform

- `ACTION_ADD`: add subject to audience
- `ACTION_REMOVE`: remove subject from audience ||
|| subjectId | **string**

Required field. subject id

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Operation/cancel -->
<!-- file: Operation/cancel.md -->

---
editable: false
apiPlayground:
  - url: https://operation.{{ api-host }}/operations/{operationId}:cancel
    method: get
    path:
      type: object
      properties:
        operationId:
          description: |-
            **string**
            Required field. ID of the operation to cancel.
          type: string
      required:
        - operationId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: Operation.Cancel

Cancels the specified operation.

Note that currently Object Storage API does not support cancelling operations.

## HTTP request

```
GET https://operation.{{ api-host }}/operations/{operationId}:cancel
```

## Path parameters

#|
||Field | Description ||
|| operationId | **string**

Required field. ID of the operation to cancel. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Operation/get -->
<!-- file: Operation/get.md -->

---
editable: false
apiPlayground:
  - url: https://operation.{{ api-host }}/operations/{operationId}
    method: get
    path:
      type: object
      properties:
        operationId:
          description: |-
            **string**
            Required field. ID of the Operation resource to return.
          type: string
      required:
        - operationId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: Operation.Get

Returns the specified Operation resource.

## HTTP request

```
GET https://operation.{{ api-host }}/operations/{operationId}
```

## Path parameters

#|
||Field | Description ||
|| operationId | **string**

Required field. ID of the Operation resource to return. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Operation/index -->
<!-- file: Operation/index.md -->

---
editable: false
---

# Identity Hub API, REST: Operation

A set of methods for managing operations for asynchronous API requests.

## Methods

#|
||Method | Description ||
|| [Get](get.md) | Returns the specified Operation resource. ||
|| [Cancel](cancel.md) | Cancels the specified operation. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/bindAccessPolicy -->
<!-- file: Organization/bindAccessPolicy.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:bindAccessPolicy
    method: post
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access policy bindings are being set.
            To get the resource ID, use a corresponding List request.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessPolicyBinding:
          description: |-
            **[AccessPolicyBinding](#yandex.cloud.access.AccessPolicyBinding)**
            Required field. Access policy binding. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-policies).
          $ref: '#/definitions/AccessPolicyBinding'
      required:
        - accessPolicyBinding
      additionalProperties: false
    definitions:
      AccessPolicyBinding:
        type: object
        properties:
          accessPolicyTemplateId:
            description: |-
              **string**
              Required field. ID of the access policy template being applied.
              The maximum string length in characters is 64.
            type: string
          parameters:
            description: |-
              **object** (map<**string**, **string**>)
              A list of access policy binding parameter KEY=VALUE pairs.
              The maximum string length in characters for each value is 1024. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. No more than 64 per resource.
            type: object
            additionalProperties:
              type: string
              maxLength: 1024
            propertyNames:
              type: string
              pattern: '[a-z][-_0-9a-z]*'
              maxLength: 63
              minLength: 1
            maxProperties: 64
        required:
          - accessPolicyTemplateId
---

# Identity Hub API, REST: Organization.BindAccessPolicy

Binds the access policy template to the organization.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:bindAccessPolicy
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access policy bindings are being set.
To get the resource ID, use a corresponding List request.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.BindAccessPolicyRequest}

```json
{
  "accessPolicyBinding": {
    "accessPolicyTemplateId": "string",
    "parameters": "object"
  }
}
```

#|
||Field | Description ||
|| accessPolicyBinding | **[AccessPolicyBinding](#yandex.cloud.access.AccessPolicyBinding)**

Required field. Access policy binding. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-policies). ||
|#

## AccessPolicyBinding {#yandex.cloud.access.AccessPolicyBinding}

#|
||Field | Description ||
|| accessPolicyTemplateId | **string**

Required field. ID of the access policy template being applied.

The maximum string length in characters is 64. ||
|| parameters | **object** (map<**string**, **string**>)

A list of access policy binding parameter KEY=VALUE pairs.

The maximum string length in characters for each value is 1024. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. No more than 64 per resource. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/get -->
<!-- file: Organization/get.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}
    method: get
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the Organization resource to return.
            To get the organization ID, use a [OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: Organization.Get

Returns the specified Organization resource.
To get the list of available Organization resources, make a [List](/docs/organization/api-ref/Organization/list#List) request.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the Organization resource to return.
To get the organization ID, use a [OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.Organization}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "createdAt": "string",
  "name": "string",
  "description": "string",
  "title": "string",
  "labels": "object"
}
```

An Organization resource. For more information, see [Organization](/docs/organization/enable-org).

#|
||Field | Description ||
|| id | **string**

ID of the organization. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| name | **string**

Name of the organization. 3-63 characters long. ||
|| description | **string**

Description of the organization. 0-256 characters long. ||
|| title | **string**

Display name of the organization. 0-256 characters long. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `` key:value `` pairs. Maximum of 64 per resource. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/index -->
<!-- file: Organization/index.md -->

---
editable: false
---

# Identity Hub API, REST: Organization

A set of methods for managing Organization resources.

## Methods

#|
||Method | Description ||
|| [Get](get.md) | Returns the specified Organization resource. ||
|| [List](list.md) | Retrieves the list of Organization resources. ||
|| [Update](update.md) | Updates the specified organization. ||
|| [ListOperations](listOperations.md) | Lists operations for the specified organization. ||
|| [ListAccessBindings](listAccessBindings.md) | Lists access bindings for the specified organization. ||
|| [SetAccessBindings](setAccessBindings.md) | Sets access bindings for the specified organization. ||
|| [UpdateAccessBindings](updateAccessBindings.md) | Updates access bindings for the specified organization. ||
|| [ListAccessPolicyBindings](listAccessPolicyBindings.md) | Returns list of access policy bindings for the organization. ||
|| [BindAccessPolicy](bindAccessPolicy.md) | Binds the access policy template to the organization. ||
|| [UnbindAccessPolicy](unbindAccessPolicy.md) | Unbinds the access policy template from the organization. ||
|| [UpdateAccessPolicyBindingParameters](updateAccessPolicyBindingParameters.md) | Updates the access policy binding parameters for the organization. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/list -->
<!-- file: Organization/list.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations
    method: get
    path: null
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`,
            the service returns a [ListOrganizationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListOrganizationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
        filter:
          description: |-
            **string**
            A filter expression that filters resources listed in the response.
            The expression must specify:
            1. The field name. Currently you can use filtering only on the [Organization.name](#yandex.cloud.organizationmanager.v1.Organization) field.
            2. An `=` operator.
            3. The value in double quotes (`"`). Must be 3-63 characters long and match the regular expression `[a-z][-a-z0-9]{1,61}[a-z0-9]`.
            The maximum string length in characters is 1000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Organization.List

Retrieves the list of Organization resources.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListOrganizationsRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`,
the service returns a [ListOrganizationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListOrganizationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|| filter | **string**

A filter expression that filters resources listed in the response.
The expression must specify:
1. The field name. Currently you can use filtering only on the [Organization.name](#yandex.cloud.organizationmanager.v1.Organization) field.
2. An `=` operator.
3. The value in double quotes (`"`). Must be 3-63 characters long and match the regular expression `[a-z][-a-z0-9]{1,61}[a-z0-9]`.

The maximum string length in characters is 1000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListOrganizationsResponse}

**HTTP Code: 200 - OK**

```json
{
  "organizations": [
    {
      "id": "string",
      "createdAt": "string",
      "name": "string",
      "description": "string",
      "title": "string",
      "labels": "object"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| organizations[] | **[Organization](#yandex.cloud.organizationmanager.v1.Organization)**

List of Organization resources. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListOrganizationsRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListOrganizationsRequest), use
the `nextPageToken` as the value
for the [ListOrganizationsRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationsRequest) query parameter
in the next list request. Each subsequent list request will have its own
`nextPageToken` to continue paging through the results. ||
|#

## Organization {#yandex.cloud.organizationmanager.v1.Organization}

An Organization resource. For more information, see [Organization](/docs/organization/enable-org).

#|
||Field | Description ||
|| id | **string**

ID of the organization. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| name | **string**

Name of the organization. 3-63 characters long. ||
|| description | **string**

Description of the organization. 0-256 characters long. ||
|| title | **string**

Display name of the organization. 0-256 characters long. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `` key:value `` pairs. Maximum of 64 per resource. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/listAccessBindings -->
<!-- file: Organization/listAccessBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:listAccessBindings
    method: get
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource to list access bindings for.
            To get the resource ID, use a corresponding List request.
            For example, use the [yandex.cloud.resourcemanager.v1.CloudService.List](/docs/resource-manager/api-ref/Cloud/list#List) request to get the Cloud resource ID.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page that should be returned. If the number of available
            results is larger than `pageSize`,
            the service returns a [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 100.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Organization.ListAccessBindings

Lists access bindings for the specified organization.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:listAccessBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource to list access bindings for.
To get the resource ID, use a corresponding List request.
For example, use the [yandex.cloud.resourcemanager.v1.CloudService.List](/docs/resource-manager/api-ref/Cloud/list#List) request to get the Cloud resource ID.

The maximum string length in characters is 64. ||
|#

## Query parameters {#yandex.cloud.access.ListAccessBindingsRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page that should be returned. If the number of available
results is larger than `pageSize`,
the service returns a [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListAccessBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessBindingsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.access.ListAccessBindingsResponse}

**HTTP Code: 200 - OK**

```json
{
  "accessBindings": [
    {
      "roleId": "string",
      "subject": {
        "id": "string",
        "type": "string"
      }
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| accessBindings[] | **[AccessBinding](#yandex.cloud.access.AccessBinding)**

List of access bindings for the specified resource. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListAccessBindingsRequest.pageSize](#yandex.cloud.access.ListAccessBindingsRequest), use
the `nextPageToken` as the value
for the [ListAccessBindingsRequest.pageToken](#yandex.cloud.access.ListAccessBindingsRequest) query parameter
in the next list request. Each subsequent list request will have its own
`nextPageToken` to continue paging through the results. ||
|#

## AccessBinding {#yandex.cloud.access.AccessBinding}

#|
||Field | Description ||
|| roleId | **string**

Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the `subject`.

The maximum string length in characters is 64. ||
|| subject | **[Subject](#yandex.cloud.access.Subject)**

Required field. Identity for which access binding is being created.
It can represent an account with a unique ID or several accounts with a system identifier. ||
|#

## Subject {#yandex.cloud.access.Subject}

#|
||Field | Description ||
|| id | **string**

Required field. ID of the subject.
It can contain one of the following values:oauth
* `allAuthenticatedUsers`: A special public group that represents anyone
who is authenticated. It can be used only if the `type` is `system`.
* `allUsers`: A special public group that represents anyone. No authentication is required.
For example, you don't need to specify the IAM token in an API query.
It can be used only if the `type` is `system`.
* `group:organization:<id>:users`: A special system group that represents all members of organization
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `group:federation:<id>:users`: A special system group that represents all users of federation
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `<cloud generated id>`: An identifier that represents a user account.
It can be used only if the `type` is `userAccount`, `federatedUser` or `serviceAccount`.

The maximum string length in characters is 100. ||
|| type | **string**

Required field. Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex or Yandex Connect, added to Yandex Cloud.
* `serviceAccount`: A service account. This type represents the [yandex.cloud.iam.v1.ServiceAccount](/docs/iam/api-ref/ServiceAccount/get#yandex.cloud.iam.v1.ServiceAccount) resource.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
* `system`: System group. This type represents several accounts with a common system identifier.
For more information, see [Subject to which the role is assigned](/docs/iam/concepts/access-control/#subject).

The maximum string length in characters is 100. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/listAccessPolicyBindings -->
<!-- file: Organization/listAccessPolicyBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:listAccessPolicyBindings
    method: get
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource to list access policy bindings for.
            To get the resource ID, use a corresponding List request.
            For example, use the [yandex.cloud.resourcemanager.v1.CloudService.List](/docs/resource-manager/api-ref/Cloud/list#List) request to get the Cloud resource ID.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page that should be returned.
            If the number of available results is larger than `pageSize`, the service returns a
            [ListAccessPolicyBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessPolicyBindingsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken` to the
            [ListAccessPolicyBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessPolicyBindingsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 100.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Organization.ListAccessPolicyBindings

Returns list of access policy bindings for the organization.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:listAccessPolicyBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource to list access policy bindings for.
To get the resource ID, use a corresponding List request.
For example, use the [yandex.cloud.resourcemanager.v1.CloudService.List](/docs/resource-manager/api-ref/Cloud/list#List) request to get the Cloud resource ID.

The maximum string length in characters is 64. ||
|#

## Query parameters {#yandex.cloud.access.ListAccessPolicyBindingsRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page that should be returned.
If the number of available results is larger than `pageSize`, the service returns a
[ListAccessPolicyBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessPolicyBindingsResponse)
that can be used to get the next page of results in subsequent list requests.
Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken` to the
[ListAccessPolicyBindingsResponse.nextPageToken](#yandex.cloud.access.ListAccessPolicyBindingsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.access.ListAccessPolicyBindingsResponse}

**HTTP Code: 200 - OK**

```json
{
  "accessPolicyBindings": [
    {
      "accessPolicyTemplateId": "string",
      "parameters": "object"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| accessPolicyBindings[] | **[AccessPolicyBinding](#yandex.cloud.access.AccessPolicyBinding)**

List of access policy bindings for the specified resource. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests.
If the number of results is larger than
[ListAccessPolicyBindingsRequest.pageSize](#yandex.cloud.access.ListAccessPolicyBindingsRequest)
, use the `nextPageToken` as the value for the
[ListAccessPolicyBindingsRequest.pageToken](#yandex.cloud.access.ListAccessPolicyBindingsRequest)
query parameter in the next list request. Each subsequent list request will have its own
`nextPageToken` to continue paging through the results. ||
|#

## AccessPolicyBinding {#yandex.cloud.access.AccessPolicyBinding}

#|
||Field | Description ||
|| accessPolicyTemplateId | **string**

Required field. ID of the access policy template being applied.

The maximum string length in characters is 64. ||
|| parameters | **object** (map<**string**, **string**>)

A list of access policy binding parameter KEY=VALUE pairs.

The maximum string length in characters for each value is 1024. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. No more than 64 per resource. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/listOperations -->
<!-- file: Organization/listOperations.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/operations
    method: get
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the Organization resource to list operations for.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`, the service returns a [ListOrganizationOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsResponse)
            that can be used to get the next page of results in subsequent list requests.
            Acceptable values are 0 to 1000, inclusive. Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListOrganizationOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: Organization.ListOperations

Lists operations for the specified organization.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/operations
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the Organization resource to list operations for.

The maximum string length in characters is 50. ||
|#

## Query parameters {#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`, the service returns a [ListOrganizationOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsResponse)
that can be used to get the next page of results in subsequent list requests.
Acceptable values are 0 to 1000, inclusive. Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListOrganizationOperationsResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsResponse}

**HTTP Code: 200 - OK**

```json
{
  "operations": [
    {
      "id": "string",
      "description": "string",
      "createdAt": "string",
      "createdBy": "string",
      "modifiedAt": "string",
      "done": "boolean",
      "metadata": "object",
      // Includes only one of the fields `error`, `response`
      "error": {
        "code": "integer",
        "message": "string",
        "details": [
          "object"
        ]
      },
      "response": "object"
      // end of the list of possible fields
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| operations[] | **[Operation](#yandex.cloud.operation.Operation)**

List of operations for the specified organization. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListOrganizationOperationsRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsRequest), use the `nextPageToken` as the value
for the [ListOrganizationOperationsRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListOrganizationOperationsRequest) query parameter in the next list request.
Each subsequent list request will have its own `nextPageToken` to continue paging through the results. ||
|#

## Operation {#yandex.cloud.operation.Operation}

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/setAccessBindings -->
<!-- file: Organization/setAccessBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:setAccessBindings
    method: post
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access bindings are being set.
            To get the resource ID, use a corresponding List request.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessBindings:
          description: |-
            **[AccessBinding](#yandex.cloud.access.AccessBinding)**
            Access bindings to be set. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings).
            The maximum number of elements is 1000.
          type: array
          items:
            $ref: '#/definitions/AccessBinding'
      additionalProperties: false
    definitions:
      Subject:
        type: object
        properties:
          id:
            description: |-
              **string**
              subject id
            type: string
          type:
            description: |-
              **string**
              subject type
            type: string
      AccessBinding:
        type: object
        properties:
          roleId:
            description: |-
              **string**
              Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the [subject](#yandex.cloud.access.AccessBinding).
              The maximum string length in characters is 64.
            type: string
          subject:
            description: |-
              **[Subject](#yandex.cloud.access.Subject)**
              Required field. Identity for which access binding is being created.
              It can represent an account with a unique ID or several accounts with a system identifier.
            $ref: '#/definitions/Subject'
        required:
          - roleId
          - subject
---

# Identity Hub API, REST: Organization.SetAccessBindings

Sets access bindings for the specified organization.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:setAccessBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access bindings are being set.
To get the resource ID, use a corresponding List request.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.SetAccessBindingsRequest}

```json
{
  "accessBindings": [
    {
      "roleId": "string",
      "subject": {
        "id": "string",
        "type": "string"
      }
    }
  ]
}
```

#|
||Field | Description ||
|| accessBindings[] | **[AccessBinding](#yandex.cloud.access.AccessBinding)**

Access bindings to be set. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings).

The maximum number of elements is 1000. ||
|#

## AccessBinding {#yandex.cloud.access.AccessBinding}

#|
||Field | Description ||
|| roleId | **string**

Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the `subject`.

The maximum string length in characters is 64. ||
|| subject | **[Subject](#yandex.cloud.access.Subject)**

Required field. Identity for which access binding is being created.
It can represent an account with a unique ID or several accounts with a system identifier. ||
|#

## Subject {#yandex.cloud.access.Subject}

#|
||Field | Description ||
|| id | **string**

Required field. ID of the subject.
It can contain one of the following values:oauth
* `allAuthenticatedUsers`: A special public group that represents anyone
who is authenticated. It can be used only if the `type` is `system`.
* `allUsers`: A special public group that represents anyone. No authentication is required.
For example, you don't need to specify the IAM token in an API query.
It can be used only if the `type` is `system`.
* `group:organization:<id>:users`: A special system group that represents all members of organization
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `group:federation:<id>:users`: A special system group that represents all users of federation
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `<cloud generated id>`: An identifier that represents a user account.
It can be used only if the `type` is `userAccount`, `federatedUser` or `serviceAccount`.

The maximum string length in characters is 100. ||
|| type | **string**

Required field. Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex or Yandex Connect, added to Yandex Cloud.
* `serviceAccount`: A service account. This type represents the [yandex.cloud.iam.v1.ServiceAccount](/docs/iam/api-ref/ServiceAccount/get#yandex.cloud.iam.v1.ServiceAccount) resource.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
* `system`: System group. This type represents several accounts with a common system identifier.
For more information, see [Subject to which the role is assigned](/docs/iam/concepts/access-control/#subject).

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/unbindAccessPolicy -->
<!-- file: Organization/unbindAccessPolicy.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:unbindAccessPolicy
    method: post
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access policy bindings are being removed.
            To get the resource ID, use a corresponding List request.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessPolicyTemplateId:
          description: |-
            **string**
            Required field. ID of the access policy.
          type: string
      required:
        - accessPolicyTemplateId
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Organization.UnbindAccessPolicy

Unbinds the access policy template from the organization.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:unbindAccessPolicy
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access policy bindings are being removed.
To get the resource ID, use a corresponding List request.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.UnbindAccessPolicyRequest}

```json
{
  "accessPolicyTemplateId": "string"
}
```

#|
||Field | Description ||
|| accessPolicyTemplateId | **string**

Required field. ID of the access policy. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/update -->
<!-- file: Organization/update.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}
    method: patch
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the organization to update.
            To get the organization ID, use a [OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        updateMask:
          description: |-
            **string** (field-mask)
            A comma-separated names off ALL fields to be updated.
            Only the specified fields will be changed. The others will be left untouched.
            If the field is specified in `` updateMask `` and no value for that field was sent in the request,
            the field's value will be reset to the default. The default value for most fields is null or 0.
            If `` updateMask `` is not sent in the request, all fields' values will be updated.
            Fields specified in the request will be updated to provided values.
            The rest of the fields will be reset to the default.
          type: string
          format: field-mask
        name:
          description: |-
            **string**
            Name of the organization.
            Value must match the regular expression ` |[a-z]([-a-z0-9]{0,61}[a-z0-9])? `.
          pattern: '|[a-z]([-a-z0-9]{0,61}[a-z0-9])?'
          type: string
        description:
          description: |-
            **string**
            Description of the organization.
            The maximum string length in characters is 256.
          type: string
        title:
          description: |-
            **string**
            Display name of the organization.
            The maximum string length in characters is 256.
          type: string
        labels:
          description: |-
            **object** (map<**string**, **string**>)
            Resource labels as `` key:value `` pairs.
            The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource.
          type: object
          additionalProperties:
            type: string
            pattern: '[-_0-9a-z]*'
            maxLength: 63
          propertyNames:
            type: string
            pattern: '[a-z][-_0-9a-z]*'
            maxLength: 63
            minLength: 1
          maxProperties: 64
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: Organization.Update

Updates the specified organization.

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the organization to update.
To get the organization ID, use a [OrganizationService.List](/docs/organization/api-ref/Organization/list#List) request.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateOrganizationRequest}

```json
{
  "updateMask": "string",
  "name": "string",
  "description": "string",
  "title": "string",
  "labels": "object"
}
```

#|
||Field | Description ||
|| updateMask | **string** (field-mask)

A comma-separated names off ALL fields to be updated.
Only the specified fields will be changed. The others will be left untouched.
If the field is specified in `` updateMask `` and no value for that field was sent in the request,
the field's value will be reset to the default. The default value for most fields is null or 0.

If `` updateMask `` is not sent in the request, all fields' values will be updated.
Fields specified in the request will be updated to provided values.
The rest of the fields will be reset to the default. ||
|| name | **string**

Name of the organization.

Value must match the regular expression ``` |[a-z]([-a-z0-9]{0,61}[a-z0-9])? ```. ||
|| description | **string**

Description of the organization.

The maximum string length in characters is 256. ||
|| title | **string**

Display name of the organization.

The maximum string length in characters is 256. ||
|| labels | **object** (map<**string**, **string**>)

Resource labels as `` key:value `` pairs.

The maximum string length in characters for each value is 63. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. Each value must match the regular expression ` [-_0-9a-z]* `. No more than 64 per resource. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/updateAccessBindings -->
<!-- file: Organization/updateAccessBindings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:updateAccessBindings
    method: post
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access bindings are being updated.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessBindingDeltas:
          description: |-
            **[AccessBindingDelta](#yandex.cloud.access.AccessBindingDelta)**
            Updates to access bindings.
            The number of elements must be in the range 1-1000.
          type: array
          items:
            $ref: '#/definitions/AccessBindingDelta'
      additionalProperties: false
    definitions:
      Subject:
        type: object
        properties:
          id:
            description: |-
              **string**
              subject id
            type: string
          type:
            description: |-
              **string**
              subject type
            type: string
      AccessBinding:
        type: object
        properties:
          roleId:
            description: |-
              **string**
              Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the [subject](#yandex.cloud.access.AccessBinding).
              The maximum string length in characters is 64.
            type: string
          subject:
            description: |-
              **[Subject](#yandex.cloud.access.Subject)**
              Required field. Identity for which access binding is being created.
              It can represent an account with a unique ID or several accounts with a system identifier.
            $ref: '#/definitions/Subject'
        required:
          - roleId
          - subject
      AccessBindingDelta:
        type: object
        properties:
          action:
            description: |-
              **enum** (AccessBindingAction)
              Required field. The action that is being performed on an access binding.
              - `ADD`: Addition of an access binding.
              - `REMOVE`: Removal of an access binding.
            type: string
            enum:
              - ACCESS_BINDING_ACTION_UNSPECIFIED
              - ADD
              - REMOVE
          accessBinding:
            description: |-
              **[AccessBinding](#yandex.cloud.access.AccessBinding)**
              Required field. Access binding. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings).
            $ref: '#/definitions/AccessBinding'
        required:
          - action
          - accessBinding
---

# Identity Hub API, REST: Organization.UpdateAccessBindings

Updates access bindings for the specified organization.

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:updateAccessBindings
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access bindings are being updated.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.UpdateAccessBindingsRequest}

```json
{
  "accessBindingDeltas": [
    {
      "action": "string",
      "accessBinding": {
        "roleId": "string",
        "subject": {
          "id": "string",
          "type": "string"
        }
      }
    }
  ]
}
```

#|
||Field | Description ||
|| accessBindingDeltas[] | **[AccessBindingDelta](#yandex.cloud.access.AccessBindingDelta)**

Updates to access bindings.

The number of elements must be in the range 1-1000. ||
|#

## AccessBindingDelta {#yandex.cloud.access.AccessBindingDelta}

#|
||Field | Description ||
|| action | **enum** (AccessBindingAction)

Required field. The action that is being performed on an access binding.

- `ADD`: Addition of an access binding.
- `REMOVE`: Removal of an access binding. ||
|| accessBinding | **[AccessBinding](#yandex.cloud.access.AccessBinding)**

Required field. Access binding. For more information, see [Access Bindings](/docs/iam/concepts/access-control/#access-bindings). ||
|#

## AccessBinding {#yandex.cloud.access.AccessBinding}

#|
||Field | Description ||
|| roleId | **string**

Required field. ID of the [yandex.cloud.iam.v1.Role](/docs/iam/api-ref/Role/get#yandex.cloud.iam.v1.Role) that is assigned to the `subject`.

The maximum string length in characters is 64. ||
|| subject | **[Subject](#yandex.cloud.access.Subject)**

Required field. Identity for which access binding is being created.
It can represent an account with a unique ID or several accounts with a system identifier. ||
|#

## Subject {#yandex.cloud.access.Subject}

#|
||Field | Description ||
|| id | **string**

Required field. ID of the subject.
It can contain one of the following values:oauth
* `allAuthenticatedUsers`: A special public group that represents anyone
who is authenticated. It can be used only if the `type` is `system`.
* `allUsers`: A special public group that represents anyone. No authentication is required.
For example, you don't need to specify the IAM token in an API query.
It can be used only if the `type` is `system`.
* `group:organization:<id>:users`: A special system group that represents all members of organization
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `group:federation:<id>:users`: A special system group that represents all users of federation
with given &lt;id&gt;. It can be used only if the `type` is `system`.
* `<cloud generated id>`: An identifier that represents a user account.
It can be used only if the `type` is `userAccount`, `federatedUser` or `serviceAccount`.

The maximum string length in characters is 100. ||
|| type | **string**

Required field. Type of the subject.
It can contain one of the following values:
* `userAccount`: An account on Yandex or Yandex Connect, added to Yandex Cloud.
* `serviceAccount`: A service account. This type represents the [yandex.cloud.iam.v1.ServiceAccount](/docs/iam/api-ref/ServiceAccount/get#yandex.cloud.iam.v1.ServiceAccount) resource.
* `federatedUser`: A federated account. This type represents a user from an identity federation, like Active Directory.
* `system`: System group. This type represents several accounts with a common system identifier.
For more information, see [Subject to which the role is assigned](/docs/iam/concepts/access-control/#subject).

The maximum string length in characters is 100. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/Organization/updateAccessPolicyBindingParameters -->
<!-- file: Organization/updateAccessPolicyBindingParameters.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:updateAccessPolicyBindingParameters
    method: patch
    path:
      type: object
      properties:
        resourceId:
          description: |-
            **string**
            Required field. ID of the resource for which access policy bindings are being updated.
            The maximum string length in characters is 64.
          type: string
      required:
        - resourceId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        accessPolicyBinding:
          description: |-
            **[AccessPolicyBinding](#yandex.cloud.access.AccessPolicyBinding)**
            Required field. Identity for which access policy binding is being updated.
          $ref: '#/definitions/AccessPolicyBinding'
      required:
        - accessPolicyBinding
      additionalProperties: false
    definitions:
      AccessPolicyBinding:
        type: object
        properties:
          accessPolicyTemplateId:
            description: |-
              **string**
              Required field. ID of the access policy template being applied.
              The maximum string length in characters is 64.
            type: string
          parameters:
            description: |-
              **object** (map<**string**, **string**>)
              A list of access policy binding parameter KEY=VALUE pairs.
              The maximum string length in characters for each value is 1024. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. No more than 64 per resource.
            type: object
            additionalProperties:
              type: string
              maxLength: 1024
            propertyNames:
              type: string
              pattern: '[a-z][-_0-9a-z]*'
              maxLength: 63
              minLength: 1
            maxProperties: 64
        required:
          - accessPolicyTemplateId
---

# Identity Hub API, REST: Organization.UpdateAccessPolicyBindingParameters

Updates the access policy binding parameters for the organization.

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{resourceId}:updateAccessPolicyBindingParameters
```

## Path parameters

#|
||Field | Description ||
|| resourceId | **string**

Required field. ID of the resource for which access policy bindings are being updated.

The maximum string length in characters is 64. ||
|#

## Body parameters {#yandex.cloud.access.UpdateAccessPolicyBindingParametersRequest}

```json
{
  "accessPolicyBinding": {
    "accessPolicyTemplateId": "string",
    "parameters": "object"
  }
}
```

#|
||Field | Description ||
|| accessPolicyBinding | **[AccessPolicyBinding](#yandex.cloud.access.AccessPolicyBinding)**

Required field. Identity for which access policy binding is being updated. ||
|#

## AccessPolicyBinding {#yandex.cloud.access.AccessPolicyBinding}

#|
||Field | Description ||
|| accessPolicyTemplateId | **string**

Required field. ID of the access policy template being applied.

The maximum string length in characters is 64. ||
|| parameters | **object** (map<**string**, **string**>)

A list of access policy binding parameter KEY=VALUE pairs.

The maximum string length in characters for each value is 1024. The string length in characters for each key must be 1-63. Each key must match the regular expression ` [a-z][-_0-9a-z]* `. No more than 64 per resource. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/createProfile -->
<!-- file: OsLogin/createProfile.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
        subjectId:
          description: |-
            **string**
            The maximum string length in characters is 50.
          type: string
        login:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 32. Value must match the regular expression ` ^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,31}$ `.
          pattern: ^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,31}$
          type: string
        uid:
          description: |-
            **string** (int64)
            1000 - 2^63 - 1
            Acceptable values are 1000 to 9223372036854775807, inclusive.
          type: string
          format: int64
        homeDirectory:
          description: |-
            **string**
            The maximum string length in characters is 255.
          type: string
        shell:
          description: |-
            **string**
            The maximum string length in characters is 255.
          type: string
      required:
        - organizationId
        - login
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: OsLogin.CreateProfile

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles
```

## Body parameters {#yandex.cloud.organizationmanager.v1.CreateOsLoginProfileRequest}

```json
{
  "organizationId": "string",
  "subjectId": "string",
  "login": "string",
  "uid": "string",
  "homeDirectory": "string",
  "shell": "string"
}
```

#|
||Field | Description ||
|| organizationId | **string**

Required field.

The maximum string length in characters is 50. ||
|| subjectId | **string**

The maximum string length in characters is 50. ||
|| login | **string**

Required field.

The maximum string length in characters is 32. Value must match the regular expression ` ^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,31}$ `. ||
|| uid | **string** (int64)

1000 - 2^63 - 1

Acceptable values are 1000 to 9223372036854775807, inclusive. ||
|| homeDirectory | **string**

The maximum string length in characters is 255. ||
|| shell | **string**

The maximum string length in characters is 255. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/deleteProfile -->
<!-- file: OsLogin/deleteProfile.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{id}
    method: delete
    path:
      type: object
      properties:
        id:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - id
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: OsLogin.DeleteProfile

## HTTP request

```
DELETE https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{id}
```

## Path parameters

#|
||Field | Description ||
|| id | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/getProfile -->
<!-- file: OsLogin/getProfile.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{osLoginProfileId}
    method: get
    path:
      type: object
      properties:
        osLoginProfileId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - osLoginProfileId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: OsLogin.GetProfile

OsLogin Profiles

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{osLoginProfileId}
```

## Path parameters

#|
||Field | Description ||
|| osLoginProfileId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.OsLoginProfile}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "organizationId": "string",
  "subjectId": "string",
  "login": "string",
  "uid": "string",
  "isDefault": "boolean",
  "homeDirectory": "string",
  "shell": "string"
}
```

#|
||Field | Description ||
|| id | **string** ||
|| organizationId | **string** ||
|| subjectId | **string** ||
|| login | **string** ||
|| uid | **string** (int64) ||
|| isDefault | **boolean** ||
|| homeDirectory | **string** ||
|| shell | **string** ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/getSettings -->
<!-- file: OsLogin/getSettings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/osLoginSettings
    method: get
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: OsLogin.GetSettings

OsLogin settings

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/osLoginSettings
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.OsLoginSettings}

**HTTP Code: 200 - OK**

```json
{
  "userSshKeySettings": {
    "enabled": "boolean",
    "allowManageOwnKeys": "boolean"
  },
  "sshCertificateSettings": {
    "enabled": "boolean"
  }
}
```

#|
||Field | Description ||
|| userSshKeySettings | **[UserSshKeySettings](#yandex.cloud.organizationmanager.v1.UserSshKeySettings)** ||
|| sshCertificateSettings | **[SshCertificateSettings](#yandex.cloud.organizationmanager.v1.SshCertificateSettings)** ||
|#

## UserSshKeySettings {#yandex.cloud.organizationmanager.v1.UserSshKeySettings}

#|
||Field | Description ||
|| enabled | **boolean** ||
|| allowManageOwnKeys | **boolean** ||
|#

## SshCertificateSettings {#yandex.cloud.organizationmanager.v1.SshCertificateSettings}

#|
||Field | Description ||
|| enabled | **boolean** ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/index -->
<!-- file: OsLogin/index.md -->

---
editable: false
---

# Identity Hub API, REST: OsLogin

## Methods

#|
||Method | Description ||
|| [GetSettings](getSettings.md) | OsLogin settings ||
|| [UpdateSettings](updateSettings.md) |  ||
|| [GetProfile](getProfile.md) | OsLogin Profiles ||
|| [ListProfiles](listProfiles.md) |  ||
|| [CreateProfile](createProfile.md) |  ||
|| [UpdateProfile](updateProfile.md) |  ||
|| [SetDefaultProfile](setDefaultProfile.md) | Sets a profile as a default for the subject assigned to this profile ||
|| [DeleteProfile](deleteProfile.md) |  ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/listProfiles -->
<!-- file: OsLogin/listProfiles.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles
    method: get
    path: null
    query:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
        pageSize:
          description: |-
            **string** (int64)
            Acceptable values are 0 to 1000, inclusive.
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            The maximum string length in characters is 2000.
          type: string
        filter:
          description: |-
            **string**
            A filter expression that filters profiles listed in the response.
            The expression must specify:
            1. The field name. Currently you can use filtering by subject_id, uid or login.
            2. An `=` operator.
            3. The value in double quotes (`"`).
            E.g. login="example-login"
            The maximum string length in characters is 1000.
          type: string
      required:
        - organizationId
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: OsLogin.ListProfiles

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListOsLoginProfilesRequest}

#|
||Field | Description ||
|| organizationId | **string**

Required field.

The maximum string length in characters is 50. ||
|| pageSize | **string** (int64)

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

The maximum string length in characters is 2000. ||
|| filter | **string**

A filter expression that filters profiles listed in the response.
The expression must specify:
1. The field name. Currently you can use filtering by subject_id, uid or login.
2. An `=` operator.
3. The value in double quotes (`"`).
E.g. login="example-login"

The maximum string length in characters is 1000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListOsLoginProfilesResponse}

**HTTP Code: 200 - OK**

```json
{
  "profiles": [
    {
      "id": "string",
      "organizationId": "string",
      "subjectId": "string",
      "login": "string",
      "uid": "string",
      "isDefault": "boolean",
      "homeDirectory": "string",
      "shell": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| profiles[] | **[OsLoginProfile](#yandex.cloud.organizationmanager.v1.OsLoginProfile)** ||
|| nextPageToken | **string** ||
|#

## OsLoginProfile {#yandex.cloud.organizationmanager.v1.OsLoginProfile}

#|
||Field | Description ||
|| id | **string** ||
|| organizationId | **string** ||
|| subjectId | **string** ||
|| login | **string** ||
|| uid | **string** (int64) ||
|| isDefault | **boolean** ||
|| homeDirectory | **string** ||
|| shell | **string** ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/setDefaultProfile -->
<!-- file: OsLogin/setDefaultProfile.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{osLoginProfileId}:setDefault
    method: post
    path:
      type: object
      properties:
        osLoginProfileId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - osLoginProfileId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: OsLogin.SetDefaultProfile

Sets a profile as a default for the subject assigned to this profile

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{osLoginProfileId}:setDefault
```

## Path parameters

#|
||Field | Description ||
|| osLoginProfileId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/updateProfile -->
<!-- file: OsLogin/updateProfile.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{osLoginProfileId}
    method: patch
    path:
      type: object
      properties:
        osLoginProfileId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - osLoginProfileId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        login:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 32. Value must match the regular expression ` ^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,31}$ `.
          pattern: ^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,31}$
          type: string
        uid:
          description: |-
            **string** (int64)
            1000 - 2^63 - 1
            Acceptable values are 1000 to 9223372036854775807, inclusive.
          type: string
          format: int64
        homeDirectory:
          description: |-
            **string**
            The maximum string length in characters is 255.
          type: string
        shell:
          description: |-
            **string**
            The maximum string length in characters is 255.
          type: string
        updateMask:
          description: |-
            **string** (field-mask)
            A comma-separated names off ALL fields to be updated.
            Only the specified fields will be changed. The others will be left untouched.
            If the field is specified in `` updateMask `` and no value for that field was sent in the request,
            the field's value will be reset to the default. The default value for most fields is null or 0.
            If `` updateMask `` is not sent in the request, all fields' values will be updated.
            Fields specified in the request will be updated to provided values.
            The rest of the fields will be reset to the default.
          type: string
          format: field-mask
      required:
        - login
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: OsLogin.UpdateProfile

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/osLoginProfiles/{osLoginProfileId}
```

## Path parameters

#|
||Field | Description ||
|| osLoginProfileId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateOsLoginProfileRequest}

```json
{
  "login": "string",
  "uid": "string",
  "homeDirectory": "string",
  "shell": "string",
  "updateMask": "string"
}
```

#|
||Field | Description ||
|| login | **string**

Required field.

The maximum string length in characters is 32. Value must match the regular expression ` ^[a-zA-Z0-9_][a-zA-Z0-9_-]{0,31}$ `. ||
|| uid | **string** (int64)

1000 - 2^63 - 1

Acceptable values are 1000 to 9223372036854775807, inclusive. ||
|| homeDirectory | **string**

The maximum string length in characters is 255. ||
|| shell | **string**

The maximum string length in characters is 255. ||
|| updateMask | **string** (field-mask)

A comma-separated names off ALL fields to be updated.
Only the specified fields will be changed. The others will be left untouched.
If the field is specified in `` updateMask `` and no value for that field was sent in the request,
the field's value will be reset to the default. The default value for most fields is null or 0.

If `` updateMask `` is not sent in the request, all fields' values will be updated.
Fields specified in the request will be updated to provided values.
The rest of the fields will be reset to the default. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/OsLogin/updateSettings -->
<!-- file: OsLogin/updateSettings.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/osLoginSettings
    method: patch
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        userSshKeySettings:
          description: '**[UserSshKeySettings](#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest.UserSshKeySettings)**'
          $ref: '#/definitions/UserSshKeySettings'
        sshCertificateSettings:
          description: '**[SshCertificateSettings](#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest.SshCertificateSettings)**'
          $ref: '#/definitions/SshCertificateSettings'
        updateMask:
          description: |-
            **string** (field-mask)
            A comma-separated names off ALL fields to be updated.
            Only the specified fields will be changed. The others will be left untouched.
            If the field is specified in `` updateMask `` and no value for that field was sent in the request,
            the field's value will be reset to the default. The default value for most fields is null or 0.
            If `` updateMask `` is not sent in the request, all fields' values will be updated.
            Fields specified in the request will be updated to provided values.
            The rest of the fields will be reset to the default.
          type: string
          format: field-mask
      additionalProperties: false
    definitions:
      UserSshKeySettings:
        type: object
        properties:
          enabled:
            description: '**boolean**'
            type: boolean
          allowManageOwnKeys:
            description: '**boolean**'
            type: boolean
      SshCertificateSettings:
        type: object
        properties:
          enabled:
            description: '**boolean**'
            type: boolean
---

# Identity Hub API, REST: OsLogin.UpdateSettings

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/osLoginSettings
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest}

```json
{
  "userSshKeySettings": {
    "enabled": "boolean",
    "allowManageOwnKeys": "boolean"
  },
  "sshCertificateSettings": {
    "enabled": "boolean"
  },
  "updateMask": "string"
}
```

#|
||Field | Description ||
|| userSshKeySettings | **[UserSshKeySettings](#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest.UserSshKeySettings)** ||
|| sshCertificateSettings | **[SshCertificateSettings](#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest.SshCertificateSettings)** ||
|| updateMask | **string** (field-mask)

A comma-separated names off ALL fields to be updated.
Only the specified fields will be changed. The others will be left untouched.
If the field is specified in `` updateMask `` and no value for that field was sent in the request,
the field's value will be reset to the default. The default value for most fields is null or 0.

If `` updateMask `` is not sent in the request, all fields' values will be updated.
Fields specified in the request will be updated to provided values.
The rest of the fields will be reset to the default. ||
|#

## UserSshKeySettings {#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest.UserSshKeySettings}

#|
||Field | Description ||
|| enabled | **boolean** ||
|| allowManageOwnKeys | **boolean** ||
|#

## SshCertificateSettings {#yandex.cloud.organizationmanager.v1.UpdateOsLoginSettingsRequest.SshCertificateSettings}

#|
||Field | Description ||
|| enabled | **boolean** ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/SshCertificate/generate -->
<!-- file: SshCertificate/generate.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/sshCertificates:generate
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        cloudId:
          description: |-
            **string**
            the cloud must be attached to an organization
            The maximum string length in characters is 50.
            Includes only one of the fields `cloudId`, `organizationId`.
          type: string
        organizationId:
          description: |-
            **string**
            The maximum string length in characters is 50.
            Includes only one of the fields `cloudId`, `organizationId`.
          type: string
        subjectId:
          description: |-
            **string**
            specify subject to generate certificate for default login
            The maximum string length in characters is 50.
            Includes only one of the fields `subjectId`, `osLogin`.
          type: string
        osLogin:
          description: |-
            **string**
            specify os_login for a specific login
            The maximum string length in characters is 32.
            Includes only one of the fields `subjectId`, `osLogin`.
          type: string
        publicKey:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 15000.
          type: string
      required:
        - publicKey
      additionalProperties: false
      allOf:
        - oneOf:
            - required:
                - cloudId
            - required:
                - organizationId
        - oneOf:
            - required:
                - subjectId
            - required:
                - osLogin
    definitions: null
---

# Identity Hub API, REST: SshCertificate.Generate

Members of an organization can generate certificates for themselves
Signing certificates for other users requires a special permission

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/sshCertificates:generate
```

## Body parameters {#yandex.cloud.organizationmanager.v1.GenerateSshCertificateRequest}

```json
{
  // Includes only one of the fields `cloudId`, `organizationId`
  "cloudId": "string",
  "organizationId": "string",
  // end of the list of possible fields
  // Includes only one of the fields `subjectId`, `osLogin`
  "subjectId": "string",
  "osLogin": "string",
  // end of the list of possible fields
  "publicKey": "string"
}
```

#|
||Field | Description ||
|| cloudId | **string**

the cloud must be attached to an organization

The maximum string length in characters is 50.

Includes only one of the fields `cloudId`, `organizationId`. ||
|| organizationId | **string**

The maximum string length in characters is 50.

Includes only one of the fields `cloudId`, `organizationId`. ||
|| subjectId | **string**

specify subject to generate certificate for default login

The maximum string length in characters is 50.

Includes only one of the fields `subjectId`, `osLogin`. ||
|| osLogin | **string**

specify os_login for a specific login

The maximum string length in characters is 32.

Includes only one of the fields `subjectId`, `osLogin`. ||
|| publicKey | **string**

Required field.

The maximum string length in characters is 15000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.GenerateSshCertificateResponse}

**HTTP Code: 200 - OK**

```json
{
  "signedCertificate": "string"
}
```

#|
||Field | Description ||
|| signedCertificate | **string**

as per specification https://cvsweb.openbsd.org/src/usr.bin/ssh/PROTOCOL.certkeys?annotate=HEAD ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/SshCertificate/index -->
<!-- file: SshCertificate/index.md -->

---
editable: false
---

# Identity Hub API, REST: SshCertificate

## Methods

#|
||Method | Description ||
|| [Generate](generate.md) | Members of an organization can generate certificates for themselves ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/User/deleteMembership -->
<!-- file: User/deleteMembership.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/users/{subjectId}
    method: delete
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the organization to delete membership.
            The maximum string length in characters is 50.
          type: string
        subjectId:
          description: |-
            **string**
            ID of the subject that is being deleted from organization.
            By default equals to authenticated subject.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: User.DeleteMembership

Delete user membership.

## HTTP request

```
DELETE https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/users/{subjectId}
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the organization to delete membership.

The maximum string length in characters is 50. ||
|| subjectId | **string**

Required field. ID of the subject that is being deleted from organization.
By default equals to authenticated subject.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/User/index -->
<!-- file: User/index.md -->

---
editable: false
---

# Identity Hub API, REST: User

A set of methods for managing Organization users.

## Methods

#|
||Method | Description ||
|| [ListMembers](listMembers.md) | List organization active members. ||
|| [DeleteMembership](deleteMembership.md) | Delete user membership. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/User/listMembers -->
<!-- file: User/listMembers.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/users
    method: get
    path:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field. ID of the Organization resource to list members for.
            The maximum string length in characters is 50.
          type: string
      required:
        - organizationId
      additionalProperties: false
    query:
      type: object
      properties:
        pageSize:
          description: |-
            **string** (int64)
            The maximum number of results per page to return. If the number of available
            results is larger than `pageSize`, the service returns a [ListMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListMembersResponse)
            that can be used to get the next page of results in subsequent list requests.
            Acceptable values are 0 to 1000, inclusive. Default value: 100.
            Acceptable values are 0 to 1000, inclusive.
          default: '100'
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            Page token. Set `pageToken`
            to the [ListMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListMembersResponse)
            returned by a previous list request to get the next page of results.
            The maximum string length in characters is 2000.
          type: string
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: User.ListMembers

List organization active members.

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/organizations/{organizationId}/users
```

## Path parameters

#|
||Field | Description ||
|| organizationId | **string**

Required field. ID of the Organization resource to list members for.

The maximum string length in characters is 50. ||
|#

## Query parameters {#yandex.cloud.organizationmanager.v1.ListMembersRequest}

#|
||Field | Description ||
|| pageSize | **string** (int64)

The maximum number of results per page to return. If the number of available
results is larger than `pageSize`, the service returns a [ListMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListMembersResponse)
that can be used to get the next page of results in subsequent list requests.
Acceptable values are 0 to 1000, inclusive. Default value: 100.

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

Page token. Set `pageToken`
to the [ListMembersResponse.nextPageToken](#yandex.cloud.organizationmanager.v1.ListMembersResponse)
returned by a previous list request to get the next page of results.

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListMembersResponse}

**HTTP Code: 200 - OK**

```json
{
  "users": [
    {
      "subjectClaims": {
        "sub": "string",
        "name": "string",
        "givenName": "string",
        "familyName": "string",
        "preferredUsername": "string",
        "picture": "string",
        "email": "string",
        "zoneinfo": "string",
        "locale": "string",
        "phoneNumber": "string",
        "subType": "string",
        "federation": {
          "id": "string",
          "name": "string"
        },
        "lastAuthenticatedAt": "string"
      }
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| users[] | **[OrganizationUser](#yandex.cloud.organizationmanager.v1.ListMembersResponse.OrganizationUser)**

List of users for the specified organization. ||
|| nextPageToken | **string**

This token allows you to get the next page of results for list requests. If the number of results
is larger than [ListMembersRequest.pageSize](#yandex.cloud.organizationmanager.v1.ListMembersRequest), use the `nextPageToken` as the value
for the [ListMembersRequest.pageToken](#yandex.cloud.organizationmanager.v1.ListMembersRequest) query parameter in the next list request.
Each subsequent list request will have its own `nextPageToken` to continue paging through the results. ||
|#

## OrganizationUser {#yandex.cloud.organizationmanager.v1.ListMembersResponse.OrganizationUser}

#|
||Field | Description ||
|| subjectClaims | **[SubjectClaims](#yandex.cloud.oauth.SubjectClaims)**

OpenID standard claims with additional Cloud Organization claims. ||
|#

## SubjectClaims {#yandex.cloud.oauth.SubjectClaims}

Claims representation, see https://openid.net/specs/openid-connect-core-1_0.html#StandardClaims for details.

#|
||Field | Description ||
|| sub | **string**

Required field. Subject - Identifier for the End-User at the Issuer.

The maximum string length in characters is 50. ||
|| name | **string**

End-User's full name in displayable form including all name parts, possibly including titles and suffixes, ordered according to the End-User's locale and preferences. ||
|| givenName | **string**

Given name(s) or first name(s) of the End-User. Note that in some cultures, people can have multiple given names; all can be present, with the names being separated by space characters. ||
|| familyName | **string**

Surname(s) or last name(s) of the End-User. Note that in some cultures, people can have multiple family names or no family name; all can be present, with the names being separated by space characters. ||
|| preferredUsername | **string**

Shorthand name by which the End-User wishes to be referred to at the RP, such as janedoe or j.doe.
This value MAY be any valid JSON string including special characters such as @, /, or whitespace. The RP MUST NOT rely upon this value being unique, as discussed in Section 5.7. ||
|| picture | **string**

URL of the End-User's profile picture. This URL MUST refer to an image file (for example, a PNG, JPEG, or GIF image file),
rather than to a Web page containing an image. Note that this URL SHOULD specifically reference a profile photo of the End-User suitable for displaying when describing the End-User, rather than an arbitrary photo taken by the End-User. ||
|| email | **string**

End-User's preferred e-mail address. Its value MUST conform to the RFC 5322 [RFC5322] addr-spec syntax.
The RP MUST NOT rely upon this value being unique, as discussed in Section 5.7. ||
|| zoneinfo | **string**

String from zoneinfo `zoneinfo` time zone database representing the End-User's time zone. For example, Europe/Paris or America/Los_Angeles. ||
|| locale | **string**

End-User's locale, represented as a BCP47 [RFC5646] language tag. This is typically an ISO 639-1 Alpha-2 [ISO639-1] language code in lowercase and an ISO 3166-1 Alpha-2 [ISO3166-1] country code in uppercase, separated by a dash.
For example, en-US or fr-CA. As a compatibility note, some implementations have used an underscore as the separator rather than a dash, for example, en_US; Relying Parties MAY choose to accept this locale syntax as well. ||
|| phoneNumber | **string**

End-User's preferred telephone number. E.164 [E.164] is RECOMMENDED as the format of this Claim, for example, +1 (425) 555-1212 or +56 (2) 687 2400.
If the phone number contains an extension, it is RECOMMENDED that the extension be represented using the RFC 3966 [RFC3966] extension syntax, for example, +1 (604) 555-1234;ext=5678. ||
|| subType | **enum** (SubjectType)

Subject type.

- `USER_ACCOUNT`
- `SERVICE_ACCOUNT`
- `GROUP`
- `INVITEE` ||
|| federation | **[Federation](#yandex.cloud.oauth.Federation)**

User federation, non-empty only for federated users. ||
|| lastAuthenticatedAt | **string** (date-time)

Last time the access token was created. Filled only for federated users (not for global users).

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#

## Federation {#yandex.cloud.oauth.Federation}

Minimalistic analog of yandex.cloud.organizationmanager.v1.saml.Federation

#|
||Field | Description ||
|| id | **string**

Required field. ID of the federation.

The maximum string length in characters is 50. ||
|| name | **string**

Name of the federation. The name is unique within the cloud or organization ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/UserSshKey/create -->
<!-- file: UserSshKey/create.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys
    method: post
    path: null
    query: null
    body:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
        subjectId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
        name:
          description: |-
            **string**
            The maximum string length in characters is 255.
          type: string
        data:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 20000.
          type: string
        expiresAt:
          description: |-
            **string** (date-time)
            String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
            `0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.
            To work with values in this field, use the APIs described in the
            [Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
            In some languages, built-in datetime utilities do not support nanosecond precision (9 digits).
          type: string
          format: date-time
      required:
        - organizationId
        - subjectId
        - data
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: UserSshKey.Create

## HTTP request

```
POST https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys
```

## Body parameters {#yandex.cloud.organizationmanager.v1.CreateUserSshKeyRequest}

```json
{
  "organizationId": "string",
  "subjectId": "string",
  "name": "string",
  "data": "string",
  "expiresAt": "string"
}
```

#|
||Field | Description ||
|| organizationId | **string**

Required field.

The maximum string length in characters is 50. ||
|| subjectId | **string**

Required field.

The maximum string length in characters is 50. ||
|| name | **string**

The maximum string length in characters is 255. ||
|| data | **string**

Required field.

The maximum string length in characters is 20000. ||
|| expiresAt | **string** (date-time)

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/UserSshKey/delete -->
<!-- file: UserSshKey/delete.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys/{userSshKeyId}
    method: delete
    path:
      type: object
      properties:
        userSshKeyId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - userSshKeyId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: UserSshKey.Delete

## HTTP request

```
DELETE https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys/{userSshKeyId}
```

## Path parameters

#|
||Field | Description ||
|| userSshKeyId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/UserSshKey/get -->
<!-- file: UserSshKey/get.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys/{userSshKeyId}
    method: get
    path:
      type: object
      properties:
        userSshKeyId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - userSshKeyId
      additionalProperties: false
    query: null
    body: null
    definitions: null
---

# Identity Hub API, REST: UserSshKey.Get

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys/{userSshKeyId}
```

## Path parameters

#|
||Field | Description ||
|| userSshKeyId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.UserSshKey}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "subjectId": "string",
  "data": "string",
  "name": "string",
  "fingerprint": "string",
  "organizationId": "string",
  "createdAt": "string",
  "expiresAt": "string"
}
```

#|
||Field | Description ||
|| id | **string** ||
|| subjectId | **string** ||
|| data | **string** ||
|| name | **string** ||
|| fingerprint | **string** ||
|| organizationId | **string** ||
|| createdAt | **string** (date-time)

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| expiresAt | **string** (date-time)

Used for temporary keys, if empty the key doesn't expire

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/UserSshKey/index -->
<!-- file: UserSshKey/index.md -->

---
editable: false
---

# Identity Hub API, REST: UserSshKey

## Methods

#|
||Method | Description ||
|| [Get](get.md) |  ||
|| [List](list.md) |  ||
|| [Create](create.md) |  ||
|| [Update](update.md) |  ||
|| [Delete](delete.md) |  ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/UserSshKey/list -->
<!-- file: UserSshKey/list.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys
    method: get
    path: null
    query:
      type: object
      properties:
        organizationId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
        subjectId:
          description: |-
            **string**
            if empty, list all organization keys
            The maximum string length in characters is 50.
          type: string
        pageSize:
          description: |-
            **string** (int64)
            Acceptable values are 0 to 1000, inclusive.
          type: string
          format: int64
        pageToken:
          description: |-
            **string**
            The maximum string length in characters is 2000.
          type: string
      required:
        - organizationId
      additionalProperties: false
    body: null
    definitions: null
---

# Identity Hub API, REST: UserSshKey.List

## HTTP request

```
GET https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys
```

## Query parameters {#yandex.cloud.organizationmanager.v1.ListUserSshKeysRequest}

#|
||Field | Description ||
|| organizationId | **string**

Required field.

The maximum string length in characters is 50. ||
|| subjectId | **string**

if empty, list all organization keys

The maximum string length in characters is 50. ||
|| pageSize | **string** (int64)

Acceptable values are 0 to 1000, inclusive. ||
|| pageToken | **string**

The maximum string length in characters is 2000. ||
|#

## Response {#yandex.cloud.organizationmanager.v1.ListUserSshKeysResponse}

**HTTP Code: 200 - OK**

```json
{
  "sshKeys": [
    {
      "id": "string",
      "subjectId": "string",
      "data": "string",
      "name": "string",
      "fingerprint": "string",
      "organizationId": "string",
      "createdAt": "string",
      "expiresAt": "string"
    }
  ],
  "nextPageToken": "string"
}
```

#|
||Field | Description ||
|| sshKeys[] | **[UserSshKey](#yandex.cloud.organizationmanager.v1.UserSshKey)** ||
|| nextPageToken | **string** ||
|#

## UserSshKey {#yandex.cloud.organizationmanager.v1.UserSshKey}

#|
||Field | Description ||
|| id | **string** ||
|| subjectId | **string** ||
|| data | **string** ||
|| name | **string** ||
|| fingerprint | **string** ||
|| organizationId | **string** ||
|| createdAt | **string** (date-time)

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| expiresAt | **string** (date-time)

Used for temporary keys, if empty the key doesn't expire

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/UserSshKey/update -->
<!-- file: UserSshKey/update.md -->

---
editable: false
apiPlayground:
  - url: https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys/{userSshKeyId}
    method: patch
    path:
      type: object
      properties:
        userSshKeyId:
          description: |-
            **string**
            Required field.
            The maximum string length in characters is 50.
          type: string
      required:
        - userSshKeyId
      additionalProperties: false
    query: null
    body:
      type: object
      properties:
        name:
          description: |-
            **string**
            The maximum string length in characters is 255.
          type: string
        updateMask:
          description: |-
            **string** (field-mask)
            A comma-separated names off ALL fields to be updated.
            Only the specified fields will be changed. The others will be left untouched.
            If the field is specified in `` updateMask `` and no value for that field was sent in the request,
            the field's value will be reset to the default. The default value for most fields is null or 0.
            If `` updateMask `` is not sent in the request, all fields' values will be updated.
            Fields specified in the request will be updated to provided values.
            The rest of the fields will be reset to the default.
          type: string
          format: field-mask
        expiresAt:
          description: |-
            **string** (date-time)
            String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
            `0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.
            To work with values in this field, use the APIs described in the
            [Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
            In some languages, built-in datetime utilities do not support nanosecond precision (9 digits).
          type: string
          format: date-time
      additionalProperties: false
    definitions: null
---

# Identity Hub API, REST: UserSshKey.Update

## HTTP request

```
PATCH https://organization-manager.{{ api-host }}/organization-manager/v1/userSshKeys/{userSshKeyId}
```

## Path parameters

#|
||Field | Description ||
|| userSshKeyId | **string**

Required field.

The maximum string length in characters is 50. ||
|#

## Body parameters {#yandex.cloud.organizationmanager.v1.UpdateUserSshKeyRequest}

```json
{
  "name": "string",
  "updateMask": "string",
  "expiresAt": "string"
}
```

#|
||Field | Description ||
|| name | **string**

The maximum string length in characters is 255. ||
|| updateMask | **string** (field-mask)

A comma-separated names off ALL fields to be updated.
Only the specified fields will be changed. The others will be left untouched.
If the field is specified in `` updateMask `` and no value for that field was sent in the request,
the field's value will be reset to the default. The default value for most fields is null or 0.

If `` updateMask `` is not sent in the request, all fields' values will be updated.
Fields specified in the request will be updated to provided values.
The rest of the fields will be reset to the default. ||
|| expiresAt | **string** (date-time)

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|#

## Response {#yandex.cloud.operation.Operation}

**HTTP Code: 200 - OK**

```json
{
  "id": "string",
  "description": "string",
  "createdAt": "string",
  "createdBy": "string",
  "modifiedAt": "string",
  "done": "boolean",
  "metadata": "object",
  // Includes only one of the fields `error`, `response`
  "error": {
    "code": "integer",
    "message": "string",
    "details": [
      "object"
    ]
  },
  "response": "object"
  // end of the list of possible fields
}
```

An Operation resource. For more information, see [Operation](/docs/api-design-guide/concepts/operation).

#|
||Field | Description ||
|| id | **string**

ID of the operation. ||
|| description | **string**

Description of the operation. 0-256 characters long. ||
|| createdAt | **string** (date-time)

Creation timestamp.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| createdBy | **string**

ID of the user or service account who initiated the operation. ||
|| modifiedAt | **string** (date-time)

The time when the Operation resource was last modified.

String in [RFC3339](https://www.ietf.org/rfc/rfc3339.txt) text format. The range of possible values is from
`0001-01-01T00:00:00Z` to `9999-12-31T23:59:59.999999999Z`, i.e. from 0 to 9 digits for fractions of a second.

To work with values in this field, use the APIs described in the
[Protocol Buffers reference](https://developers.google.com/protocol-buffers/docs/reference/overview).
In some languages, built-in datetime utilities do not support nanosecond precision (9 digits). ||
|| done | **boolean**

If the value is `false`, it means the operation is still in progress.
If `true`, the operation is completed, and either `error` or `response` is available. ||
|| metadata | **object**

Service-specific metadata associated with the operation.
It typically contains the ID of the target resource that the operation is performed on.
Any method that returns a long-running operation should document the metadata type, if any. ||
|| error | **[Status](#google.rpc.Status)**

The error result of the operation in case of failure or cancellation.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|| response | **object**

The normal response of the operation in case of success.
If the original method returns no data on success, such as Delete,
the response is [google.protobuf.Empty](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#google.protobuf.Empty).
If the original method is the standard Create/Update,
the response should be the target resource of the operation.
Any method that returns a long-running operation should document the response type, if any.

Includes only one of the fields `error`, `response`.

The operation result.
If `done == false` and there was no failure detected, neither `error` nor `response` is set.
If `done == false` and there was a failure detected, `error` is set.
If `done == true`, exactly one of `error` or `response` is set. ||
|#

## Status {#google.rpc.Status}

The error result of the operation in case of failure or cancellation.

#|
||Field | Description ||
|| code | **integer** (int32)

Error code. An enum value of [google.rpc.Code](https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto). ||
|| message | **string**

An error message. ||
|| details[] | **object**

A list of messages that carry the error details. ||
|#


---

<!-- source: https://yandex.cloud/en/organization/api-ref/authentication -->
<!-- file: authentication.md -->

---
title: '{{ org-full-name }} API authentication'
description: Before you can work with the API, you need to get an IAM token.
---

# {{ org-full-name }} API authentication

{% include notitle [auth](../../_includes/authentication.md) %}


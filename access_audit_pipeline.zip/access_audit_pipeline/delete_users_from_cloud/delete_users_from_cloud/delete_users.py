#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Удаляет список пользователей организации Yandex Cloud по email.

Примеры:
    python delete_users.py egor.balagurov@astrazeneca.com
    python delete_users.py --emails-file emails.txt
    python delete_users.py egor.balagurov@astrazeneca.com --dry-run
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.identity_hub import (  # noqa: E402  (sys.path update above)
    DEFAULT_BASE_URL,
    IdentityHub,
    IdentityHubError,
    load_iam_token,
)
from modules.logging_conf import log

CREDS_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "credentials",
    "cloud_identity_hub.md",
)


def read_emails_file(path: str) -> list:
    emails: list = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith("#"):
                emails.append(line)
    return emails


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Удаляет пользователей Yandex Cloud по email."
    )
    p.add_argument("emails", nargs="*", help="Emailы пользователей для удаления")
    p.add_argument(
        "-f", "--emails-file", help="Файл с email (по одному на строку, # — комментарий)"
    )
    p.add_argument("-t", "--iam-token", help="IAM-токен (переопределяет cred-файл)")
    p.add_argument("--creds", default=CREDS_PATH, help="Путь к cred-файлу с IAM-токеном")
    p.add_argument("--base-url", default=DEFAULT_BASE_URL, help="Base URL API Organization Manager")
    p.add_argument(
        "-o",
        "--organization",
        help="Название организации, если в аккаунте несколько",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Показать, кто будет удалён, без реального удаления",
    )
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)

    emails = list(args.emails)
    if args.emails_file:
        emails = read_emails_file(args.emails_file)
    if not emails:
        print("Нет emailов для обработки", file=sys.stderr)
        return 2

    log.info(
        "Запуск: %d email(s), dry_run=%s, base_url=%s",
        len(emails),
        args.dry_run,
        args.base_url,
    )

    try:
        token = args.iam_token or load_iam_token(args.creds)
        client = IdentityHub(iam_token=token, base_url=args.base_url)
        org_id = client.get_organization_id(org_name=args.organization)
        log.info("Используется организация: id=%s", org_id)
        success, failed = client.delete_users(org_id, emails, dry_run=args.dry_run)
    except IdentityHubError as exc:
        log.error("%s", exc)
        return 1

    log.info("Успешно: %d, ошибок: %d", len(success), len(failed))
    if failed:
        log.error("Не обработано: %s", ", ".join(failed))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

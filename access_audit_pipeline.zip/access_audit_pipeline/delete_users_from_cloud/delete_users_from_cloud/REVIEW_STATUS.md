**module**: tracker_permissions
**iteration**: 1
**phase**: review

## Step-by-step Task Description
Написать скрипт на python, который удаляет список пользователей из cloud по их emails. Credentials в папке credentials. Документация в папке api_documentation.
Проверить на ['egor.balagurov@astrazeneca.com']

## Review Comments


## History

- iter1.implement: done

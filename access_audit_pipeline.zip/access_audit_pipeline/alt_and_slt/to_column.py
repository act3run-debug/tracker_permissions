from pathlib import Path

FILE_NAME = "alt_and_slt.txt"  # имя файла рядом со скриптом

path = Path(__file__).resolve().parent / FILE_NAME
text = path.read_text(encoding="utf-8")

for item in text.split(","):
    item = item.strip()
    if item:
        print(item)
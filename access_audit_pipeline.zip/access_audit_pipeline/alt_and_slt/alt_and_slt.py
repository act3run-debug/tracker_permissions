# -*- coding: utf-8 -*-
"""
Скрипт для сбора иерархии прямых подчиненных через Microsoft Teams (playwright).
Работает в ОТДЕЛЬНОМ процессе Edge (свой профиль, свой порт CDP).

Логика:
- depth=1: прямые подчинённые Ирины → заходим в их Organization, рекурсивно обрабатываем подчинённых
- depth=2: подчинённые подчинённых → только email из карточки, не заходим в Organization
- Если вкладка Organization есть, но нет кнопки с email — ждём до 1 минуты
- Если вкладки нет и кнопки нет — пользователь скрыт, просто нажимаем "Назад"
- После каждого возврата переискиваем контейнер (фрейм мог измениться)
"""

from __future__ import annotations

import time
import subprocess
import os

from playwright.sync_api import sync_playwright, expect

# === Профиль и порт CDP скрипта ===
AUTOMATION_PROFILE_2 = r"C:\Users\kvfv307\AppData\Local\ChromeAutomation_2"
CDP_PORT_2 = 9223

EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

# === Универсальные селекторы (RU + EN) ===
SHOW_MORE_SELECTORS = [
    "button[aria-label*='скрыт']",
    "button[aria-label*='Показать еще']",
    "button[aria-label*='hidden managers']",
    "button:has-text('Показать еще')",
    "button:has-text('Show')",
]

EMAIL_SELECTORS = [
    "button[aria-label^='Email:']",
    "button[aria-label^='Электронная почта:']",
    "button[aria-label*='Email:']",
    "button[aria-label*='почта:']",
    "button[aria-label*='@']",
]

BACK_SELECTORS = [
    "button[data-testid='NavigationBackButton']",
    "button[aria-label='Back']",
    "button[aria-label='Назад']",
    "button[title='Back']",
    "button[title='Назад']",
]

ORG_SELECTORS = [
    "#LPC_Header_TabBar_Organization",
    "button[name='Organization']",
    "[data-content='Organization']",
]

PROFILE_SELECTORS = [
    "#LPC_Header_TabBar_Profile",
    "button[name='Profile']",
    "[data-content='Profile']",
    "button[name='Профиль']",
    "[data-content='Профиль']",
]

CLOSE_CARD_SELECTORS = [
    "button[data-testid='NavigationCloseButton']",
    "button[aria-label='Закрыть']",
    "button[aria-label='Close']",
    "button[title='Закрыть']",
    "button[title='Close']",
]

# Селекторы для подчинённых (Direct Reports)
DIRECT_REPORTS_SELECTORS = [
    "ol li button.Direct-ShowProfileButton",
    "button.Direct-ShowProfileButton",
    "button[aria-label^='View profile of']",
]

# Максимальная глубина рекурсии
MAX_DEPTH = 2

# Таймаут ожидания кнопки с email
EMAIL_WAIT_TIMEOUT_IF_ORG_MS = 60000  # 1 минута, если вкладка Organization есть
EMAIL_WAIT_TIMEOUT_MS = 30000  # 30 секунд в остальных случаях


class HierarchyAPIError(RuntimeError):
    pass


def is_internal(email: str) -> bool:
    if not email:
        return False
    lower = email.lower()
    return lower.endswith("@astrazeneca.com") or lower.endswith("@alexion.com")


def _find_element_anywhere(page, selectors, timeout=15000):
    if isinstance(selectors, str):
        selectors = [selectors]

    deadline = time.time() + timeout / 1000
    while time.time() < deadline:
        for selector in selectors:
            try:
                candidate = page.locator(selector)
                if candidate.count() > 0:
                    return candidate.first, page, selector
            except Exception:
                pass
            for frame in page.frames:
                try:
                    candidate = frame.locator(selector)
                    if candidate.count() > 0:
                        return candidate.first, frame, selector
                except Exception:
                    continue
        time.sleep(0.2)
    return None, None, None


def _wait_for_any(page, selectors, timeout=15000):
    return _find_element_anywhere(page, selectors, timeout)


def _expand_all_direct_reports(page):
    max_iterations = 15
    for iteration in range(max_iterations):
        btn, _, _ = _find_element_anywhere(page, SHOW_MORE_SELECTORS, timeout=500)
        if not btn:
            break
        btn.scroll_into_view_if_needed()
        btn.click(force=True)


def _switch_to_profile_and_back(page):
    """Переключается на вкладку Profile и обратно на Organization для обновления данных."""
    profile_tab, _, _ = _find_element_anywhere(page, PROFILE_SELECTORS, timeout=10000)
    if not profile_tab:
        for frame in [page] + page.frames:
            try:
                candidate = frame.get_by_role("tab", name="Profile")
                if candidate.count() > 0:
                    profile_tab = candidate.first
                    break
                candidate = frame.get_by_role("tab", name="Профиль")
                if candidate.count() > 0:
                    profile_tab = candidate.first
                    break
            except Exception:
                continue
    
    if profile_tab:
        try:
            expect(profile_tab).to_be_visible(timeout=5000)
            profile_tab.click(force=True)
            time.sleep(1)
        except Exception:
            pass
    
    org_tab, _, _ = _find_element_anywhere(page, ORG_SELECTORS, timeout=10000)
    if not org_tab:
        for frame in [page] + page.frames:
            try:
                candidate = frame.get_by_role("tab", name="Organization")
                if candidate.count() > 0:
                    org_tab = candidate.first
                    break
            except Exception:
                continue
    
    if org_tab:
        try:
            expect(org_tab).to_be_visible(timeout=5000)
            org_tab.click(force=True)
            time.sleep(1.5)
            return True
        except Exception:
            pass
    
    return False


def _go_back_or_close(page):
    """Пытается нажать кнопку 'Назад', если нет — закрывает карточку."""
    back_btn, _, _ = _wait_for_any(page, BACK_SELECTORS, timeout=5000)
    if back_btn:
        back_btn.click(force=True)
        time.sleep(1.5)
        return "back"
    
    close_btn, _, _ = _find_element_anywhere(page, CLOSE_CARD_SELECTORS, timeout=3000)
    if close_btn:
        close_btn.click(force=True)
        time.sleep(1)
        return "close"
    
    page.keyboard.press("Escape")
    time.sleep(1)
    return "escape"


def _find_container_with_direct_reports(page):
    """Ищет актуальный фрейм (контейнер) с подчинёнными.
    
    Возвращает (container, used_selector) или (None, None), если подчинённые не найдены.
    """
    # Ищем любой элемент из ORG_SELECTORS, чтобы найти актуальный фрейм
    org_tab, container, _ = _find_element_anywhere(page, ORG_SELECTORS, timeout=10000)
    
    if not org_tab:
        for frame in [page] + page.frames:
            try:
                candidate = frame.get_by_role("tab", name="Organization")
                if candidate.count() > 0:
                    org_tab = candidate.first
                    container = frame
                    break
            except Exception:
                continue
    
    if not container:
        return None, None
    
    # Теперь ищем подчинённых в этом контейнере
    for selector in DIRECT_REPORTS_SELECTORS:
        try:
            candidate = container.locator(selector)
            if candidate.count() > 0:
                return container, selector
        except Exception:
            continue
    
    # Если в контейнере не нашли, ищем на всей странице
    for selector in DIRECT_REPORTS_SELECTORS:
        try:
            candidate = page.locator(selector)
            if candidate.count() > 0:
                return page, selector
        except Exception:
            continue
    
    return None, None


def _extract_email_from_card(page, org_tab_exists=False):
    """Извлекает email из карточки профиля.
    
    Если вкладка Organization есть, но кнопки с email нет — ждём до 1 минуты.
    В остальных случаях ждём до 30 секунд.
    """
    # Быстрый поиск кнопки с email (5 секунд)
    email_btn, _, _ = _wait_for_any(page, EMAIL_SELECTORS, timeout=5000)
    
    if email_btn:
        expect(email_btn).to_be_visible(timeout=5000)
        email = email_btn.get_attribute("aria-label")
        email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()
        return email
    
    # Если вкладка Organization есть — ждём до 1 минуты
    if org_tab_exists:
        print(f"    -> Кнопка с email не найдена, но вкладка Organization есть. Ждём до 1 минуты...")
        email_btn, _, _ = _wait_for_any(page, EMAIL_SELECTORS, timeout=EMAIL_WAIT_TIMEOUT_IF_ORG_MS)
        if email_btn:
            expect(email_btn).to_be_visible(timeout=5000)
            email = email_btn.get_attribute("aria-label")
            email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()
            return email
    else:
        # В остальных случаях ждём до 30 секунд
        email_btn, _, _ = _wait_for_any(page, EMAIL_SELECTORS, timeout=EMAIL_WAIT_TIMEOUT_MS)
        if email_btn:
            expect(email_btn).to_be_visible(timeout=5000)
            email = email_btn.get_attribute("aria-label")
            email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()
            return email
    
    return None


def _extract_direct_reports_recursive(page, all_emails, depth=1):
    """Рекурсивно извлекает подчинённых.
    
    После каждого возврата переискивает актуальный контейнер с подчинёнными.
    """
    indent = "  " * depth
    
    if depth > MAX_DEPTH:
        return []
    
    emails = []
    processed_names = set()  # Защита от бесконечных циклов и дубликатов

    # Ищем актуальный контейнер с подчинёнными
    container, used_selector = _find_container_with_direct_reports(page)
    
    if container is None:
        print(f"{indent}Подчинённые не найдены (у пользователя нет подчинённых)")
        return emails

    _expand_all_direct_reports(page)

    processed = 0
    while True:
        # Каждый раз переискиваем контейнер (он мог измениться после возврата)
        if processed > 0:
            container_fresh, selector_fresh = _find_container_with_direct_reports(page)
            if container_fresh is not None:
                container = container_fresh
                used_selector = selector_fresh
        
        dr_btns_fresh = container.locator(used_selector)
        total = dr_btns_fresh.count()
        
        if total == 0:
            print(f"{indent}Подчинённые исчезли из списка, останавливаемся")
            break
        
        if processed >= total:
            break

        i = processed
        try:
            dr_btn = dr_btns_fresh.nth(i)
            aria_label = dr_btn.get_attribute("aria-label") or ""
            name = aria_label.replace("View profile of ", "").replace("Просмотреть профиль ", "").replace("Посмотреть профиль ", "").strip()
            
            # Защита от бесконечных циклов
            if name in processed_names:
                print(f"{indent}Подчинённый {name} уже обработан, пропускаем")
                processed += 1
                continue
            
            processed_names.add(name)
            print(f"{indent}Обработка подчинённого {i}: {name} (depth={depth})")

            # 1. Клик на подчинённого (открывается его карточка)
            dr_btn.scroll_into_view_if_needed()
            dr_btn.click(force=True)
            time.sleep(1.5)

            # 2. Проверяем, есть ли вкладка Organization (быстрый поиск)
            has_org_tab = False
            if depth < MAX_DEPTH:
                org_tab, sub_container, _ = _find_element_anywhere(page, ORG_SELECTORS, timeout=5000)
                if not org_tab:
                    for frame in [page] + page.frames:
                        try:
                            candidate = frame.get_by_role("tab", name="Organization")
                            if candidate.count() > 0:
                                org_tab = candidate.first
                                sub_container = frame
                                has_org_tab = True
                                break
                        except Exception:
                            continue
                else:
                    has_org_tab = True

            # 3. Извлекаем email из карточки
            email = _extract_email_from_card(page, org_tab_exists=has_org_tab)
            
            if email:
                print(f"{indent}  -> Email: {email}")
                if email.lower() not in all_emails:
                    emails.append(email)
                    all_emails.add(email.lower())
            else:
                if has_org_tab:
                    print(f"{indent}  -> Email не найден даже после 1 минуты ожидания")
                else:
                    print(f"{indent}  -> Email не найден")

            # 4. Если вкладка Organization есть — заходим и рекурсивно обрабатываем
            if has_org_tab and org_tab:
                expect(org_tab).to_be_visible(timeout=5000)
                org_tab.click(force=True)
                time.sleep(1.5)

                # Рекурсивный вызов для следующего уровня
                _extract_direct_reports_recursive(page, all_emails, depth + 1)

            # 5. Если нет ни кнопки с email, ни вкладки — скрытый пользователь
            if email is None and not has_org_tab:
                print(f"{indent}  -> Скрытый пользователь (нет ни кнопки с email, ни вкладки)")
                action = _go_back_or_close(page)
                print(f"{indent}  -> Вернулись ({action})")
                
                time.sleep(1)
                _expand_all_direct_reports(page)
                processed += 1
                continue

            # 6. Нажимаем "Назад" чтобы вернуться
            action = _go_back_or_close(page)
            print(f"{indent}  -> Вернулись ({action})")
            
            # Обновляем вкладку Organization переключением Profile -> Organization
            if action == "back" and depth < MAX_DEPTH:
                if _switch_to_profile_and_back(page):
                    print(f"{indent}  -> Обновили вкладку Organization")
                else:
                    print(f"{indent}  -> Не удалось обновить вкладку Organization")

            time.sleep(1)
            _expand_all_direct_reports(page)
            processed += 1

        except Exception as e:
            print(f"{indent}  -> Ошибка: {e}")
            try:
                action = _go_back_or_close(page)
                
                if action == "back" and depth < MAX_DEPTH:
                    _switch_to_profile_and_back(page)
                
                time.sleep(1)
                _expand_all_direct_reports(page)
            except Exception:
                pass
            processed += 1

    return emails


class HierarchyAPI:
    def __init__(self):
        self._playwright = None
        self._browser = None
        self._page = None
        self._connected = False
        self._context = None

    def _ensure_browser(self):
        if self._connected:
            return
        
        edge_path = next((p for p in EDGE_PATHS if os.path.exists(p)), None)
        if not edge_path:
            raise HierarchyAPIError("Edge не найден!")
        
        try:
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.connect_over_cdp(f"http://localhost:{CDP_PORT_2}")
            self._connected = True
            print(f"  Подключено к существующему Edge на порту {CDP_PORT_2}")
        except Exception:
            print(f"  Запуск нового процесса Edge на порту {CDP_PORT_2}...")
            subprocess.Popen([
                edge_path, 
                f"--user-data-dir={AUTOMATION_PROFILE_2}",
                f"--remote-debugging-port={CDP_PORT_2}", 
                "--no-first-run",
                "--no-default-browser-check", 
                "--start-maximized",
            ])
            time.sleep(5)
            
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.connect_over_cdp(f"http://localhost:{CDP_PORT_2}")
            self._connected = True

        contexts = self._browser.contexts
        if contexts:
            self._context = contexts[0]
            self._page = self._context.pages[0] if self._context.pages else self._context.new_page()
        else:
            self._context = self._browser.new_context()
            self._page = self._context.new_page()

    def _ensure_teams_ready(self):
        if not self._page:
            self._ensure_browser()

        current_url = self._page.url
        if "teams.microsoft.com" in current_url:
            time.sleep(2)
            return

        self._page.goto("https://teams.microsoft.com/v2/")
        self._page.wait_for_load_state("domcontentloaded")
        time.sleep(5)

        try:
            self._page.locator("input#ms-searchux-input").wait_for(state="visible", timeout=20000)
        except Exception:
            self._page.locator("input#ms-searchux-input").wait_for(state="visible", timeout=120000)

    def _search_user(self, email: str):
        if not is_internal(email):
            return None
        
        self._page.bring_to_front()
        time.sleep(0.5)
        
        search_input = self._page.wait_for_selector("input#ms-searchux-input", timeout=20000)
        search_input.click()
        time.sleep(0.5)
        search_input.fill(email)
        time.sleep(1.5)
        self._page.keyboard.press("ArrowDown")
        time.sleep(0.5)
        self._page.keyboard.press("ArrowDown")
        time.sleep(0.5)
        self._page.keyboard.press("Enter")
        time.sleep(2.5)

    def _open_profile_and_org_tab(self, email: str = ""):
        self._page.bring_to_front()
        time.sleep(1)
        
        self._page.keyboard.press("Escape")
        time.sleep(0.5)
        
        try:
            profile_trigger = self._page.wait_for_selector(
                "ul[data-tid='chat-topic-menu'] div[data-person-mri]",
                timeout=20000,
            )
        except Exception:
            print(f"  -> Чат не открылся или триггер не найден для {email}")
            return None

        profile_trigger.click()
        time.sleep(1)

        org_tab, container, _ = _find_element_anywhere(self._page, ORG_SELECTORS, timeout=15000)

        if not org_tab:
            for frame in [self._page] + self._page.frames:
                try:
                    candidate = frame.get_by_role("tab", name="Organization")
                    if candidate.count() > 0:
                        org_tab = candidate.first
                        container = frame
                        break
                except Exception:
                    continue

        if not org_tab:
            raise HierarchyAPIError("Вкладка Organization не появилась!")

        expect(org_tab).to_be_visible(timeout=10000)
        org_tab.click(force=True)

        time.sleep(2)
        return container

    def get_direct_reports(self, email: str) -> list[str]:
        if not is_internal(email):
            return []
        try:
            print(f"  -> Обеспечение готовности Teams...")
            self._ensure_teams_ready()
            print(f"  -> Поиск пользователя {email}...")
            self._search_user(email)

            print(f"  -> Открытие профиля и вкладки Organization...")
            container = self._open_profile_and_org_tab()
            if container is None:
                return []
            
            print(f"  -> Извлечение иерархии подчинённых (до {MAX_DEPTH} уровней)...")
            all_emails = set()
            emails = _extract_direct_reports_recursive(self._page, all_emails, depth=1)
            
            # Закрываем карточку профиля в конце
            try:
                close_btn, _, _ = _find_element_anywhere(self._page, CLOSE_CARD_SELECTORS, timeout=5000)
                if close_btn:
                    close_btn.click(force=True)
                    time.sleep(0.5)
                else:
                    self._page.keyboard.press("Escape")
                    time.sleep(0.5)
            except Exception:
                pass
            
            # Возвращаем ВСЕ собранные email (и depth=1, и depth=2)
            return list(all_emails)

        except HierarchyAPIError:
            raise
        except Exception as e:
            print(f"  -> Ошибка: {e}")
            raise HierarchyAPIError(f"Ошибка получения подчиненных для {email}: {e}") from e


def main():
    target_email = "Irina.Panarina@astrazeneca.com"
    all_emails = set()
    all_emails.add(target_email.lower())
    
    api = HierarchyAPI()
    
    print(f"Поиск иерархии подчиненных {target_email}...")
    all_subordinates = api.get_direct_reports(target_email)
    
    for email in all_subordinates:
        all_emails.add(email.lower())
            
    result_str = ", ".join(sorted(list(all_emails)))
    with open("output.txt", "w", encoding="utf-8") as f:
        f.write(result_str)
        
    print(f"\nГотово! Найдено уникальных email: {len(all_emails)}. Файл output.txt создан.")
    print(f"Список: {result_str}")


if __name__ == "__main__":
    main()
from pathlib import Path

def read_emails(filename):
    text = Path(filename).read_text(encoding="utf-8")
    return [email.strip() for email in text.split(",") if email.strip()]

emails = read_emails("emails_output.txt")
exclude = {email.casefold() for email in read_emails("output.txt")}

true_emails = [email for email in emails if email.casefold() not in exclude]

Path("true_emails.txt").write_text(",".join(true_emails), encoding="utf-8")
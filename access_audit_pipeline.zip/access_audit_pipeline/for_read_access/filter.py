from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def load_exclude(filename):
    path = BASE_DIR / filename
    return {
        line.strip().lower()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }


exclude = load_exclude("alt_and_slt.txt") | load_exclude("staying.txt")

raw_emails = (BASE_DIR / "emails_output.txt").read_text(encoding="utf-8")
emails = [email.strip() for email in raw_emails.split(",") if email.strip()]

result = []
seen = set()

for email in emails:
    key = email.lower()
    if key not in exclude and key not in seen:
        seen.add(key)
        result.append(email)

lines = ["["]
for i, email in enumerate(result):
    comma = "," if i < len(result) - 1 else ""
    lines.append(f'    "{email}"{comma}')
lines.append("]")

(BASE_DIR / "for_reading.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
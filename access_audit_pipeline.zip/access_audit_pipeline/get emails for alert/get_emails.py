import re
from pathlib import Path

folder = Path(__file__).resolve().parent
input_file = folder / "inactive_users_report.txt"
output_file = folder / "emails_output.txt"

if not input_file.exists():
    raise SystemExit(f"Файл не найден: {input_file}")

text = input_file.read_text(encoding="utf-8-sig", errors="ignore")

# Границы: пробел, перевод строки, скобки.
# Если нужно считать таб тоже границей, замени на r"[\s()]+"
tokens = re.split(r"[ \n\r()]+", text)

emails = []
seen = set()

for token in tokens:
    if "@" in token[1:-1] and token not in seen:
        seen.add(token)
        emails.append(token)

output_file.write_text(",".join(emails), encoding="utf-8")
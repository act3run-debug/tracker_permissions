import sys
from pathlib import Path


def read_text(path: Path) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="utf-8", errors="replace")


def add_emails(line: str, emails: list, seen: set) -> None:
    # двоеточие теперь считается границей/разделителем
    for token in line.replace(":", " ").split():
        if token.count("@") == 1:
            left, _, right = token.partition("@")
            if left and right:
                key = token.lower()
                if key not in seen:
                    seen.add(key)
                    emails.append(token)


def print_email_block(header: str, emails: list) -> None:
    print(header)
    if not emails:
        print("[]")
        return

    print("[")
    for i, email in enumerate(emails):
        comma = "," if i < len(emails) - 1 else ""
        print(f"    '{email}'{comma}")
    print("]")


def main():
    script_dir = Path(__file__).resolve().parent
    txt_files = sorted(
        p for p in script_dir.iterdir()
        if p.is_file() and p.suffix.lower() == ".txt"
    )

    if not txt_files:
        sys.exit("В папке со скриптом нет .txt файла.")
    if len(txt_files) > 1:
        sys.exit("В папке со скриптом несколько .txt файлов. Должен быть один.")

    lines = read_text(txt_files[0]).splitlines()

    fired_emails = []
    fired_seen = set()

    error_emails = []
    error_seen = set()
    error_full_lines = []

    for line in lines:
        low = line.lower().replace("ё", "е")

        if "уволен" in low:
            add_emails(line, fired_emails, fired_seen)

        if "ERROR" in line:
            add_emails(line, error_emails, error_seen)

            if "ошибка обработки" not in line.lower():
                error_full_lines.append(line)

    print_email_block("Уволены:", fired_emails)
    print_email_block("ERROR:", error_emails)

    if error_full_lines:
        print("\n".join(error_full_lines))


if __name__ == "__main__":
    main()
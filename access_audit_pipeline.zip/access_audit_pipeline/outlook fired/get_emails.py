import re
from pathlib import Path

base = Path(__file__).resolve().parent
src = base / "outlook_fired.txt"
out = base / "output.txt"

text = src.read_text(encoding="utf-8", errors="ignore")

emails = []
seen = set()

for chunk in re.findall(r"[^\s()]+", text):
    for candidate in chunk.split(","):
        if len(candidate) > 1 and candidate[0] != "@" and "@" in candidate:
            key = candidate.lower()  # уникальность без учёта регистра
            if key not in seen:
                seen.add(key)
                emails.append(candidate)

out.write_text(
    "\n".join(emails) + ("\n" if emails else ""),
    encoding="utf-8"
)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Удаляет пользователей организации Yandex Cloud по email. Всё в одном файле."""

from __future__ import annotations

import logging
import sys

import requests

# ========================= КОНФИГ =========================
EMAILS = [
    'maxim.kainer@astrazeneca.com',
    'natalia.mironenko@astrazeneca.com',
    'yana.grigoreva@astrazeneca.com',
    'olga.shcherbina@astrazeneca.com',
    'aleksey.dudka@astrazeneca.com',
    'victoria.tyukhova@astrazeneca.com',
    'vladimir.andreev@astrazeneca.com',
    'iana.cherepanova@astrazeneca.com',
    'anna.siliutina@astrazeneca.com',
    'evgeniia.medvedeva@astrazeneca.com',
    'anastasiya.knysh@astrazeneca.com',
    'mariia.fedosova@astrazeneca.com',
    'alexandr.stadnikov1@astrazeneca.com',
    'aleksandra.arzhanik@astrazeneca.com',
    'irina.melnikova@astrazeneca.com',
    'vasiliy.terehov@astrazeneca.com',
    'viktoriya.nagornaya@astrazeneca.com',
    'ksenia.elmemmi@astrazeneca.com',
    'igor.scherbakov@astrazeneca.com',
    'shepetilo.eugine@astrazeneca.com',
    'denis.vakhromeev@astrazeneca.com',
    'yuri.nivin@astrazeneca.com',
    'vladimir.mingaleev@astrazeneca.com',
    'anna.gulieva@astrazeneca.com',
    'nikita.epishev@astrazeneca.com',
    'vitaliy.varfolomeev@astrazeneca.com',
    'svetlana.dolina@astrazeneca.com',
    'elizaveta.zakharova@astrazeneca.com',
    'daria.zanina@astrazeneca.com',
    'anton.litvinov@astrazeneca.com',
    'ekaterina.gorbacheva@astrazeneca.com',
    'evgeniia.kasianenko@astrazeneca.com',
    'ivan.terekov@astrazeneca.com',
    'natalia.khalitova@astrazeneca.com',
    'nina.tretiakova@astrazeneca.com',
    'tatyana.kuznetsova@astrazeneca.com',
    'dariya.nursultanova@astrazeneca.com',
    'rossinur.rakhman@astrazeneca.com',
    'viktor.lesnikov@astrazeneca.com',
    'polina.sorokina@astrazeneca.com',
    'anna.ivantsova@astrazeneca.com',
    'aleksandr.nokhrin@astrazeneca.com',
    'viktoriya.molochnikova@astrazeneca.com',
    'evgeniy.kolbasov@astrazeneca.com',
    'ayzira.gimatova@astrazeneca.com',
    'andrey.motygulin@astrazeneca.com',
    'ekaterina.dudinova@astrazeneca.com',
    'anna.lushnikova1@astrazeneca.com',
    'andrey.ryazanov@astrazeneca.com',
    'anastasiya.lazareva@astrazeneca.com',
    'valeriy.markunin@astrazeneca.com',
    'anna.tchernobai@astrazeneca.com',
    'yuliya.iliina@astrazeneca.com',
    'victoria.polyakova1@astrazeneca.com',
    'elena.sayapina@astrazeneca.com',
    'pavel.guda@astrazeneca.com',
    'delya.sharmanzhinova@astrazeneca.com',
    'veronika.razzhivaykina@astrazeneca.com',
    'anton.zubarev@astrazeneca.com',
    'alina.abdulmamova@astrazeneca.com',
    'elizaveta.minyaeva@astrazeneca.com',
    'nikolai.zatonskii@astrazeneca.com',
    'violetta.sedova@astrazeneca.com',
    'albina.nabiullina@astrazeneca.com',
    'aida.mahmutova1@astrazeneca.com',
    'aleksandr.gurin1@astrazeneca.com',
    'aleksandr.yurasov@astrazeneca.com',
    'alena.dynkova@astrazeneca.com',
    'alexey.artemov@astrazeneca.com',
    'alla.zhuravleva@alexion.com',
    'anastasia.sakharova@astrazeneca.com',
    'anastasiia.aleksandrova@astrazeneca.com',
    'andrey.sinitsin@astrazeneca.com',
    'anna.dudar@astrazeneca.com',
    'daniil.boldyrev@astrazeneca.com',
    'daniil.guravlev@astrazeneca.com',
    'daniil.polyakov@astrazeneca.com',
    'danila.korolev@astrazeneca.com',
    'diana.gadzhimuradova@alexion.com',
    'egor.balagurov@astrazeneca.com',
    'ekaterina.fadina@astrazeneca.com',
    'ekaterina.ilyicheva@astrazeneca.com',
    'ekaterina.popova2@astrazeneca.com',
    'elena.glukhova@alexion.com',
    'evgeniia.morgunova@astrazeneca.com',
    'evgeniia.shaplina@astrazeneca.com',
    'evgeniya.atmanzina@alexion.com',
    'ksenia.semiglazova@astrazeneca.com',
    'matvey.borovov@astrazeneca.com',
    'mikhail.postnikov@astrazeneca.com',
    'mikhail.tyurin@astrazeneca.com',
    'nataliya.yanchich@astrazeneca.com',
    'natalya.bukhtoyarova@alexion.com',
    'nikita.novikov1@astrazeneca.com',
    'olga.mikhaylova@alexion.com',
    'ramil.sharipov@astrazeneca.com',
    'ruslan.novikov@alexion.com',
    'sofia.timofeeva@astrazeneca.com',
    'victor.babichev@astrazeneca.com',
    'vsevolod.mikhaylov@astrazeneca.com',
    'yana.evdokimova@astrazeneca.com',
    'yulia.danilova@astrazeneca.com',
]

IAM_TOKEN = (
    "t1.9euelZqeipuYl86SnJTHjp2UzY6Om-3rnpWaiYzNmcvLm5ePi5nPy5uQjJDl9PcIVwUr-e8HbSKs3fT3SAUDK_nvB20irNXi9eyGnNGQnoqLl9GPip2TlpzSjJuU7fmQj5qRlpvN5_XrnpWaj5aYmI-OyZGPmc3MlsqOx4zv_MXrnpWaj5aYmI-OyZGPmc3MlsqOx4y9656VmszJj5rImcmax5mLmpTMjp2PteuGnNGWnpLRkI-akZab0oyajYmajQ.tyVzWSZWFVGTuFvlmQbX-TdfURPZ0SyArY_8kEqz_x2ELnzkDtv_mN9nzMXwywyV926M9Ub3l9lkfPi5uEykBQ"
)

ORGANIZATION = None  # Название организации, если их несколько; None = первая
DRY_RUN = False
BASE_URL = "https://organization-manager.api.cloud.yandex.net"
PAGE_SIZE = 1000
# ==========================================================

# --- Логирование ---
_LOG_FMT = "%(asctime)s | %(levelname)-8s | %(message)s"
log = logging.getLogger("delete_users")
log.setLevel(logging.INFO)
_h = logging.StreamHandler(sys.stdout)
_h.setFormatter(logging.Formatter(_LOG_FMT, datefmt="%Y-%m-%d %H:%M:%S"))
log.addHandler(_h)
log.propagate = False


class IdentityHubError(RuntimeError):
    pass


class IdentityHub:
    def __init__(self, iam_token: str, base_url: str = BASE_URL, timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {iam_token}",
            "Content-Type": "application/json",
        })

    def _request(self, method: str, path: str, **kwargs):
        url = f"{self.base_url}{path}"
        resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        if resp.status_code != 200:
            raise IdentityHubError(f"{method} {path} -> {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    def list_organizations(self) -> list:
        return self._request("GET", "/organization-manager/v1/organizations").get("organizations", [])

    def get_organization_id(self, org_name: str | None = None) -> str:
        orgs = self.list_organizations()
        if not orgs:
            raise IdentityHubError("Нет ни одной Cloud Organization")
        org = orgs[0]
        if len(orgs) > 1 and org_name:
            for c in orgs:
                if c.get("name") == org_name:
                    org = c
                    break
            else:
                log.warning("Организация '%s' не найдена — используется первая из %d", org_name, len(orgs))
        if len(orgs) > 1:
            log.warning("Найдено организаций: %d, используется id=%s name=%s", len(orgs), org.get("id"), org.get("name"))
        org_id = org.get("id")
        if not org_id:
            raise IdentityHubError("Не удалось определить id организации")
        return org_id

    def list_members(self, org_id: str) -> dict:
        """{email_lower: subjectId}"""
        result: dict = {}
        token = ""
        while True:
            params = {"pageSize": PAGE_SIZE}
            if token:
                params["pageToken"] = token
            data = self._request("GET", f"/organization-manager/v1/organizations/{org_id}/users", params=params)
            for user in data.get("users", []):
                claims = user.get("subjectClaims") or {}
                email = (claims.get("email") or "").lower()
                sub = claims.get("sub")
                if email and sub:
                    result[email] = sub
            token = data.get("nextPageToken")
            if not token:
                break
        return result

    def delete_user(self, org_id: str, subject_id: str) -> dict:
        path = f"/organization-manager/v1/organizations/{org_id}/users/{subject_id}"
        operation = self._request("DELETE", path)
        op_id = operation.get("id")
        if not op_id:
            return operation
        resolved = self._fetch_operation(org_id, op_id)
        if resolved and resolved.get("done"):
            if resolved.get("error"):
                raise IdentityHubError(f"Operation {op_id} error: {resolved['error']}")
            log.info("Operation %s завершена", op_id)
        return operation

    def _fetch_operation(self, org_id: str, op_id: str) -> dict | None:
        for path in [
            f"/organization-manager/v1/organizations/{org_id}/operations/{op_id}",
            f"/organization-manager/v1/operations/{op_id}",
        ]:
            try:
                return self._request("GET", path)
            except IdentityHubError:
                pass
        return None

    def delete_users(self, org_id: str, emails: list, dry_run: bool = False) -> tuple[list, list]:
        by_email = self.list_members(org_id)
        success, failed = [], []
        for email in emails:
            subject_id = by_email.get(email.lower())
            if not subject_id:
                log.warning("%s: не найден — пропущен", email)
                failed.append(email)
                continue
            if dry_run:
                log.info("%s (subjectId=%s): dry-run, был бы удалён", email, subject_id)
                success.append(email)
                continue
            try:
                self.delete_user(org_id, subject_id)
                log.info("%s (subjectId=%s) удалён", email, subject_id)
                success.append(email)
            except IdentityHubError as exc:
                log.error("%s: ошибка — %s", email, exc)
                failed.append(email)
        return success, failed


def main() -> int:
    if not EMAILS:
        print("Список EMAILS пуст", file=sys.stderr)
        return 2

    log.info("Запуск: %d email(s), dry_run=%s", len(EMAILS), DRY_RUN)

    try:
        client = IdentityHub(iam_token=IAM_TOKEN, base_url=BASE_URL)
        org_id = client.get_organization_id(org_name=ORGANIZATION)
        log.info("Организация: id=%s", org_id)
        success, failed = client.delete_users(org_id, EMAILS, dry_run=DRY_RUN)
    except IdentityHubError as exc:
        log.error("%s", exc)
        return 1

    log.info("Успешно: %d, ошибок: %d", len(success), len(failed))
    if failed:
        log.error("Не обработано: %s", ", ".join(failed))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
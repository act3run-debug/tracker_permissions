# -*- coding: utf-8 -*-
"""Движок обработки заявок на доступ.

Реализует:
- дефолт-доступ (прямые очереди, группы без признака, иерархия Graph,
  фиксированный список, спецлогика);
- доп. доступ (Согласование / Ожидание решения / На доработку);
- глобальные маркеры «Кастом:» / «Кастом группы:» (наивысший приоритет);
- сканирование новых участников Cloud и отзыв истёкших временных доступов.
"""

from __future__ import annotations

import json
import os
import re

from config import (
    STATUS_AGREEMENT,
    STATUS_DORABOTKA,
    STATUS_OZIDANIE,
    STATUS_CLOSED,
    TEXT_RIGHTS_NOT_FIXED,
    PREFIX_AGREE_ALL,
    CLOUD_SNAPSHOT_FILE,
    JOINED_INTERVAL_DAYS,
    DEFAULT_ACCESS_START_EMAIL,
)
from issue_parser import (
    ParsedIssue,
    parse_issue,
    normalize_rights,
)
from logging_conf import log
from special_logic import (
    is_internal,
    check_rwe_research,
    check_autsors_external_translations,
    apply_group_addition_rules,
    RWE_GROUP,
    EXTERNAL_TRANSLATIONS_GROUP,
)
from temp_access import TempAccessStore
from table_parser import GroupRule

RIGHTS_READ = "Чтение"
RIGHTS_WRITE = "Создание, редактирование, чтение"
_RECURSION_LABEL = "Рекурсия руководителя (один уровень)"


def _norm_group_name(value) -> str:
    """Нормализует имя группы из Tracker для сопоставления с правилом.

    Tracker отдаёт группе поле ``name``, которое помимо собственно имени
    содержит описание: ``tracker-data-and-digital Все сотрудники D&D (...)``
    или ``rwe-research | Альбина Хабибуллина ...``. Срезаем всё после ``|``,
    содержимое скобок и схлопываем пробелы.
    """
    text = (value or "").lower()
    text = text.split("|", 1)[0]
    text = re.sub(r"\(.*?\)", " ", text)
    return re.sub(r"\s+", " ", text).strip()


class AccessEngine:
    def __init__(
        self,
        tracker,
        identity,
        graph,
        temp_store: TempAccessStore,
        rules: list[GroupRule],
    ):
        self.tracker = tracker
        self.identity = identity
        self.graph = graph
        self.temp = temp_store
        self.rules = rules
        self._rule_by_group = {r.group_name: r for r in rules if r.group_name}
        self._group_perm_cache: dict = {}
        self._tracker_groups: dict | None = None
        self._inactive_emails: set[str] = set()
        # Cloud-юзеры, отсутствующие в Teams (уволённые) — обнаруживаются в
        # scan_cloud_users; отчёт о них печатается в конце работы скрипта.
        self.terminated_cloud_emails: list[str] = []

    def set_inactive_emails(self, emails: set[str]) -> None:
        """Установить множество email'ов неактивных пользователей."""
        self._inactive_emails = emails

    def _is_inactive(self, email: str) -> bool:
        """Проверить, является ли email неактивным."""
        return email.lower() in self._inactive_emails

    # ------------------------------------------------------------------
    # Низкий уровень: права группы в очереди (динамическое сопоставление)
    # ------------------------------------------------------------------
    def _tracker_group_id(self, group_name: str):
        if self._tracker_groups is None:
            index: dict[str, object] = {}
            for g in self.tracker.get_groups():
                key = _norm_group_name(g.get("name"))
                gid = g.get("id")
                if key and gid and key not in index:
                    index[key] = gid
            self._tracker_groups = index
        target = _norm_group_name(group_name)
        if not target:
            return None
        # 1) точное совпадение по нормализованному имени
        gid = self._tracker_groups.get(target)
        if gid:
            return gid
        # 2) префиксное совпадение: имя правила — начало имени группы
        #    в Tracker (после имени идёт описание/разделитель)
        for key, gid in self._tracker_groups.items():
            if key.startswith(target) and (
                len(key) == len(target) or key[len(target)] in " -"
            ):
                return gid
            if target.startswith(key) and (
                len(target) == len(key) or target[len(key)] in " -"
            ):
                return gid
        return None

    def group_permissions(self, group_name: str, queue: str) -> frozenset:
        key = (group_name, queue)
        if key not in self._group_perm_cache:
            gid = self._tracker_group_id(group_name)
            perms: set[str] = set()
            if gid:
                data = self.tracker.get_group_permissions(queue, gid)
                perms = set((data.get("permissions") or {}).keys())
            self._group_perm_cache[key] = frozenset(perms)
        return self._group_perm_cache[key]

    def rights_satisfied(self, group_name: str, queue: str, rights: str) -> bool:
        perms = self.group_permissions(group_name, queue)
        if rights == RIGHTS_READ:
            return "READ" in perms
        if rights == RIGHTS_WRITE:
            return "WRITE" in perms
        return False

    def is_group_member(self, group_name: str, email: str) -> bool:
        return email.lower() in self.identity.list_group_members(group_name)

    # ------------------------------------------------------------------
    # Выдача доступов
    # ------------------------------------------------------------------
    def grant_group(self, key: str, group_name: str, email: str, rule_label: str) -> bool:
        if self.is_group_member(group_name, email):
            log.info(
                "Задача %s: %s уже состоит в группе '%s' (%s)",
                key, email, group_name, rule_label,
            )
            return True
        try:
            self.identity.add_user_to_group(group_name, email)
        except Exception as exc:  # IdentityHubError и сетевые
            log.error(
                "Задача %s: НЕ удалось добавить %s в группу '%s' (%s): %s",
                key, email, group_name, rule_label, exc,
            )
            return False
        log.info(
            "Задача %s: %s добавлен в Cloud-группу '%s' (правило: %s)",
            key, email, group_name, rule_label,
        )
        # Дополнительная логика (хардкод-правила)
        for extra in apply_group_addition_rules(group_name, email):
            log.info(
                "Задача %s: спецлогика — вместе с '%s' добавляем в '%s'",
                key, group_name, extra,
            )
            self.grant_group(key, extra, email, "Дополнительная логика")
        return True

    def grant_direct(self, key: str, queue: str, email: str, rights: str, rule_label: str) -> bool:
        try:
            self.tracker.grant_user_access(queue, email, rights)
        except Exception as exc:
            log.error(
                "Задача %s: НЕ удалось выдать %s доступ '%s' в очередь %s "
                "(%s): %s",
                key, email, rights, queue, rule_label, exc,
            )
            return False
        log.info(
            "Задача %s: %s выдан доступ '%s' в очередь %s напрямую (правило: %s)",
            key, email, rights, queue, rule_label,
        )
        return True

    def _grant_manager_recursion(self, key: str, group_name: str, email: str, label: str) -> None:
        """Рекурсия руководителя строго на один уровень (ТЗ)."""
        try:
            manager = self.graph.get_direct_manager(email)
        except Exception as exc:
            log.error("Graph: прямой руководитель %s недоступен: %s", email, exc)
            return
        if not manager:
            return
        if is_internal(manager) and self.identity.get_subject_id(manager) is not None:
            self.grant_group(key, group_name, manager, _RECURSION_LABEL + f" (по {label})")

    def _match_default(self, email: str, rule: GroupRule) -> tuple[bool, str]:
        """Дефолт-критерий строки таблицы для пользователя."""
        if email.lower() in rule.fixed_list:
            return True, "Фиксированный список"
        if not is_internal(email):
            return False, ""
        if rule.managers_any_level:
            chain = self.graph.get_manager_chain(email)
            chain = [m.lower() for m in chain]
            for m in chain:
                if m in rule.managers_any_level:
                    return True, "Руководитель (на любом уровне)"
        if rule.managers_direct:
            dm = self.graph.get_direct_manager(email)
            if dm and dm.lower() in rule.managers_direct:
                return True, "Руководитель линейный"
        return False, ""

    # ------------------------------------------------------------------
    # Статусы и описание
    # ------------------------------------------------------------------
    def _go(self, key: str, target: str, current: str) -> None:
        if current == target:
            return
        self.tracker.transition_to_status(key, target)

    def _append_text(self, key: str, description: str, text: str) -> str:
        if text in description:
            log.info("Задача %s: текст уже есть в описании — не дублирую", key)
            return description
        new_desc = f"{description.rstrip()}\n\n{text}"
        self.tracker.update_issue_description(key, new_desc)
        log.info("Задача %s: в описание дописан текст", key)
        return new_desc

    @staticmethod
    def _block_header(kind: str, emails: list[str], queue: str) -> str:
        emails_str = ", ".join(emails)
        if kind == "propose":
            return f"Предлагаемые группы для юзера/юзеров {emails_str} в очередь {queue}:"
        if kind == "conflict":
            return f"Предлагаемые конфликтные группы для юзера/юзеров {emails_str} в очередь {queue}:"
        return f"Предлагаемые не конфликтные группы для юзера/юзеров {emails_str} в очередь {queue}:"

    def _append_block(
        self, key: str, description: str, kind: str,
        emails: list[str], queue: str, groups: list[str],
    ) -> str:
        header = self._block_header(kind, emails, queue)
        if header in description:
            log.info("Задача %s: блок «%s…» уже есть — не дублирую", key, header[:40])
            return description
        block = header + "\n" + "\n".join(f"{g}:" for g in groups)
        added = f"\n\n{block}"
        if kind == "propose" and PREFIX_AGREE_ALL not in description:
            added = f"\n\n{PREFIX_AGREE_ALL}{added}"
        new_desc = description.rstrip() + added
        self.tracker.update_issue_description(key, new_desc)
        log.info("Задача %s: добавлен блок предложений (kind=%s, очередь=%s)", key, kind, queue)
        return new_desc

    # ------------------------------------------------------------------
    # Спецлогика (модуль «Дополнительная логика»)
    # ------------------------------------------------------------------
    def _process_special_logic(self, key: str, parsed: ParsedIssue) -> bool:
        if not parsed.emails or not parsed.initiator:
            return False
        granted = False
        rwe = check_rwe_research(parsed.initiator, parsed.summary)
        for email in list(parsed.emails):
            if self._is_inactive(email):
                log.info(
                    "Задача %s: пропускаю неактивного %s в спецлогике",
                    key, email,
                )
                continue
            if rwe:
                if is_internal(email):
                    if self.grant_group(key, RWE_GROUP, email, "Спецлогика rwe-research"):
                        granted = True
                else:
                    log.warning(
                        "Задача %s: rwe-research — внешний %s пропущен (только внутренние)",
                        key, email,
                    )
            if check_autsors_external_translations(parsed.initiator, email):
                if self.grant_group(
                    key, EXTERNAL_TRANSLATIONS_GROUP, email,
                    "Спецлогика autsors-external-translations",
                ):
                    granted = True
        return granted

    # ------------------------------------------------------------------
    # Глобальные маркеры «Кастом:» / «Кастом группы:»
    # ------------------------------------------------------------------
    def _process_global_markers(self, key: str, parsed: ParsedIssue, description: str) -> bool:
        if not parsed.emails:
            return False
        if not parsed.custom_queues and not parsed.custom_groups:
            return False
        rights = normalize_rights(parsed.rights) or RIGHTS_READ
        granted_ok: set[tuple[str, str, str]] = set()
        for email in parsed.emails:
            if self._is_inactive(email):
                log.info(
                    "Задача %s: пропускаю неактивного %s в глобальных маркерах",
                    key, email,
                )
                continue
            for queue, _exp in parsed.custom_queues:
                if self.grant_direct(key, queue, email, rights, "Кастом:"):
                    granted_ok.add(("queue", email, queue))
            for group, _exp in parsed.custom_groups:
                if not is_internal(email):
                    log.warning(
                        "Задача %s: Кастом группы — внешний %s пропущен (только внутренние)",
                        key, email,
                    )
                    continue
                if self.grant_group(key, group, email, "Кастом группы:"):
                    granted_ok.add(("group", email, group))
        for email in parsed.emails:
            for queue, exp in parsed.custom_queues:
                if exp and ("queue", email, queue) in granted_ok:
                    self.temp.add(email, "queue", queue, exp, rights)
            for group, exp in parsed.custom_groups:
                if exp and is_internal(email) and ("group", email, group) in granted_ok:
                    self.temp.add(email, "group", group, exp, "")
        # Закрывать заявку можно ТОЛЬКО если абсолютно все запрошенные
        # (email, ресурс) пары из «Кастом:» / «Кастом группы:» фактически
        # выданы (см. ТЗ «Условие закрытия»). Иначе — ERROR-лог, а заявка
        # остаётся открытой для ручного разбора оператором.
        expected: set[tuple[str, str, str]] = set()
        for email in parsed.emails:
            for queue, _exp in parsed.custom_queues:
                expected.add(("queue", email, queue))
            for group, _exp in parsed.custom_groups:
                expected.add(("group", email, group))

        missing = expected - granted_ok
        if missing:
            log.error(
                "Задача %s: выдано %d из %d запрошенных глобальных доступов — "
                "заявка НЕ закрыта. Не выдано: %s",
                key,
                len(granted_ok),
                len(expected),
                ", ".join(f"{m[1]} -> {m[2]}" for m in sorted(missing)),
            )
            return True

        self._go(key, STATUS_CLOSED, parsed.issue_status)
        log.info("Задача %s: обработана по глобальным маркерам — закрыта", key)
        return True

    # ------------------------------------------------------------------
    # Обработка одной очереди заявки
    # ------------------------------------------------------------------
    def _process_queue(
        self, key: str, parsed: ParsedIssue, queue: str, rights: str,
    ) -> dict:
        res = {"granted": True, "not_fixed": False,
               "grants": {}, "proposals": {}}

        # --- 1. Очередь для индивидуального доступа ---
        rows_ind = [r for r in self.rules if queue in r.individual_queues]
        if rows_ind:
            for email in parsed.emails:
                if self._is_inactive(email):
                    log.info(
                        "Задача %s: пропускаю неактивного %s в индивидуальной очереди",
                        key, email,
                    )
                    continue
                if not self.grant_direct(
                    key, queue, email, rights, "Очередь для индивидуального доступа"
                ):
                    res["granted"] = False
            return res

        # --- 2. Очереди для групп без признака ---
        rows_noattr = [r for r in self.rules if queue in r.noattr_queues]
        if rows_noattr:
            for rule in rows_noattr:
                if not rule.group_name:
                    continue
                for email in parsed.emails:
                    if self._is_inactive(email):
                        log.info(
                            "Задача %s: пропускаю неактивного %s в очередях без признака",
                            key, email,
                        )
                        continue
                    if not self.grant_group(
                        key, rule.group_name, email, "Очереди для групп без признака"
                    ):
                        res["granted"] = False
            return res

        # --- 3. Подходящие не-дефолтные и дефолтные группы по правам ---
        candidates = []
        for rule in self.rules:
            if not rule.group_name:
                continue
            if queue in rule.individual_queues or queue in rule.noattr_queues:
                continue
            if self.rights_satisfied(rule.group_name, queue, rights):
                candidates.append(rule)

        if not candidates:
            res["granted"] = False
            res["not_fixed"] = True
            log.info(
                "Задача %s: права '%s' очереди %s не зафиксированы ни в одной "
                "не-дефолтной группе",
                key, rights, queue,
            )
            return res

        for email in parsed.emails:
            if self._is_inactive(email):
                log.info(
                    "Задача %s: пропускаю неактивного %s в дефолт-очереди",
                    key, email,
                )
                continue
            res["grants"][email] = []
            res["proposals"][email] = []
            for rule in candidates:
                already = self.is_group_member(rule.group_name, email)
                if already:
                    res["grants"][email].append(rule.group_name)
                    continue
                if rule.only_by_consent:
                    res["proposals"][email].append(rule.group_name)
                    continue
                ok, label = self._match_default(email, rule)
                if ok:
                    if self.grant_group(key, rule.group_name, email, label):
                        res["grants"][email].append(rule.group_name)
                    else:
                        res["granted"] = False
                    if "Руководитель" in label:
                        self._grant_manager_recursion(
                            key, rule.group_name, email, label
                        )
                else:
                    res["proposals"][email].append(rule.group_name)
        # Если для кого-то есть непредложенные/несогласованные группы —
        # очередь не считается полностью обработанной
        if any(res["proposals"][e] for e in res["proposals"]):
            res["granted"] = False
        return res

    def _partition_conflicts(self, queue: str, groups: list[str]) -> tuple[list[str], list[str]]:
        """Конфликтные группы (>=2 с идентичными правами) и остальные."""
        rights_of: dict[str, frozenset] = {
            g: self.group_permissions(g, queue) for g in groups
        }
        counts: dict[frozenset, int] = {}
        for rs in rights_of.values():
            counts[rs] = counts.get(rs, 0) + 1
        conflict = [g for g in groups if counts[rights_of[g]] > 1]
        non_conflict = [g for g in groups if g not in conflict]
        return conflict, non_conflict

    # ------------------------------------------------------------------
    # Основной поток (заявка с маркерами 1-3)
    # ------------------------------------------------------------------
    def _process_default_flow(self, key: str, parsed: ParsedIssue) -> None:
        rights = normalize_rights(parsed.rights)
        if not rights:
            log.error(
                "Задача %s: права '%s' не являются ожидаемыми "
                "('Чтение' / 'Создание, редактирование, чтение')",
                key, parsed.rights,
            )
            self._append_text(key, parsed.description, TEXT_RIGHTS_NOT_FIXED)
            self._go(key, STATUS_DORABOTKA, parsed.issue_status)
            return

        # ---- Обработка подтверждений «Ок» из уже существующих блоков ----
        from issue_parser import parse_proposal_blocks
        agree_all = _agree_all_ok(parsed.description)
        for b in parse_proposal_blocks(parsed.description):
            targets = [g for g, _ok in b.groups if _ok]
            if agree_all:
                targets = [g for g, _ in b.groups]
            for g in dict.fromkeys(targets):
                for email in b.emails:
                    if self._is_inactive(email):
                        log.info(
                            "Задача %s: пропускаю неактивного %s в блоке «Ок»",
                            key, email,
                        )
                        continue
                    self.grant_group(key, g, email, "Согласовано администратором («Ок»)")

        # ---- Свежий проход по очередям ----
        per_queue = {}
        for queue in parsed.queues:
            per_queue[queue] = self._process_queue(key, parsed, queue, rights)

        any_not_fixed = any(r["not_fixed"] for r in per_queue.values())
        proposals = {
            q: r["proposals"] for q, r in per_queue.items() if not r["granted"]
        }

        if not proposals and not any_not_fixed:
            self._go(key, STATUS_CLOSED, parsed.issue_status)
            log.info("Задача %s: все запрошенные доступы выданы — закрыта", key)
            return

        description = parsed.description
        if any_not_fixed:
            description = self._append_text(
                key, description, TEXT_RIGHTS_NOT_FIXED
            )
            self._go(key, STATUS_DORABOTKA, parsed.issue_status)

        if proposals:
            # Сначала вычисляем partition'ы по всем очередям, чтобы понять,
            # есть ли хотя бы один конфликт («Ожидание решения»).
            partitions: list[tuple[str, list[str], list[str], list[str]]] = []
            for q, prop in proposals.items():
                email_map: dict[frozenset, list[str]] = {}
                for email, groups in prop.items():
                    if groups:
                        email_map.setdefault(frozenset(groups), []).append(email)
                for groups, emails in email_map.items():
                    glist = sorted(groups)
                    conflict, non_conflict = self._partition_conflicts(q, glist)
                    partitions.append((q, _ordered(emails, parsed.emails), glist, conflict))

            if not partitions:
                # Доступы не выданы, но ни одной группы для предложения не
                # найдено: переводить в «Согласование» нечего — админу нечего
                # согласовывать, заявка застрянет. Оставляем заявку в
                # «На доработку» с логом причины, чтобы оператор увидел проблему.
                log.error(
                    "Задача %s: доступы не выданы, но ни одной группы для "
                    "предложения не найдено (очереди: %s) — заявка оставлена "
                    "в «На доработку»",
                    key, ", ".join(sorted(proposals)),
                )
                if not any_not_fixed:
                    self._go(key, STATUS_DORABOTKA, parsed.issue_status)
                return

            conflict_mode = any(conf for (_q, _e, _g, conf) in partitions)

            for q, emails, glist, conflict in partitions:
                non_conflict = [g for g in glist if g not in conflict]
                if conflict_mode:
                    # В «Ожидание решения» всё выводится парами:
                    # конфликтные и неконфликтные группы.
                    if conflict:
                        description = self._append_block(
                            key, description, "conflict", emails, q, conflict,
                        )
                    if non_conflict:
                        description = self._append_block(
                            key, description, "nonconflict", emails, q, non_conflict,
                        )
                elif conflict:
                    description = self._append_block(
                        key, description, "conflict", emails, q, conflict,
                    )
                    if non_conflict:
                        description = self._append_block(
                            key, description, "nonconflict", emails, q, non_conflict,
                        )
                else:
                    description = self._append_block(
                        key, description, "propose", emails, q, glist,
                    )
            if conflict_mode and not any_not_fixed:
                self._go(key, STATUS_OZIDANIE, parsed.issue_status)
            elif not any_not_fixed:
                self._go(key, STATUS_AGREEMENT, parsed.issue_status)
            else:
                # остаёмся в «На доработку», блоки уже дописаны
                pass

    # ------------------------------------------------------------------
    # Обработка одной заявки (входная точка)
    # ------------------------------------------------------------------
    def process_issue(self, issue: dict) -> None:
        key = issue.get("key", "")
        log.info("=== Обработка задачи %s ===", key)
        fresh = self.tracker.get_issue(key)
        parsed = parse_issue(key, fresh.get("summary") or "", fresh.get("description") or "")
        parsed.issue_status = (fresh.get("status") or {}).get("key") or ""

        if parsed.issue_status == STATUS_CLOSED:
            log.info("Задача %s уже закрыта — пропуск", key)
            return

        # 1. Спецлогика проверяется для каждой заявки в общем потоке
        special_granted = self._process_special_logic(key, parsed)

        # 2. Глобальные маркеры — наивысший приоритет
        if self._process_global_markers(key, parsed, fresh.get("description") or ""):
            return

        # 3. Основной сценарий — маркеры 1-3
        if parsed.has_markers_1_3:
            self._process_default_flow(key, parsed)
            return

        # Заявка обработана только спец-логикой -> «Закрыт»
        if special_granted:
            self._go(key, STATUS_CLOSED, parsed.issue_status)
            log.info("Задача %s: обработана только по спецлогике — закрыта", key)
            return

        # Заявка не подходит ни под один сценарий обработки (нет маркеров 1-3,
        # глобальных маркеров и не сработала спецлогика) — фиксируем причину
        # пропуска в логе, чтобы оператор мог отличить «заявка вне формата ТЗ»
        # от потерянной/сломанной заявки.
        reasons = []
        if not parsed.queues:
            reasons.append("нет маркера 1 «К каким очередям задач нужен доступ?»")
        if not parsed.rights:
            reasons.append("нет маркера 2 «Запрашиваемые права»")
        if not parsed.emails:
            reasons.append("нет маркера 3 «Корпоративный E-mail»")
        if not parsed.initiator:
            reasons.append("нет маркера 4 «Ваш рабочий email» — спецлогика не сработает")
        if not parsed.custom_queues and not parsed.custom_groups:
            reasons.append("нет глобальных маркеров «Кастом:»/«Кастом группы:»")
        log.info(
            "Задача %s: пропущена — формат не соответствует ТЗ: %s",
            key, "; ".join(reasons) or "неизвестная причина",
        )

    # ------------------------------------------------------------------
    # Сканирование новых пользователей Cloud Identity Hub
    # ------------------------------------------------------------------
    def scan_new_cloud_users(
        self,
        ignore_delta: bool = False,
        specific_emails: set[str] | None = None,
    ) -> None:
        # Режим конкретные юзеры (config.SPECIFIC_USERS_EMAILS) имеет
        # наивысший приоритет: обрабатываются ТОЛЬКО indicated email и
        # независимо от JOINED_INTERVAL_DAYS / IGNORE_DELTA_ALL_USERS
        # (ТЗ: «не важно новые юзеры или нет»). При этом снимок Cloud
        # всё равно сохраняется, чтобы не ломать вычисление дельты на
        # следующих запусках в других режимах.
        if specific_emails:
            try:
                members = set(self.identity.list_members())
            except Exception as exc:
                log.error(
                    "IdentityHub: не получили участников Cloud "
                    "(режим конкретные юзеры): %s",
                    exc,
                )
                return
            self._save_snapshot(members)
            targets = sorted(specific_emails)
            log.info(
                "Режим «конкретные юзеры» — потенциально %d email в Cloud",
                len(targets),
            )
        elif not ignore_delta and JOINED_INTERVAL_DAYS <= 0:
            log.info("Сканирование новых пользователей отключено (JOINED_INTERVAL_DAYS=0)")
            return
        else:
            users = self.identity.list_members()
            current = set(users)  # ключи словаря {email: subjectId} — это email
            previous = set()
            if os.path.exists(CLOUD_SNAPSHOT_FILE):
                try:
                    with open(CLOUD_SNAPSHOT_FILE, "r", encoding="utf-8") as fh:
                        previous = set(json.load(fh))
                except (OSError, json.JSONDecodeError):
                    log.error("cloud_users_snapshot.json повреждён — считаю пустым")
            self._save_snapshot(current)
            if ignore_delta:
                # Режим «все юзеры без привязки ко времени»: обрабатываем
                # всех, кто есть в организации (кроме тех, кто уже обработан
                # в рамках scan_new_cloud_users на текущем запуске).
                targets = sorted(current)
                log.info(
                    "Режим «все юзеры» активен — потенциально %d участников Cloud",
                    len(targets),
                )
            else:
                if not previous:
                    log.info("Первый запуск — снимок участников Cloud сохранён (%d), новых нет", len(current))
                    return
                delta = current - previous
                if not delta:
                    log.info("Новых участников Cloud за интервал нет")
                    return
                targets = sorted(delta)
                log.info("Новых участников Cloud за интервал: %d", len(targets))

        # «Продолжение» прерванного запуска: старт с стартового email
        # (config.DEFAULT_ACCESS_START_EMAIL). Порядок обработки детерминирован
        # (sorted), поэтому уже обработанных пользователей (до стартового по
        # алфавиту) касаться не нужно, а обрабатываются все от стартового и
        # ниже.
        targets = self._filter_from_start(targets)
        if not targets:
            log.info("Нет пользователей для обработки после стартового — выход")
            return

        # Обход Cloud через Teams с обработкой уволенных (отсутствующих в
        # Teams). Цепочки иерархии кэшируются в graph._chain_cache, поэтому
        # _apply_default_rules_to_new_user ниже не вызывает повторных
        # навигаций по Teams.
        # Повторная обработка увалённых (требование ТЗ 3): повторить скан до
        # 4 попыток, чтобы справиться с лагами интерфейса Teams — иногда
        # карточка пользователя не открывается с первого раза. Прерываемся,
        # как только увалённые больше не определяются.
        targets_lower = {e.lower() for e in targets}
        terminated: list[str] = []
        for attempt in range(1, 5):
            self.graph.scan_cloud_users(targets)
            terminated = [
                e for e in self.graph.scan_terminated_emails
                if e.lower() in targets_lower
            ]
            if not terminated:
                break
            log.info(
                "Скан Cloud: увалённые после попытки %d/4 — %d",
                attempt,
                len(terminated),
            )

        self.terminated_cloud_emails = terminated
        terminated_lower = {e.lower() for e in terminated}
        if terminated:
            log.info(
                "Скан Cloud: увалённые (нет в Teams) не обработаны после "
                "4 попыток — %d",
                len(terminated),
            )
            for email in terminated:
                log.info(
                    "Скан Cloud: %s — финальный вердикт: всё ещё отсутствует "
                    "в Teams, дефолт-доступ не выдан",
                    email,
                )

        for email in targets:
            if email.lower() in terminated_lower:
                log.info(
                    "Скан Cloud: %s отсутствует в Teams (уволён) — пропуск",
                    email,
                )
                continue
            self._apply_default_rules_to_new_user(email)

    def _filter_from_start(self, sorted_targets: list[str]) -> list[str]:
        """Отфильтровать отсортированный список начиная со стартового email.

        Реализует «продолжение» прерванного выдачи дефолт-доступа.
        Порядок обработки детерминирован (sorted), поэтому уже обработанные
        пользователи (до стартового по алфавиту) не затрагиваются.
        """
        start = DEFAULT_ACCESS_START_EMAIL
        if not start:
            return sorted_targets
        start_lower = start.lower()
        kept = [e for e in sorted_targets if e.lower() >= start_lower]
        if len(kept) != len(sorted_targets):
            log.info(
                "Режим «продолжение» — старт с «%s», обрабатываю %d из %d",
                start,
                len(kept),
                len(sorted_targets),
            )
        return kept

    def _apply_default_rules_to_new_user(self, email: str) -> None:
        if self._is_inactive(email):
            log.info(
                "Cloud-скан: пропускаю неактивного %s в _apply_default_rules_to_new_user",
                email,
            )
            return
        for rule in self.rules:
            if not rule.group_name or rule.only_by_consent:
                continue
            ok, label = self._match_default(email, rule)
            if ok and not self.is_group_member(rule.group_name, email):
                if self.grant_group("Скан Cloud", rule.group_name, email, "Дефолт-доступ: " + label):
                    if "Руководитель" in label:
                        self._grant_manager_recursion(
                            "Скан Cloud", rule.group_name, email, label
                        )

    def _save_snapshot(self, emails) -> None:
        with open(CLOUD_SNAPSHOT_FILE, "w", encoding="utf-8") as fh:
            json.dump(sorted(emails), fh, ensure_ascii=False)

    # ------------------------------------------------------------------
    # Отзыв истёкших временных доступов
    # ------------------------------------------------------------------
    def expire_temp_accesses(self) -> None:
        expired = self.temp.expired()
        for rec in expired:
            email, kind, resource = rec["email"], rec["kind"], rec["resource"]
            log.info(
                "Временный доступ %s:%s для %s истёк (%s) — отзываю",
                kind, resource, email, rec.get("expires"),
            )
            try:
                if kind == "queue":
                    rights = rec.get("rights") or RIGHTS_READ
                    self.tracker.revoke_user_access(resource, email, rights)
                elif kind == "group":
                    self.identity.remove_user_from_group(resource, email)
                self.temp.remove(email, kind, resource)
                log.info("Временный доступ %s:%s для %s отозван", kind, resource, email)
            except Exception as exc:
                log.error(
                    "Не удалось отозвать временный доступ %s:%s для %s: %s",
                    kind, resource, email, exc,
                )


def _agree_all_ok(description: str) -> bool:
    import re
    return bool(re.search(r"^\s*Согласиться со всем:\s*(Ок|ок|OK)\s*$", description or "", re.M))


def _ordered(emails: list[str], order: list[str]) -> list[str]:
    return [e for e in order if e in emails] + [e for e in emails if e not in order]
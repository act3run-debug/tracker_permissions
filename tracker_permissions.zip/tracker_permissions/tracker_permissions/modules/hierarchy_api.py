# -*- coding: utf-8 -*-
"""API для получения иерархии руководителей через Microsoft Teams (playwright).

Замена Graph API. Использует Edge + CDP для навигации по Teams и извлечения
иерархии руководителей из вкладки Organization профиля пользователя.

Аналогично get-managers-hierarchy.py, но без ожидания действий пользователя.
"""

from __future__ import annotations

import re
import time
import subprocess
import os

from playwright.sync_api import sync_playwright, expect
from logging_conf import log
from special_logic import is_internal

# === Профиль и порт CDP ===
AUTOMATION_PROFILE = r"C:\Users\kvfv307\AppData\Local\ChromeAutomation"
CDP_PORT = 9222

EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

# === Универсальные селекторы (RU + EN) ===
SHOW_MORE_SELECTORS = [
    "button[aria-label*='скрыт']",
    "button[aria-label*='Показать еще']",
    "button[aria-label*='hidden managers']",
    "button:has-text('Показать еще')",
    "button:has-text('Show')",
]

VIEW_PROFILE_SELECTORS = [
    "button[aria-label*='View profile']",
    "button[aria-label*='Просмотреть профиль']",
    "button[aria-label*='просмотреть профиль']",
    "button[aria-label*='Посмотреть профиль']",
    "button:has-text('View profile')",
    "button:has-text('Просмотреть профиль')",
    "button:has-text('Посмотреть профиль')",
]

EMAIL_SELECTORS = [
    "button[aria-label^='Email:']",
    "button[aria-label^='Электронная почта:']",
    "button[aria-label*='Email:']",
    "button[aria-label*='почта:']",
    "button[aria-label*='@']",
]

BACK_SELECTORS = [
    "button[data-testid='NavigationBackButton']",
    "button[aria-label='Back']",
    "button[aria-label='Назад']",
    "button[title='Back']",
    "button[title='Назад']",
]

ORG_SELECTORS = [
    "#LPC_Header_TabBar_Organization",
    "button[name='Organization']",
    "[data-content='Organization']",
]

CLOSE_CARD_SELECTORS = [
    "button[data-testid='NavigationCloseButton']",
    "button[aria-label='Закрыть']",
    "button[aria-label='Close']",
    "button[title='Закрыть']",
    "button[title='Close']",
]


class HierarchyAPIError(RuntimeError):
    """Ошибка получения иерархии."""
    pass


def _find_element_anywhere(page, selectors, timeout=15000):
    """Быстрый поиск элемента по списку селекторов в page и всех iframe'ах."""
    if isinstance(selectors, str):
        selectors = [selectors]

    deadline = time.time() + timeout / 1000
    while time.time() < deadline:
        for selector in selectors:
            try:
                candidate = page.locator(selector)
                if candidate.count() > 0:
                    return candidate.first, page, selector
            except Exception:
                pass
            for frame in page.frames:
                try:
                    candidate = frame.locator(selector)
                    if candidate.count() > 0:
                        return candidate.first, frame, selector
                except Exception:
                    continue
        time.sleep(0.2)
    return None, None, None


def _wait_for_any(page, selectors, timeout=15000):
    return _find_element_anywhere(page, selectors, timeout)


def _expand_all_managers(page, container):
    """Разворачивает всех менеджеров."""
    max_iterations = 15
    for iteration in range(max_iterations):
        btn, _, _ = _find_element_anywhere(page, SHOW_MORE_SELECTORS, timeout=500)
        if not btn:
            break
        btn.scroll_into_view_if_needed()
        btn.click(force=True)


def _clean_manager_name(aria_label: str) -> str:
    """Извлекает имя руководителя из aria-label Teams.

    aria-label руководителя Teams имеет вид
    «Имя, Фамилия, Должность, Компания, Отдел, N отчётов», где каждое поле
    обособлено запятыми, а последнее поле — счётчик отчётов «N отчётов»
    (например «Soriot, Pascal, Chief Executive, AstraZeneca, COA, 141&nbsp;658
    отчётов»). Возвращаем все поля до счётчика; сам счётчик исключается.
    """
    if not aria_label:
        return ""
    fields = [field.strip() for field in aria_label.split(",")]
    # Отбрасываем счётчик «N отчётов» (число перед словом «отчётов»).
    fields = [field for field in fields if not re.search(r"\d.*отчётов", field)]
    return ", ".join(fields)


def _extract_hierarchy(page, container, target_email: str, email_cache: dict[str, str]):
    """Извлекает иерархию с гарантированным поиском менеджера при перезапуске.

    При обнаружении email, совпадающего с target_email (целевым пользователем),
    выполняет перезапуск открытия профиля для корректного продолжения обхода.

    email_cache — кэш «чистое имя менеджера → почта». Если почта менеджера уже
    известна (уже была извлечена в этом запуске), карточку не открываем.
    """
    hierarchy = []

    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
        state='visible', timeout=20000
    )

    _expand_all_managers(page, container)

    processed = 0
    while True:
        managers = container.locator("ol button[id^='org-explorer-manager-']")
        total = managers.count()
        if processed >= total:
            break

        i = processed
        try:
            # Получаем свежую ссылку на менеджера
            manager_btn = managers.nth(i)
            aria_label = manager_btn.get_attribute("aria-label") or ""
            # Имя: всё до счётчика «N отчётов» (включая должность, компанию и др.).
            name = _clean_manager_name(aria_label)

            # Проверяем кэш «чистое имя → почта»: если почта уже известна
            # (уже была извлечена из иерархии в этом запуске), открывать
            # карточку менеджера повторно не нужно.
            if name in email_cache:
                email = email_cache[name]
            else:
                # 1. Клик на руководителя
                manager_btn.scroll_into_view_if_needed()
                manager_btn.click(force=True)
                time.sleep(1)

                # 2. Ожидаем и кликаем "Просмотреть профиль"
                view_btn, _, _ = _wait_for_any(page, VIEW_PROFILE_SELECTORS, timeout=15000)
                if not view_btn:
                    raise HierarchyAPIError("Кнопка 'Просмотреть профиль' не появилась")

                expect(view_btn).to_be_visible(timeout=5000)
                view_btn.scroll_into_view_if_needed()
                view_btn.click(force=True)
                time.sleep(1)

                # 3. Ожидаем email
                email_btn, _, _ = _wait_for_any(page, EMAIL_SELECTORS, timeout=15000)
                if not email_btn:
                    raise HierarchyAPIError("Email не появился в профиле")

                expect(email_btn).to_be_visible(timeout=5000)

                email = email_btn.get_attribute("aria-label")
                email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()

                # 4. Клик назад (возвращаемся к списку)
                back_btn_final, _, _ = _wait_for_any(page, BACK_SELECTORS, timeout=10000)
                if back_btn_final:
                    back_btn_final.click(force=True)
                    time.sleep(1)

                # Ждём возврата к списку
                container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                    state='visible', timeout=10000
                )

                # После возврата список мог свернуться — разворачиваем
                _expand_all_managers(page, container)

                # Запоминаем почту, чтобы не открывать карточку повторно.
                email_cache[name] = email

            hierarchy.append({"name": name, "email": email})
            processed += 1

        except HierarchyAPIError:
            raise
        except Exception as e:
            # В случае ошибки восстановления - пробуем вернуться к списку
            try:
                back_btn, _, _ = _find_element_anywhere(page, BACK_SELECTORS, timeout=5000)
                if back_btn:
                    back_btn.click(force=True)
                    time.sleep(0.5)
                    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                        state='visible', timeout=10000
                    )
                    _expand_all_managers(page, container)
            except Exception:
                pass

    return hierarchy


def _extract_hierarchy_with_retry(page, container, target_email: str, email_cache: dict[str, str]):
    """Извлекает иерархию с гарантированным поиском менеджера при перезапуске.

    При обнаружении email, совпадающего с target_email (целевым пользователем),
    выполняет перезапуск открытия профиля для корректного продолжения обхода.

    email_cache — кэш «чистое имя менеджера → почта». Если почта менеджера уже
    известна (уже была извлечена из иерархии в этом запуске), карточку не открываем.
    """
    hierarchy = []

    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
        state='visible', timeout=20000
    )

    _expand_all_managers(page, container)

    processed = 0
    while True:
        managers = container.locator("ol button[id^='org-explorer-manager-']")
        total = managers.count()
        if processed >= total:
            break

        i = processed
        try:
            # Получаем свежую ссылку на менеджера
            manager_btn = managers.nth(i)
            aria_label = manager_btn.get_attribute("aria-label") or ""
            # Имя: всё до счётчика «N отчётов» (включая должность, компанию и др.).
            name = _clean_manager_name(aria_label)

            # Проверяем кэш «чистое имя → почта»: если почта уже известна
            # (уже была извлечена из иерархии в этом запуске), открывать
            # карточку менеджера повторно не нужно.
            if name in email_cache:
                email = email_cache[name]
            else:
                # 1. Клик на руководителя
                manager_btn.scroll_into_view_if_needed()
                manager_btn.click(force=True)
                time.sleep(0.5)

                # 2. Ожидаем и кликаем "Просмотреть профиль"
                view_btn, _, _ = _wait_for_any(page, VIEW_PROFILE_SELECTORS, timeout=15000)
                if not view_btn:
                    raise HierarchyAPIError("Кнопка 'Просмотреть профиль' не появилась")

                expect(view_btn).to_be_visible(timeout=5000)
                view_btn.scroll_into_view_if_needed()
                view_btn.click(force=True)
                time.sleep(0.5)

                # 3. Ожидаем email и ПРОВЕРЯЕМ на совпадение с целевым пользователем
                email_btn, _, _ = _wait_for_any(page, EMAIL_SELECTORS, timeout=15000)
                if not email_btn:
                    raise HierarchyAPIError("Email не появился в профиле")

                expect(email_btn).to_be_visible(timeout=5000)

                email = email_btn.get_attribute("aria-label")
                email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()

                retry_count = 0
                max_retries = 3

                # Если email совпадает с целевым, перезапускаем открытие профиля ЗАНОВО
                while email.lower() == target_email.lower() and retry_count < max_retries:
                    # a) Возвращаемся назад, чтобы закрыть залипшую карточку
                    back_btn, _, _ = _wait_for_any(page, BACK_SELECTORS, timeout=10000)
                    if back_btn:
                        back_btn.click(force=True)
                        time.sleep(1)

                    # b) Ждём возврата к списку
                    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                        state='visible', timeout=10000
                    )

                    # c) Снова разворачиваем список, если он свернулся
                    _expand_all_managers(page, container)

                    # d) ЗАНОВО находим нужного менеджера по индексу (i)
                    managers = container.locator("ol button[id^='org-explorer-manager-']")
                    manager_btn = managers.nth(i)

                    # e) Снова открываем его профиль
                    manager_btn.scroll_into_view_if_needed()
                    manager_btn.click(force=True)
                    time.sleep(1)

                    view_btn_retry, _, _ = _wait_for_any(page, VIEW_PROFILE_SELECTORS, timeout=10000)
                    if view_btn_retry:
                        view_btn_retry.scroll_into_view_if_needed()
                        view_btn_retry.click(force=True)
                        time.sleep(1.5)

                        email_btn_retry, _, _ = _wait_for_any(page, EMAIL_SELECTORS, timeout=10000)
                        if email_btn_retry:
                            email = email_btn_retry.get_attribute("aria-label")
                            email = email.replace("Email: ", "").replace("Электронная почта: ", "").strip()

                    retry_count += 1

                # 4. Клик назад (возвращаемся к списку)
                back_btn_final, _, _ = _wait_for_any(page, BACK_SELECTORS, timeout=10000)
                if back_btn_final:
                    back_btn_final.click(force=True)
                    time.sleep(0.5)

                # Ждём возврата к списку
                container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                    state='visible', timeout=10000
                )

                # После возврата список мог свернуться — разворачиваем перед следующей итерацией
                _expand_all_managers(page, container)

                # Запоминаем почту, чтобы не открывать карточку повторно.
                email_cache[name] = email

                # Добавляем в иерархию только если email не совпадает с целевым
                if email.lower() != target_email.lower():
                    hierarchy.append({"name": name, "email": email})

            processed += 1

        except HierarchyAPIError:
            raise
        except Exception as e:
            # В случае ошибки восстановления - пробуем вернуться к списку
            try:
                back_btn, _, _ = _find_element_anywhere(page, BACK_SELECTORS, timeout=5000)
                if back_btn:
                    back_btn.click(force=True)
                    time.sleep(0.5)
                    container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
                        state='visible', timeout=10000
                    )
                    _expand_all_managers(page, container)
            except Exception:
                pass

    return hierarchy


class HierarchyAPI:
    """API для получения иерархии руководителей через Microsoft Teams.

    Использует Edge + CDP для навигации по Teams.
    """

    def __init__(self):
        self._playwright = None
        self._browser = None
        self._page = None
        self._connected = False
        self._chain_cache: dict[str, list[str]] = {}
        # Кэш «чистое имя менеджера → почта» (в пределах одного запуска скрипта).
        # Позволяет не открывать карточку менеджера повторно, если его почта уже
        # была получена из иерархии другого пользователя.
        self._manager_email_by_name: dict[str, str] = {}
        # Cloud-юзеры, отсутствующие в Teams (уволённые), за последним прогоном
        # scan_cloud_users. Отчёт о них печатается в конце работы скрипта.
        self.scan_terminated_emails: list[str] = []

    def _ensure_browser(self):
        """Подключиться к Edge (или запустить новый) через CDP."""
        if self._connected:
            return

        try:
            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.connect_over_cdp(
                f"http://localhost:{CDP_PORT}"
            )
            self._connected = True
        except Exception:
            # Запускаем новый Edge
            edge_path = next((p for p in EDGE_PATHS if os.path.exists(p)), None)
            if not edge_path:
                raise HierarchyAPIError("Edge не найден!")

            subprocess.Popen([
                edge_path, f"--user-data-dir={AUTOMATION_PROFILE}",
                f"--remote-debugging-port={CDP_PORT}", "--no-first-run",
                "--no-default-browser-check", "--start-maximized",
            ])
            time.sleep(5)

            self._playwright = sync_playwright().start()
            self._browser = self._playwright.chromium.connect_over_cdp(
                f"http://localhost:{CDP_PORT}"
            )
            self._connected = True

        contexts = self._browser.contexts
        self._page = contexts[0].pages[0] if contexts else self._browser.new_context().new_page()

    def _ensure_teams_ready(self):
        """Открыть Teams и дождаться готовности."""
        if not self._page:
            self._ensure_browser()

        current_url = self._page.url
        if "teams.microsoft.com" in current_url:
            time.sleep(2)
            return

        self._page.goto("https://teams.microsoft.com/v2/")
        self._page.wait_for_load_state("domcontentloaded")
        time.sleep(5)

        try:
            self._page.wait_for_selector("input#ms-searchux-input", timeout=20000)
        except Exception:
            # Если Teams не загрузился, ждем авторизации
            self._page.wait_for_selector(
                "input#ms-searchux-input", timeout=120000
            )

    def _search_user(self, email: str):
        """Поиск пользователя в Teams.

        Возвращает None (и не тратит время на Teams), если e-mail не
        корпоративный (не домен astrazeneca.com / alexion.com). Это
        исключает поиск внешних/нескорпоративных учётных записей
        (например a.mahmutova@alial.group) в иерархии Teams.
        """
        if not is_internal(email):
            log.info(
                f"[hierarchy] Пропуск поиска {email}: не корпоративный адрес "
                f"(ignored, non-corporate)"
            )
            return None
        search_input = self._page.wait_for_selector("input#ms-searchux-input", timeout=20000)
        search_input.click()
        time.sleep(0.5)
        search_input.fill(email)
        time.sleep(1.5)
        self._page.keyboard.press("ArrowDown")
        time.sleep(0.5)
        self._page.keyboard.press("ArrowDown")
        time.sleep(0.5)
        self._page.keyboard.press("Enter")

    def _open_profile_and_org_tab(self, email: str = ""):
        """Открыть профиль пользователя и перейти на вкладку Organization.

        Возвращает container или None, если пользователь отсутствует в Teams:
        после «двух стрелки вниз» и Enter с ним не начинается чат (вероятно,
        увалён). В этом случае вызов должен перейти к следующему пользователю.
        """
        time.sleep(1)
        try:
            self._page.wait_for_selector(
                "ul[data-tid='chat-topic-menu'] div[data-person-mri]",
                timeout=10000,
            )
            profile_trigger = self._page.wait_for_selector(
                "ul[data-tid='chat-topic-menu'] div[data-person-mri]",
                timeout=20000,
            )
        except Exception:
            log.warning(
                "Teams: карточка для %s не открылась — отсутствует в Teams (увалён)",
                email,
            )
            return None

        profile_trigger.click()

        time.sleep(1)

        # Ищем вкладку Organization
        org_tab, container, _ = _find_element_anywhere(self._page, ORG_SELECTORS, timeout=15000)

        if not org_tab:
            for frame in [self._page] + self._page.frames:
                try:
                    candidate = frame.get_by_role("tab", name="Organization")
                    if candidate.count() > 0:
                        org_tab = candidate.first
                        container = frame
                        break
                except Exception:
                    continue

        if not org_tab:
            raise HierarchyAPIError("Вкладка Organization не появилась!")

        expect(org_tab).to_be_visible(timeout=10000)
        org_tab.click(force=True)

        container.locator("ol button[id^='org-explorer-manager-']").first.wait_for(
            state='visible', timeout=15000
        )

        return container

    def _close_profile_card(self):
        """Закрыть карточку профиля (вкладку Organization), чтобы можно было
        начать обработку следующего пользователя.

        Пока карточка не закрыта, новый поиск в Teams невозможен — следующий
        get_manager_chain падал бы с ошибкой. Закрываем по кнопке
        NavigationCloseButton, с резервом на Esc (аналогично референсу).
        """
        try:
            close_btn, _, _ = _find_element_anywhere(
                self._page, CLOSE_CARD_SELECTORS, timeout=8000
            )
            if close_btn:
                close_btn.scroll_into_view_if_needed()
                close_btn.click(force=True)
                time.sleep(0.5)
                return
        except Exception:
            pass
        # Резервный метод — клавиша Escape.
        try:
            self._page.keyboard.press("Escape")
            time.sleep(0.5)
        except Exception:
            pass

    def scan_cloud_users(self, emails) -> dict[str, list[str]]:
        """Дефолт-доступ: обход cloud-юзеров в порядке с обработкой увалённых.

        Для каждого email (в переданном порядке) открывает профиль в Teams.
        Если человек отсутствует в Teams (чат не начинается после
        «двух стрелок вниз» и Enter) — запоминаем его в
        self.scan_terminated_emails и пропускаем, продолжая со следующего
        email. Если сотрудник существует, место для раскрытия карточки
        появляется и обработка идёт как обычно.

        Цепочки иерархии сохраняются в self._chain_cache, поэтому
        get_manager_chain / get_direct_manager затем используют кэш без
        повторных навигаций. Возвращает {email: manager_chain} для найденных.
        """
        self.scan_terminated_emails = []
        # Email пользователей, для которых иерархию не удалось извлечь
        # даже после 4 попыток (требование ТЗ 3 — финальный вердикт).
        failing_emails: list[str] = []
        for email in emails:
            lower = email.lower()
            if lower in self._chain_cache:
                continue
            if not is_internal(email):
                # Не корпоративный адрес (например a.mahmutova@alial.group):
                # не ищем в Teams и не считаем увалённым.
                log.info(
                    f"[cloud] Пропуск {email}: не корпоративный "
                    f"(ignored, non-corporate)"
                )
                continue
            # Повторная обработка при ошибках иерархии (требование ТЗ 3):
            # до 4 попыток, чтобы справиться с лагами интерфейса Teams.
            # Прерываемся по успеху или исчерпании попыток.
            attempt = 0
            while attempt < 4:
                attempt += 1
                try:
                    self._ensure_teams_ready()
                    self._search_user(email)
                    container = self._open_profile_and_org_tab(email)
                    if container is None:
                        # Отсутствует в Teams (увалён) — переход к следующему.
                        log.info(
                            "Скан Cloud: %s отсутствует в Teams — пропуск "
                            "(дальше по списку)",
                            email,
                        )
                        self.scan_terminated_emails.append(email)
                        break
                    hierarchy = _extract_hierarchy_with_retry(
                        self._page, container, lower, self._manager_email_by_name
                    )
                    self._close_profile_card()
                    chain = [h["email"] for h in hierarchy if h.get("email")]
                    self._chain_cache[lower] = chain
                    break
                except HierarchyAPIError as exc:
                    # Ошибка восстановления иерархии (не «отсутствует в Teams»).
                    self._safe_close_card()
                    if attempt >= 4:
                        log.error(
                            "Скан Cloud: %s — финальный вердикт: всё ещё не "
                            "работает (%s) после 4 попыток",
                            email,
                            exc,
                        )
                        failing_emails.append(email)
                        break
                    log.warning(
                        "Скан Cloud: %s — ошибка иерархии, повторная "
                        "обработка, попытка %d/4",
                        email,
                        attempt,
                    )
                    continue
                except Exception as exc:
                    log.error("Скан Cloud: ошибка обработки %s: %s", email, exc)
                    self._safe_close_card()
                    if attempt >= 4:
                        log.error(
                            "Скан Cloud: %s — финальный вердикт: всё ещё не "
                            "работает (%s) после 4 попыток",
                            email,
                            exc,
                        )
                        failing_emails.append(email)
                        break
                    continue
        if failing_emails:
            log.error(
                "Скан Cloud: %d пользователей с ошибкой иерархии не обработаны "
                "после 4 попыток — финальный вердикт: дефолт-доступ не выдан: %s",
                len(failing_emails),
                ", ".join(failing_emails),
            )
        return {
            e: self._chain_cache[e.lower()]
            for e in emails
            if e.lower() in self._chain_cache
        }

    def _safe_close_card(self):
        """Пытаться закрыть карточку без исключений (после ошибки обработки)."""
        try:
            self._close_profile_card()
        except Exception:
            pass

    def get_manager_chain(self, email: str) -> list[str]:
        """Получить список всех email руководителей пользователя (по цепочке).

        Пустой список для некорпоративных адресов — их не должно быть в
        иерархии Teams (например a.mahmutova@alial.group).
        """
        if not is_internal(email):
            log.info(
                f"[hierarchy] Пустая цепочка для {email}: не корпоративный "
                f"(ignored, non-corporate)"
            )
            return []
        try:
            cache_key = email.lower()
            if cache_key in self._chain_cache:
                return self._chain_cache[cache_key]

            self._ensure_teams_ready()
            self._search_user(email)

            container = self._open_profile_and_org_tab()
            hierarchy = _extract_hierarchy_with_retry(
                self._page, container, email, self._manager_email_by_name
            )
            self._close_profile_card()

            chain = [h["email"] for h in hierarchy if h.get("email")]
            self._chain_cache[cache_key] = chain
            return chain

        except HierarchyAPIError:
            raise
        except Exception as e:
            raise HierarchyAPIError(f"Ошибка получения иерархии для {email}: {e}") from e

    def get_direct_manager(self, email: str) -> str | None:
        """Получить email прямого (ближайшего) руководителя.

        Цепочка иерархии кэшируется в get_manager_chain, поэтому получение
        прямого руководителя не вызывает повторного поиска того же юзера.
        """
        try:
            chain = self.get_manager_chain(email)
            return chain[0] if chain else None
        except HierarchyAPIError:
            raise
        except Exception as e:
            raise HierarchyAPIError(f"Ошибка получения прямого руководителя для {email}: {e}") from e

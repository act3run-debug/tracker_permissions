# -*- coding: utf-8 -*-
"""Тексты комментариев в заявках Трекер."""

from __future__ import annotations

from config import (
    PREFIX_AGREE_ALL,
    PREFIX_PROPOSE,
    PREFIX_CONFLICT,
    PREFIX_NON_CONFLICT,
    TEXT_RIGHTS_NOT_FIXED,
)


def make_counter(block: dict) -> str:
    return block.get("counter") or "1/1"


def render_group_block(block: dict) -> str:
    """Блок «Предлагаемые группы для юзера/юзеров ... в очередь <key>:»"""
    return block["text"]


def render_status_resolved(status: str) -> str:
    return f"Статус: {status}. Проверяется вручную."


def render_responsible_hint(login: str) -> str:
    return (
        "Ответственный за права доступа: "
        + (f"@{login}" if login else "не указан")
    )


def render_duplicates(keys: list[str]) -> str:
    return "В задаче указаны дублирующие доступы, уже выданные в задачах: " + ", ".join(keys)
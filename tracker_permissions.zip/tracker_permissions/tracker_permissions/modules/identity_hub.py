# -*- coding: utf-8 -*-
"""Клиент Cloud Identity Hub (Yandex Cloud Organization Manager API).

Используется для: поиска групп по имени, поиска subject-id участника
организации по email, добавления/удаления участников групп, листинга
участников организации (сканирование новых пользователей).
"""

from __future__ import annotations

import requests

from logging_conf import log


class IdentityHubError(RuntimeError):
    """Ошибка при обращении к Cloud Identity Hub."""


class IdentityHub:
    def __init__(self, iam_token: str, org_id: str, base_url: str):
        self.iam_token = iam_token
        self.org_id = org_id
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update(
            {"Authorization": f"Bearer {iam_token}", "Content-Type": "application/json"}
        )

    def _get(self, path: str, params: dict | None = None):
        resp = self.session.get(f"{self.base_url}{path}", params=params, timeout=60)
        if resp.status_code != 200:
            raise IdentityHubError(f"GET {path} -> {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    def _post(self, path: str, body: dict | None = None):
        resp = self.session.post(f"{self.base_url}{path}", json=body or {}, timeout=90)
        if resp.status_code not in (200, 201):
            raise IdentityHubError(f"POST {path} -> {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    # ------------------------------------------------------------------
    # Группы
    # ------------------------------------------------------------------
    def list_groups(self) -> dict[str, str]:
        """Словарь {имя группы: id группы} для организации."""
        result: dict[str, str] = {}
        token = ""
        while True:
            params = {"organizationId": self.org_id, "pageSize": 1000}
            if token:
                params["pageToken"] = token
            data = self._get("/organization-manager/v1/groups", params)
            for g in data.get("groups", []):
                result[g.get("name", "")] = g.get("id", "")
            token = data.get("nextPageToken")
            if not token:
                break
        return result

    def get_group_id(self, group_name: str) -> str | None:
        return self.list_groups().get(group_name)

    def list_group_members(self, group_name: str) -> set[str]:
        """Множество email (нижний регистр) участников группы.

        Получает group_id через ``get_group_id``, затем вызывает
        ``GET /organization-manager/v1/groups/{id}:listMembers``.
        API возвращает только subjectId участников, поэтому email
        восстанавливаются по обратному индексу участников организации.
        """
        group_id = self.get_group_id(group_name)
        if not group_id:
            return set()
        subject_ids: list[str] = []
        token = ""
        while True:
            params = {"pageSize": 1000}
            if token:
                params["pageToken"] = token
            path = f"/organization-manager/v1/groups/{group_id}:listMembers"
            data = self._get(path, params)
            subject_ids.extend(
                m.get("subjectId")
                for m in data.get("members", [])
                if m.get("subjectId")
            )
            token = data.get("nextPageToken")
            if not token:
                break
        email_by_subject = {
            sub: email for email, sub in self.list_members().items()
        }
        return {
            email_by_subject[s] for s in subject_ids if s in email_by_subject
        }

    # ------------------------------------------------------------------
    # Участники организации
    # ------------------------------------------------------------------
    def list_members(self) -> dict[str, str]:
        """Словарь {email(нижний регистр): subjectId} участников организации."""
        result: dict[str, str] = {}
        token = ""
        while True:
            params = {"pageSize": 1000}
            if token:
                params["pageToken"] = token
            path = f"/organization-manager/v1/organizations/{self.org_id}/users"
            data = self._get(path, params)
            for u in data.get("users", []):
                claims = u.get("subjectClaims") or {}
                email = (claims.get("email") or "").lower()
                sub = claims.get("sub")
                if email and sub:
                    result[email] = sub
            token = data.get("nextPageToken")
            if not token:
                break
        return result

    def get_subject_id(self, email: str) -> str | None:
        return self.list_members().get(email.lower())

    # ------------------------------------------------------------------
    # Добавление/удаление участников группы
    # ------------------------------------------------------------------
    def update_group_members(self, group_name: str, subject_id: str, action: str) -> bool:
        """Добавляет (ADD) или удаляет (REMOVE) участника группы по subject_id."""
        group_id = self.get_group_id(group_name)
        if not group_id:
            raise IdentityHubError(f"Группа '{group_name}' не найдена в Cloud Identity Hub")
        body = {"memberDeltas": [{"action": action, "subjectId": subject_id}]}
        path = f"/organization-manager/v1/groups/{group_id}:updateMembers"
        self._post(path, body)
        log.info(
            "Cloud: участник %s %s группу '%s' (id=%s)",
            subject_id,
            "добавлен в" if action == "ADD" else "удалён из",
            group_name,
            group_id,
        )
        return True

    def add_user_to_group(self, group_name: str, email: str) -> bool:
        subject_id = self.get_subject_id(email)
        if not subject_id:
            raise IdentityHubError(
                f"Пользователь {email} не найден среди участников организации — "
                f"требуется приглашение внешнего пользователя в Cloud Identity Hub"
            )
        return self.update_group_members(group_name, subject_id, "ADD")

    def remove_user_from_group(self, group_name: str, email: str) -> bool:
        subject_id = self.get_subject_id(email)
        if not subject_id:
            raise IdentityHubError(f"Пользователь {email} не найден в организации")
        return self.update_group_members(group_name, subject_id, "REMOVE")
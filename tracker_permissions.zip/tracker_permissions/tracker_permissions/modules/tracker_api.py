# -*- coding: utf-8 -*-
"""Клиент Yandex Tracker API (v3)."""

from __future__ import annotations

import time
from collections.abc import Mapping

import requests

from logging_conf import log

# Статусы, при которых стоит повторить запрос (rate limit и временные сбои).
_RETRYABLE_STATUSES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 5
_RETRY_BASE_DELAY = 1  # экспоненциальный backoff: 1, 2, 4, 8 c


class TrackerError(RuntimeError):
    """Ошибка при обращении к Tracker API."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


def _retry(fn):
    """Повторяет вызов при retryable-статусах с экспоненциальным backoff."""

    def wrapper(*args, **kwargs):
        for attempt in range(_MAX_RETRIES):
            try:
                return fn(*args, **kwargs)
            except TrackerError as exc:
                if exc.status_code not in _RETRYABLE_STATUSES:
                    raise
                delay = _RETRY_BASE_DELAY * (2 ** attempt)
                log.warning(
                    "Tracker API: %s (попытка %d/%d), повтор через %ds",
                    exc,
                    attempt + 1,
                    _MAX_RETRIES,
                    delay,
                )
                time.sleep(delay)
        raise TrackerError(f"Превышено число повторов ({_MAX_RETRIES}): {fn}")

    return wrapper


class TrackerAPI:
    """Тонкая обёртка над Tracker REST API.

    Авторизация — OAuth-токен и ``X-Cloud-Org-Id`` (см. credentials).
    """

    def __init__(self, token: str, org_id: str, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "X-Cloud-Org-Id": org_id,
            }
        )
        # Заголовки последнего успешного ответа (X-Total-Pages и т.п.).
        self._last_response_headers: Mapping[str, str] = {}

    # ------------------------------------------------------------------
    # Низкоуровневые запросы
    # ------------------------------------------------------------------
    @_retry
    def _get(self, path: str, params: dict | None = None):
        resp = self.session.get(f"{self.base_url}{path}", params=params, timeout=60)
        if resp.status_code != 200:
            raise TrackerError(
                f"GET {path} -> {resp.status_code}: {resp.text[:500]}",
                resp.status_code,
            )
        self._last_response_headers = resp.headers
        return resp.json()

    @_retry
    def _post(self, path: str, body: dict | None = None):
        resp = self.session.post(
            f"{self.base_url}{path}", json=body or {}, timeout=60
        )
        if resp.status_code not in (200, 201):
            raise TrackerError(
                f"POST {path} -> {resp.status_code}: {resp.text[:500]}",
                resp.status_code,
            )
        self._last_response_headers = resp.headers
        return resp.json()

    @_retry
    def _patch(self, path: str, body: dict | None = None, ok_status=(200,)):
        resp = self.session.patch(
            f"{self.base_url}{path}", json=body or {}, timeout=60
        )
        if resp.status_code not in ok_status:
            raise TrackerError(
                f"PATCH {path} -> {resp.status_code}: {resp.text[:500]}",
                resp.status_code,
            )
        self._last_response_headers = resp.headers
        return resp.json()

    # ------------------------------------------------------------------
    # Задачи
    # ------------------------------------------------------------------
    def search_issues(self, filter_dict: dict) -> list[dict]:
        """Поиск задач (POST /v3/issues/_search) с пагинацией.

        В фильтр всегда добавляется ``resolution: empty()``, чтобы не
        выкачивать закрытые задачи (у них resolution заполнен): это
        сокращает число запросов и не упирается в rate limit (429).
        """
        body = {"filter": {**filter_dict, "resolution": "empty()"}}
        page = 1
        items: list[dict] = []
        per_page = 50
        while page <= 200:
            data = self._post(
                f"/issues/_search?expand=transitions&perPage={per_page}&page={page}",
                body,
            )
            items.extend(data)
            if len(data) < per_page:
                break
            page += 1
        return items

    def get_issue(self, key: str) -> dict:
        return self._get(f"/issues/{key}")

    def update_issue_description(self, key: str, description: str) -> dict:
        """Перезаписывает описание задачи (PATCH /v3/issues/{key})."""
        return self._patch(f"/issues/{key}", {"description": description})

    # ------------------------------------------------------------------
    # Переходы по статусам
    # ------------------------------------------------------------------
    def get_transitions(self, key: str) -> list[dict]:
        return self._get(f"/issues/{key}/transitions")

    def transition_to_status(self, key: str, target_status_key: str) -> bool:
        """Переводит задачу в статус с ключом ``target_status_key``.

        Ищет первый доступный переход, ведущий в нужный статус.
        """
        for tr in self.get_transitions(key):
            to = tr.get("to") or {}
            if to.get("key") == target_status_key:
                self._post(f"/issues/{key}/transitions/{tr['id']}/_execute", {})
                log.info("Задача %s переведена в статус '%s'", key, target_status_key)
                return True
        log.warning(
            "Задача %s: доступный переход в статус '%s' не найден "
            "(доступные: %s)",
            key,
            target_status_key,
            [tr.get("to", {}).get("key") for tr in self.get_transitions(key)],
        )
        return False

    # ------------------------------------------------------------------
    # Доступы к очередям
    # ------------------------------------------------------------------
    def get_queue_permissions(self, queue: str) -> dict:
        """Полный список прав доступа очереди (PATCH-эндпоинт из доков)."""
        resp = self.session.get(
            f"{self.base_url}/queues/{queue}/permissions", timeout=60
        )
        if resp.status_code != 200:
            raise TrackerError(
                f"GET /queues/{queue}/permissions -> {resp.status_code}: "
                f"{resp.text[:500]}"
            )
        return resp.json()

    def get_group_permissions(self, queue: str, group_id) -> dict:
        path = f"/queues/{queue}/permissions/groups/{group_id}"
        try:
            return self._get(path)
        except TrackerError:
            return {}

    def grant_user_access(self, queue: str, login: str, rights: str) -> bool:
        """Выдача индивидуального доступа пользователю в очередь.

        ``rights``: 'Чтение' или 'Создание, редактирование, чтение'.
        Используется объектная форма (add) — существующие права не трогаем.
        """
        body: dict = {}
        if rights == "Чтение":
            body["read"] = {"users": {"add": [login]}}
        elif rights == "Создание, редактирование, чтение":
            body = {
                "read": {"users": {"add": [login]}},
                "write": {"users": {"add": [login]}},
                "create": {"users": {"add": [login]}},
            }
        else:
            raise TrackerError(f"Неизвестный уровень прав: {rights!r}")
        self._patch(f"/queues/{queue}/permissions", body)
        log.info(
            "Трекер: индивидуальный доступ '%s' выдан %s в очередь %s",
            rights,
            login,
            queue,
        )
        return True

    def revoke_user_access(self, queue: str, login: str, rights: str) -> bool:
        """Отзыв индивидуального доступа (для временных доступов)."""
        body: dict = {}
        if rights == "Чтение":
            body["read"] = {"users": {"remove": [login]}}
        else:
            body = {
                "read": {"users": {"remove": [login]}},
                "write": {"users": {"remove": [login]}},
                "create": {"users": {"remove": [login]}},
            }
        self._patch(f"/queues/{queue}/permissions", body)
        log.info(
            "Трекер: индивидуальный доступ '%s' отозван у %s в очереди %s",
            rights,
            login,
            queue,
        )
        return True

    # ------------------------------------------------------------------
    # Справочники
    # ------------------------------------------------------------------
    def get_groups(self) -> list[dict]:
        """Все группы организации (id + name)."""
        items = []
        page = 1
        while True:
            data = self._get("/groups", {"perPage": "200", "page": str(page)})
            items.extend(data)
            # X-Total-Pages приходит в заголовках ОТВЕТА (сохранены в _get),
            # а не в заголовках запроса сессии.
            total_pages = int(self._last_response_headers.get("X-Total-Pages", "1"))
            if not data or page >= total_pages:
                break
            page += 1
        return items

    def get_statuses(self) -> list[dict]:
        return self._get("/statuses")

    def get_user(self, login: str) -> dict | None:
        try:
            return self._get(f"/users/{login}")
        except TrackerError:
            return None

    def get_users_last_login(self) -> list[dict]:
        """Получить всех пользователей организации с lastLoginDate.

        Использует GET /v3/users/_relative. Возвращает список словарей с
        полями login, display, email и lastLoginDate.
        """
        all_users: list[dict] = []
        per_page = 100
        last_uid: str | None = None

        while True:
            params: dict = {"perPage": per_page}
            if last_uid:
                params["id"] = last_uid

            data = self._get("/users/_relative", params)
            users_list = data.get("users", [])
            if not users_list:
                break

            all_users.extend(users_list)

            has_next = data.get("hasNext", False)
            if not has_next:
                break

            last_user = users_list[-1]
            last_uid = last_user.get("uid") or last_user.get("trackerUid")

            time.sleep(0.1)

        return all_users
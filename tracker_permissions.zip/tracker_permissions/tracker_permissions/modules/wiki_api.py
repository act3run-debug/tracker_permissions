# -*- coding: utf-8 -*-
"""Клиент Yandex Wiki API (v1).

Используется для чтения Технической таблицы из markdown-разметки страницы
(GET /pages/{id}?fields=content). Динамические grid-таблицы на целевой
странице отсутствуют, поэтому таблица парсится из content страницы.
"""

from __future__ import annotations

import requests

from logging_conf import log


class WikiError(RuntimeError):
    """Ошибка при обращении к Wiki API."""


class WikiAPI:
    def __init__(self, token: str, org_id: str, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"OAuth {token}",
                "Content-Type": "application/json",
                "X-Cloud-Org-Id": org_id,
            }
        )

    def _get(self, path: str, params: dict | None = None):
        resp = self.session.get(f"{self.base_url}{path}", params=params, timeout=60)
        if resp.status_code != 200:
            raise WikiError(f"GET {path} -> {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    def get_page_by_slug(self, slug: str) -> dict:
        """Получение страницы по slug (как в примере из wiki_api.md)."""
        data = self._get("/pages", {"slug": slug})
        # API может вернуть список страниц или единичный объект
        if isinstance(data, list):
            if not data:
                raise WikiError(f"Страница не найдена по slug: {slug}")
            return data[0]
        return data

    def get_page_content(self, slug: str) -> str:
        """Markdown-содержимое страницы (GET /pages/{id}?fields=content).

        Техническая таблица встроена в content страницы как markdown-разметка
        со всеми столбцами ТЗ, поэтому динамические grid-таблицы не
        используются.
        """
        page = self.get_page_by_slug(slug)
        pid = int(page.get("id") or 0)
        log.info("Wiki: страница '%s' (id=%s) загружена", slug, pid)
        data = self._get(f"/pages/{pid}", {"fields": "content"})
        content = data.get("content") or ""
        if not content.strip():
            raise WikiError(f"Страница '{slug}' не содержит markdown-контента")
        return content
# -*- coding: utf-8 -*-
"""Клиент Microsoft Graph API — заменено на HierarchyAPI (playwright).

Теперь используется HierarchyAPI для получения иерархии руководителей
из Microsoft Teams через Edge browser с CDP.
"""

from __future__ import annotations

from modules.hierarchy_api import HierarchyAPI, HierarchyAPIError


class GraphError(RuntimeError):
    """Ошибка при обращении к Graph API (теперь Hierarchy API)."""


class GraphAPI:
    """Обертка над HierarchyAPI для совместимости с旧 кодом.

    Использует HierarchyAPI вместо Graph API для получения
    иерархии руководителей через Microsoft Teams.
    """

    def __init__(
        self,
        client_id: str,
        tenant_id: str,
        cache_file: str,
        access_token_file: str,
        base_url: str,
    ):
        # Инициализируем HierarchyAPI
        self._hierarchy_api = HierarchyAPI()

    @property
    def scan_terminated_emails(self):
        """Cloud-юзеры, отсутствующие в Teams (увалённые) за последним scan.

        Проксирует поле HierarchyAPI.scan_terminated_emails, чтобы AccessEngine
        (который оперирует graph) мог получить отчёт об увалённых.
        """
        return self._hierarchy_api.scan_terminated_emails

    def scan_cloud_users(self, emails) -> dict[str, list[str]]:
        """Дефолт-доступ: обход cloud-юзеров с обработкой увалённых (Teams).

        Делегирует HierarchyAPI.scan_cloud_users, который умеет пропускать
        отсутствующих в Teams (увалённых) и продолжить со следующего email.
        """
        return self._hierarchy_api.scan_cloud_users(emails)

    def get_manager_chain(self, email: str) -> list[str]:
        """Вся цепочка руководителей (от прямого до верхнего уровня).

        Теперь использует HierarchyAPI (playwright + Edge + CDP) вместо
        Graph API для получения иерархии руководителей.
        """
        try:
            return self._hierarchy_api.get_manager_chain(email)
        except HierarchyAPIError as e:
            raise GraphError(f"Ошибка получения иерархии: {e}") from e

    def get_direct_manager(self, email: str) -> str | None:
        """Email непосредственного руководителя."""
        try:
            return self._hierarchy_api.get_direct_manager(email)
        except HierarchyAPIError as e:
            raise GraphError(f"Ошибка получения прямого руководителя: {e}") from e
# -*- coding: utf-8 -*-
"""Парсер описания заявки (системное поле description).

Извлекает исходные текстовые маркеры 1-4, служебные блоки скрипта и
глобальные варианты («Кастом:» / «Кастом группы:»).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from config import (
    PREFIX_AGREE_ALL,
    PREFIX_PROPOSE,
    PREFIX_CONFLICT,
    PREFIX_NON_CONFLICT,
    PREFIX_CUSTOM_QUEUE,
    PREFIX_CUSTOM_GROUP,
    TEXT_RIGHTS_NOT_FIXED,
)

# Текстовые маркеры заявки
MARKER_QUEUES = "К каким очередям задач нужен доступ?:"
MARKER_RIGHTS = "Запрашиваемые права:"
MARKER_EMAILS = "Корпоративный E-mail, кому нужен доступ:"
MARKER_INITIATOR = "Ваш рабочий email:"

# Ожидаемые значения прав
RIGHTS_READ = "Чтение"
RIGHTS_WRITE = "Создание, редактирование, чтение"
RIGHTS_VARIANTS = (RIGHTS_READ, RIGHTS_WRITE)

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_QUEUE_KEY_RE = re.compile(r"tracker\.yandex\.(?:ru|net)/([A-Za-z0-9_\-]+)")
_DATE_RE = re.compile(r"\d{2}\.\d{2}\.\d{4}")

# Префиксы, с которых начинаются служебные блоки скрипта
# и исходные маркеры заявки (ими прерываем чтение значений)
_BLOCK_PREFIXES = (
    PREFIX_AGREE_ALL,
    PREFIX_PROPOSE,
    PREFIX_CONFLICT,
    PREFIX_NON_CONFLICT,
    PREFIX_CUSTOM_QUEUE,
    PREFIX_CUSTOM_GROUP,
    TEXT_RIGHTS_NOT_FIXED,
    # Исходные маркеры заявки (1-4) - тоже служат границей
    # при чтении Кастом: / Кастом группы:
    MARKER_QUEUES,
    MARKER_RIGHTS,
    MARKER_EMAILS,
    MARKER_INITIATOR,
)
_MARKER_LINES = (
    MARKER_QUEUES,
    MARKER_RIGHTS,
    MARKER_EMAILS,
    MARKER_INITIATOR,
)


@dataclass
class ParsedIssue:
    key: str
    summary: str
    description: str
    emails: list[str] = field(default_factory=list)        # маркер 3
    queues: list[str] = field(default_factory=list)        # маркер 1
    rights: str | None = None                              # маркер 2
    initiator: str | None = None                           # маркер 4
    has_markers_1_3: bool = False
    custom_queues: list[tuple[str, str | None]] = field(default_factory=list)
    custom_groups: list[tuple[str, str | None]] = field(default_factory=list)
    agree_all: bool = False                                # «Согласиться со всем: Ок»
    approved_groups: set[str] = field(default_factory=set)  # группы с «Ок»
    text_rights_not_fixed: bool = False
    issue_status: str = ""


def _norm(line: str) -> str:
    """Нормализация строки: убираем markdown-жирность и пробелы."""
    return re.sub(r"\s+", " ", line.strip().strip("*")).strip()


def _is_block_line(line: str) -> bool:
    n = _norm(line)
    for p in _BLOCK_PREFIXES:
        if n.startswith(p) or n == p:
            return True
    return False


def extract_marker_value(description: str, marker: str) -> str:
    """Значение маркера со следующей строки (строго по ТЗ)."""
    lines = description.splitlines()
    for i, line in enumerate(lines):
        if _norm(line) == marker:
            if i + 1 < len(lines):
                return lines[i + 1].strip()
            return ""
    return ""


def extract_block_below(description: str, marker: str) -> str:
    """Все строки под маркером до пустой строки или служебного блока."""
    lines = description.splitlines()
    out = []
    started = False
    for line in lines:
        if not started:
            if _norm(line) == marker:
                started = True
            continue
        if not line.strip():
            break
        if _is_block_line(line):
            break
        out.append(line.strip())
    return "\n".join(out)


def parse_emails(text: str) -> list[str]:
    seen, result = set(), []
    for m in _EMAIL_RE.findall(text or ""):
        m = m.lower()
        if m not in seen:
            seen.add(m)
            result.append(m)
    return result


def parse_queues(text: str) -> list[str]:
    """Ключи очередей из значения маркера 1 (элементы через запятую)."""
    result: list[str] = []
    for part in (text or "").split(","):
        key = part.split(":", 1)[0].strip()
        if key and not _EMAIL_RE.match(key):
            if key not in result:
                result.append(key)
    return result


def parse_expiry(text: str) -> str | None:
    """Дата DD.MM.YYYY из строки, если есть."""
    m = _DATE_RE.search(text or "")
    return m.group(0) if m else None


def parse_custom_lines(description: str, marker: str) -> list[tuple[str, str | None]]:
    """Строки под 'Кастом:'/'Кастом группы:' -> (ресурс, дата истечения)."""
    result = []
    text = extract_block_below(description, marker)
    if not text:
        return result
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        url_m = _QUEUE_KEY_RE.search(line)
        if url_m:
            resource = url_m.group(1)
        elif line.startswith("http"):
            resource = line
        else:
            resource = line.split()[0] if line.split() else ""
        result.append((resource, parse_expiry(line)))
    return result


def parse_issue(key: str, summary: str, description: str) -> ParsedIssue:
    desc = description or ""
    parsed = ParsedIssue(
        key=key,
        summary=summary or "",
        description=desc,
        emails=parse_emails(extract_block_below(desc, MARKER_EMAILS)),
        queues=parse_queues(extract_marker_value(desc, MARKER_QUEUES)),
        rights=extract_marker_value(desc, MARKER_RIGHTS) or None,
        initiator=None,
    )
    initiator = parse_emails(extract_marker_value(desc, MARKER_INITIATOR))
    parsed.initiator = initiator[0] if initiator else None
    parsed.has_markers_1_3 = bool(
        parsed.queues and parsed.rights and parsed.emails
    )
    parsed.custom_queues = parse_custom_lines(desc, PREFIX_CUSTOM_QUEUE)
    parsed.custom_groups = parse_custom_lines(desc, PREFIX_CUSTOM_GROUP)

    # ---- Обычный блок предложений: поиск подтверждений «Ок» ----
    parsed.agree_all = bool(re.search(r"Согласиться со всем:\s*(Ок|ок|OK)\b", desc))
    approved = set()
    for line in desc.splitlines():
        # строка вида "<группа>: Ок"
        m = re.match(r"^\s*(.+?):\s*(Ок|ок|OK)\s*$", line)
        if m and not _is_block_line(m.group(1)):
            approved.add(m.group(1).strip())
    parsed.approved_groups = approved
    parsed.text_rights_not_fixed = TEXT_RIGHTS_NOT_FIXED in desc
    return parsed


# ================================================================
# Разбор служебных блоков предложений (form: жирные строки внизу desc)
# ================================================================
@dataclass
class ProposalBlock:
    """Блок предложений групп для одного (набора почт, очереди).

    kind: 'propose' | 'conflict' | 'nonconflict'
    groups: список (название группы, стоит ли «Ок»)
    """

    kind: str
    emails: list[str]
    queue: str
    groups: list[tuple[str, bool]]


_HEADER_RE = re.compile(
    r"^\s*Предлагаемые (?:конфликтные |не конфликтные )?группы для "
    r"юзера/юзеров\s+(.+?)\s+в очередь\s+(.+?):\s*$"
)
_OK_RE = re.compile(r"^\s*(.+?):\s*(Ок|ок|OK)?\s*$")
_AGREE_ALL_RE = re.compile(r"^\s*Согласиться со всем:\s*(Ок|ок|OK)?\s*$")


def parse_proposal_blocks(description: str) -> list[ProposalBlock]:
    """Разбирает все блоки предложений в описании задачи."""
    blocks: list[ProposalBlock] = []
    current: ProposalBlock | None = None
    for line in (description or "").splitlines():
        if not line.strip():
            continue
        m = _HEADER_RE.match(line)
        if m:
            current = ProposalBlock(
                kind="propose",
                emails=parse_emails(m.group(1)),
                queue=m.group(2).strip(),
                groups=[],
            )
            if "конфликтные" in line and "не конфликтные" not in line:
                current.kind = "conflict"
            elif "не конфликтные" in line:
                current.kind = "nonconflict"
            blocks.append(current)
            continue
        if _AGREE_ALL_RE.match(line):
            continue
        gm = _OK_RE.match(line)
        if gm:
            name = gm.group(1).strip()
            # строка вида "<группа>:" без колонок — продолжаем текущий блок
            if current is not None and not _is_block_line(name):
                current.groups.append((name, bool(gm.group(2))))
                continue
            current = None
        else:
            current = None
    return blocks


def find_proposal_blocks(description: str, emails: list[str], queue: str) -> list[ProposalBlock]:
    """Блоки, относящиеся к указанной паре (почты, очередь)."""
    return [
        b
        for b in parse_proposal_blocks(description)
        if b.queue == queue and set(b.emails) == set(emails)
    ]


# ---------------------------------------------------------------- helpers
def normalize_rights(rights: str | None):
    """Приводит права из заявки к одному из RIGHTS_VARIANTS (иначе None)."""
    if not rights:
        return None
    r = re.sub(r"\s+", " ", rights.strip())
    for v in RIGHTS_VARIANTS:
        if r == v:
            return v
    return None
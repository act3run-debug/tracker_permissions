# -*- coding: utf-8 -*-
"""Парсер Технической таблицы Yandex Wiki.

Таблица встроена в content страницы как markdown-разметка (динамические
grid-таблицы на странице отсутствуют), поэтому основной парсер —
``parse_markdown_table``. Строки, где заполнено более одного
взаимоисключающего столбца (кроме «Дополнительная логика»), пропускаются
с логом ошибки (правило ТЗ).
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from logging_conf import log

# Фиксированные названия столбцов
COL_GROUP = "Название группы"
COL_INDIVIDUAL = "Очередь для индивидуального доступа"
COL_NOATTR = "Очереди для групп без признака"
COL_MANAGER_ANY = "Руководитель (на любом уровне)"
COL_MANAGER_DIRECT = "Руководитель линейный"
COL_FIXED = "Фиксированный список"
COL_CONSENT = "Только по согласованию"
COL_EXTRA_LOGIC = "Дополнительная логика"

# Столбцы, которые не могут быть заполнены одновременно
MUTUALLY_EXCLUSIVE = (
    COL_INDIVIDUAL,
    COL_NOATTR,
    COL_MANAGER_ANY,
    COL_MANAGER_DIRECT,
    COL_FIXED,
    COL_CONSENT,
)

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_QUEUE_URL_RE = re.compile(r"https?://tracker\.yandex\.(?:ru|net)/([A-Za-z0-9_\-]+)")
_MD_LINK_RE = re.compile(r"\[([^\]]*)\]\([^)]*\)")


def _clean_markdown(value: str) -> str:
    """Снимает markdown-разметку со значения ячейки.

    - ``**имя**`` -> ``имя``;
    - ``[текст](url)`` -> ``текст``;
    - схлопывает пробелы и переводы строк.
    """
    text = (value or "").strip("*").strip()
    text = _MD_LINK_RE.sub(r"\1", text)
    return re.sub(r"\s+", " ", text).strip()


@dataclass
class GroupRule:
    """Одна строка Технической таблицы."""

    group_name: str | None                # пусто — только прямой доступ в Трекер
    individual_queues: list[str]          # Очередь для индивидуального доступа
    noattr_queues: list[str]              # Очереди для групп без признака
    managers_any_level: list[str]         # Руководитель (на любом уровне)
    managers_direct: list[str]            # Руководитель линейный
    fixed_list: list[str]                 # Фиксированный список
    only_by_consent: bool                 # Только по согласованию
    extra_logic: str | None               # Дополнительная логика


def _normalize_cell(value) -> list[str]:
    """Превращает значение ячейки wiki-grid в список строк.

    Ячейка может быть строкой, списком строк или списком объектов
    (например пользователей), поэтому приводим всё к текстовым строкам.
    """
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, (int, float, bool)):
        return [str(value)]
    if isinstance(value, list):
        lines = []
        for item in value:
            if isinstance(item, dict):
                # объект пользователя/ссылки
                text = (
                    item.get("email")
                    or item.get("display")
                    or item.get("username")
                    or item.get("text")
                    or item.get("value")
                )
                if text:
                    lines.append(str(text))
            else:
                lines.append(str(item))
        return lines
    return [str(value)]


def parse_emails(text: str) -> list[str]:
    """Все email из произвольного текста (markdown-ссылки, запятые и т.п.).

    Без дублей и в нижнем регистре: `[e](mailto:e)` содержит email дважды.
    """
    seen: set[str] = set()
    result = []
    for m in _EMAIL_RE.findall(text or ""):
        e = m.lower()
        if e not in seen:
            seen.add(e)
            result.append(e)
    return result


def parse_queue_keys(text: str) -> list[str]:
    """Ключи очередей из ячеек-ссылок (последняя часть URL)."""
    keys = []
    for m in _QUEUE_URL_RE.findall(text or ""):
        if m and m not in keys:
            keys.append(m)
    return keys


def parse_grid(grid: dict) -> list[GroupRule]:
    """Разбирает структуру grid в список GroupRule."""
    structure = grid.get("structure") or {}
    columns = structure.get("columns") or []
    # индекс столбца по названию (нормализация пробелов)
    col_index: dict[str, int] = {}
    for i, col in enumerate(columns):
        title = re.sub(r"\s+", " ", (col.get("title") or "")).strip()
        col_index[title] = i

    rules: list[GroupRule] = []
    for row in grid.get("rows") or []:
        cells = row.get("row") or []

        def cell_text(title: str) -> str:
            idx = col_index.get(title)
            if idx is None or idx >= len(cells):
                return ""
            return "\n".join(_normalize_cell(cells[idx]))

        # ---- Проверка взаимоисключающих столбцов ----
        filled = [c for c in MUTUALLY_EXCLUSIVE if cell_text(c).strip()]
        if len(filled) > 1:
            log.error(
                "Таблица: строка пропущена — заполнено несколько "
                "взаимоисключающих столбцов %s (группа='%s')",
                filled,
                cell_text(COL_GROUP)[:60],
            )
            continue

        rule = GroupRule(
            group_name=_clean_markdown(cell_text(COL_GROUP)) or None,
            individual_queues=parse_queue_keys(cell_text(COL_INDIVIDUAL)),
            noattr_queues=parse_queue_keys(cell_text(COL_NOATTR)),
            managers_any_level=parse_emails(cell_text(COL_MANAGER_ANY)),
            managers_direct=parse_emails(cell_text(COL_MANAGER_DIRECT)),
            fixed_list=parse_emails(cell_text(COL_FIXED)),
            only_by_consent=bool(cell_text(COL_CONSENT).strip()),
            extra_logic=cell_text(COL_EXTRA_LOGIC).strip() or None,
        )
        rules.append(rule)
        log.debug("Таблица: добавлено правило для группы '%s'", rule.group_name)
    return rules


def _split_markdown_row(line: str) -> list[str]:
    """Разбивает строку markdown-таблицы на ячейки (без обрамляющих |)."""
    line = line.strip()
    if not line.startswith("|"):
        return []
    line = line[1:] if line.startswith("|") else line
    if line.endswith("|"):
        line = line[:-1]
    return [cell.strip() for cell in line.split("|")]


def _is_separator_row(cells: list[str]) -> bool:
    """True, если строка — разделитель заголовка markdown-таблицы (---)."""
    non_empty = [c for c in cells if c.strip()]
    if not non_empty:
        return False
    return all(re.fullmatch(r":?-+:?", c.strip()) for c in non_empty)


def _iter_table_blocks(content: str):
    """Генерирует блоки строк markdown-таблиц из content страницы."""
    block: list[list[str]] = []
    for raw in (content or "").splitlines():
        line = raw.strip()
        if line.startswith("|"):
            cells = _split_markdown_row(line)
            if cells:
                block.append(cells)
        elif block:
            yield block
            block = []
    if block:
        yield block


def parse_markdown_table(content: str) -> list[GroupRule]:
    """Разбирает markdown-таблицу из content страницы Wiki в список GroupRule.

    Ищет блок таблицы, заголовок которого содержит все фиксированные
    столбцы ТЗ, и парсит его строки.
    """
    required = (
        COL_GROUP,
        COL_INDIVIDUAL,
        COL_NOATTR,
        COL_MANAGER_ANY,
        COL_MANAGER_DIRECT,
        COL_FIXED,
        COL_CONSENT,
        COL_EXTRA_LOGIC,
    )
    for block in _iter_table_blocks(content):
        if len(block) < 2:
            continue
        header = [re.sub(r"\s+", " ", h).strip() for h in block[0]]
        col_index: dict[str, int] = {}
        for i, title in enumerate(header):
            col_index[title] = i
        if not all(c in col_index for c in required):
            log.debug("Таблица: блок без требуемых столбцов, пропущен")
            continue

        rules: list[GroupRule] = []
        for cells in block[1:]:
            if _is_separator_row(cells):
                continue
            if not any(c.strip() for c in cells):
                continue

            def cell_text(title: str) -> str:
                idx = col_index.get(title)
                if idx is None or idx >= len(cells):
                    return ""
                return cells[idx].strip()

            # ---- Проверка взаимоисключающих столбцов ----
            filled = [c for c in MUTUALLY_EXCLUSIVE if cell_text(c)]
            if len(filled) > 1:
                log.error(
                    "Таблица: строка пропущена — заполнено несколько "
                    "взаимоисключающих столбцов %s (группа='%s')",
                    filled,
                    cell_text(COL_GROUP)[:60],
                )
                continue

            rule = GroupRule(
                group_name=_clean_markdown(cell_text(COL_GROUP)) or None,
                individual_queues=parse_queue_keys(cell_text(COL_INDIVIDUAL)),
                noattr_queues=parse_queue_keys(cell_text(COL_NOATTR)),
                managers_any_level=parse_emails(cell_text(COL_MANAGER_ANY)),
                managers_direct=parse_emails(cell_text(COL_MANAGER_DIRECT)),
                fixed_list=parse_emails(cell_text(COL_FIXED)),
                only_by_consent=bool(cell_text(COL_CONSENT)),
                extra_logic=cell_text(COL_EXTRA_LOGIC) or None,
            )
            rules.append(rule)
            log.debug("Таблица: добавлено правило для группы '%s'", rule.group_name)

        log.info("Таблица: найдена markdown-таблица, загружено %d правил", len(rules))
        return rules
    raise ValueError("В content страницы не найдена markdown-таблица с требуемыми столбцами")


def build_lookup(rules: list[GroupRule]) -> dict:
    """Индекс правил по ключу очереди (для быстрого маппинга заявок)."""
    by_queue: dict[str, list[GroupRule]] = {}
    for rule in rules:
        for q in rule.individual_queues:
            by_queue.setdefault(q, []).append(rule)
        for q in rule.noattr_queues:
            by_queue.setdefault(q, []).append(rule)
    return by_queue
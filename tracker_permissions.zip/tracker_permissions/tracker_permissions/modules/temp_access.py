# -*- coding: utf-8 -*-
"""Хранилище временных доступов.

Локальный JSON-файл (в папке скрипта). При каждом запуске скрипт
проверяет записи и отзывает доступы с истёкшей датой.
"""

from __future__ import annotations

import json
import os
from datetime import date

from logging_conf import log


class TempAccessStore:
    def __init__(self, filename: str):
        self.filename = filename

    def _load(self) -> list[dict]:
        if not os.path.exists(self.filename):
            return []
        try:
            with open(self.filename, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (json.JSONDecodeError, OSError):
            log.error("temp_access.json повреждён — считаю хранилище пустым")
            return []

    def _save(self, records: list[dict]) -> None:
        with open(self.filename, "w", encoding="utf-8") as fh:
            json.dump(records, fh, ensure_ascii=False, indent=2)

    def add(
        self,
        email: str,
        kind: str,
        resource: str,
        expires: str,
        rights: str = "",
    ) -> None:
        """kind: 'queue' (прямой доступ к очереди) или 'group' (Cloud-группа).

        ``rights`` — уровень прав для прямых доступов (нужен при отзыве).
        """
        records = self._load()
        records.append(
            {
                "email": email,
                "kind": kind,
                "resource": resource,
                "expires": expires,
                "rights": rights,
            }
        )
        self._save(records)
        log.info(
            "Временный доступ %s:%s для %s до %s записан в %s",
            kind,
            resource,
            email,
            expires,
            os.path.basename(self.filename),
        )

    def expired(self, today: date | None = None) -> list[dict]:
        """Записи, срок которых уже наступил (дата < сегодня)."""
        today = today or date.today()
        result = []
        for rec in self._load():
            try:
                exp = date(*[int(x) for x in rec["expires"].split(".")][::-1])
            except (KeyError, ValueError):
                log.error("temp_access: некорректная дата в записи %r", rec)
                continue
            if exp < today:
                result.append(rec)
        return result

    def remove(self, email: str, kind: str, resource: str) -> None:
        records = [
            r
            for r in self._load()
            if not (
                r.get("email") == email
                and r.get("kind") == kind
                and r.get("resource") == resource
            )
        ]
        self._save(records)
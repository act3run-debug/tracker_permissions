# -*- coding: utf-8 -*-
"""Модуль «Дополнительная логика» (хардкод-правила, требуют правки кода).

Правила (из ТЗ):
- tracker-ets: любой попадающий в группу добавляется в tracker-data-and-digital.
- rwe-research: инициатор == SPECIAL_INITIATOR_RWE И в Summary есть
  "Wiki + Cloud". Проверяется для каждой заявки в общем потоке, даже без
  маркеров 1-2, но при обязательных маркерах 3 и 4.
- autsors-external-translations: инициатор == SPECIAL_INITIATOR_EXTERNAL_TRANSLATIONS
  И пользователь внешний. Те же требования к маркерам.
"""

from __future__ import annotations

from config import (
    SPECIAL_INITIATOR_RWE,
    SPECIAL_INITIATOR_EXTERNAL_TRANSLATIONS,
    SPECIAL_GROUP_ETS,
    SPECIAL_GROUP_TDD,
    SPECIAL_GROUP_RWE,
    SPECIAL_GROUP_EXTERNAL_TRANSLATIONS,
    RWE_SUMMARY_MARKER,
    INTERNAL_DOMAINS,
)


def is_internal(email: str) -> bool:
    return email.lower().endswith(INTERNAL_DOMAINS)


def apply_group_addition_rules(group_name: str, email: str) -> list[str]:
    """Дополнительные группы, в которые добавить пользователя.

    Возвращает список названий групп (помимо исходной) на основе
    хардкод-правил. Сейчас одно правило — tracker-ets.
    """
    extra: list[str] = []
    if group_name == SPECIAL_GROUP_ETS:
        extra.append(SPECIAL_GROUP_TDD)
    return extra


def check_rwe_research(initiator: str | None, summary: str) -> bool:
    """Условие выдачи группы rwe-research."""
    return bool(
        initiator
        and initiator.lower() == SPECIAL_INITIATOR_RWE
        and RWE_SUMMARY_MARKER in (summary or "")
    )


def check_autsors_external_translations(initiator: str | None, email: str) -> bool:
    """Условие выдачи группы autsors-external-translations."""
    return bool(
        initiator
        and initiator.lower() == SPECIAL_INITIATOR_EXTERNAL_TRANSLATIONS
        and not is_internal(email)
    )


RWE_GROUP = SPECIAL_GROUP_RWE
EXTERNAL_TRANSLATIONS_GROUP = SPECIAL_GROUP_EXTERNAL_TRANSLATIONS
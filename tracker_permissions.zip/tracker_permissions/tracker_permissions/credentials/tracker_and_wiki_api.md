x-cloud-org-id: "bpfb300ct6ef4t2kr3l1"
token: "y0__wgBEM-Q3bUIGPqsOiCu_fCDGTC40-KCCCHhEvRf0CXapaUvgQWDYH-0p-L0"

Уточнение: используется x-cloud-org-id, headers писать так:
```python
headers = {
    "Authorization": f"Bearer {oauth_token}",
    "Content-Type": "application/json",
    "X-Cloud-Org-Id": org_id
}
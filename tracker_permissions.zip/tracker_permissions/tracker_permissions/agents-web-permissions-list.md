"curl": "allow",
"curl *": "allow",
"$curl": "allow",
"$curl *": "allow",

"wget": "allow",
"wget *": "allow",
"$wget": "allow",
"$wget *": "allow",

"Invoke-WebRequest": "allow",
"Invoke-WebRequest *": "allow",
"$Invoke-WebRequest": "allow",
"$Invoke-WebRequest *": "allow",

"iwr": "allow",
"iwr *": "allow",
"$iwr": "allow",
"$iwr *": "allow",

"Invoke-RestMethod": "allow",
"Invoke-RestMethod *": "allow",
"$Invoke-RestMethod": "allow",
"$Invoke-RestMethod *": "allow",

"irm": "allow",
"irm *": "allow",
"$irm": "allow",
"$irm *": "allow",

"ping": "allow",
"ping *": "allow",
"$ping": "allow",
"$ping *": "allow",

"nslookup": "allow",
"nslookup *": "allow",
"$nslookup": "allow",
"$nslookup *": "allow",

"dig": "allow",
"dig *": "allow",
"$dig": "allow",
"$dig *": "allow",

"host": "allow",
"host *": "allow",
"$host": "allow",
"$host *": "allow"
# -*- coding: utf-8 -*-
"""Точка входа скрипта выдачи/отзыва доступов в Яндекс Трекер.

Запуск вручную: ``python main.py``. Выполняет два действия (ТЗ):
1. Сканирует пользователей, присоединившихся к Cloud Identity Hub за
   интервал (по дельте снимков).
2. Обрабатывает все открытые заявки на доступ в очереди TRACKERSUPPORT
   (тип ``dostup``): спецлогика, глобальные маркеры, дефолт- и доп. доступ.

В конце отзывает временные доступы с истёкшей датой (temp_access.json).
"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta, timezone as tz

# Корень проекта и каталог modules должны быть в sys.path — модули внутри
# modules/ импортируют друг друга и config.py по плоско.
_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _ROOT)
sys.path.insert(0, os.path.join(_ROOT, "modules"))

from config import (  # noqa: E402
    QUEUE_KEY,
    ISSUE_TYPE_KEY,
    STATUS_CLOSED,
    IGNORE_DELTA_ALL_USERS,
    SPECIFIC_USERS_EMAILS,
    INACTIVE_THRESHOLD_DAYS,
    WIKI_PAGE_SLUG,
    TRACKER_API,
    WIKI_API,
    ORG_MANAGER_API,
    TEMP_ACCESS_FILE,
    load_ya_credentials,
    load_iam_token,
)
from logging_conf import log, setup_logging  # noqa: E402
from access_engine import AccessEngine  # noqa: E402
from graph_api import GraphAPI  # noqa: E402 - теперь обертка над HierarchyAPI
from identity_hub import IdentityHub  # noqa: E402
from table_parser import parse_markdown_table  # noqa: E402
from temp_access import TempAccessStore  # noqa: E402
from tracker_api import TrackerAPI  # noqa: E402
from wiki_api import WikiAPI, WikiError  # noqa: E402


def _build_inactive_emails_set(
    tracker, threshold_days: int,
) -> set[str]:
    """Собрать множество email'ов неактивных пользователей.

    Получает через Tracker API список всех пользователей организации с
    ``lastLoginDate``, отфильтровывает dismissed и определяет неактивных
    (lastLoginDate старше ``threshold_days`` или отсутствует).
    """
    log.info(
        "Получаю список неактивных пользователей (порог: %d дней)...",
        threshold_days,
    )
    cutoff = datetime.now(tz.utc) - timedelta(days=threshold_days)
    inactive: set[str] = set()

    try:
        users = tracker.get_users_last_login()
    except Exception as exc:
        log.error("Tracker API: не удалось получить список пользователей: %s", exc)
        return set()

    log.info("Всего пользователей в организации (с lastLoginDate): %d", len(users))

    for user in users:
        # Пропускаем dismissed
        if user.get("dismissed"):
            continue
        login = user.get("login") or ""
        # Парсим lastLoginDate
        last_login_str = user.get("lastLoginDate")
        if not last_login_str:
            # Нет даты последнего входа — считаем неактивным
            email = user.get("email", "").lower()
            if email:
                inactive.add(email)
            continue
        try:
            last_login_dt = datetime.fromisoformat(last_login_str)
            if last_login_dt.tzinfo is None:
                last_login_dt = last_login_dt.replace(tzinfo=tz.utc)
        except (ValueError, TypeError):
            # Не удалось распарсить дату — считаем неактивным
            email = user.get("email", "").lower()
            if email:
                inactive.add(email)
            continue
        if last_login_dt < cutoff:
            email = user.get("email", "").lower()
            if email:
                inactive.add(email)

    log.info("Неактивных пользователей (порог %d дней): %d", threshold_days, len(inactive))
    return inactive


def main() -> int:
    setup_logging()
    log.info("=== Старт обработки заявок на доступ ===")

    ya_token, ya_org = load_ya_credentials()
    iam_token = load_iam_token()
    if not ya_token or not ya_org or not iam_token:
        log.error("Не удалось загрузить секреты из credentials/ — останов")
        return 1

    tracker = TrackerAPI(ya_token, ya_org, TRACKER_API)
    wiki = WikiAPI(ya_token, ya_org, WIKI_API)
    identity = IdentityHub(iam_token, ya_org, ORG_MANAGER_API)
    # GraphAPI теперь использует HierarchyAPI (playwright + Edge + CDP)
    graph = GraphAPI(
        "",  # client_id (игнорируется, теперь используется HierarchyAPI)
        "",  # tenant_id (игнорируется)
        "",  # cache_file (игнорируется)
        "",  # access_token_file (игнорируется)
        "",  # base_url (игнорируется)
    )
    temp = TempAccessStore(TEMP_ACCESS_FILE)

    # --- Неактивные пользователи (фильтр по активности) ---
    inactive_emails: set[str] = set()
    if INACTIVE_THRESHOLD_DAYS > 0:
        try:
            inactive_emails = _build_inactive_emails_set(
                tracker, INACTIVE_THRESHOLD_DAYS
            )
        except Exception as exc:
            log.exception(
                "Не удалось получить список неактивных пользователей — "
                "фильтр по активности отключён: %s",
                exc,
            )
            inactive_emails = set()
    else:
        log.info(
            "Фильтр по активности пользователей отключен "
            "(INACTIVE_THRESHOLD_DAYS=0)"
        )

    # --- Техническая таблица (источник правил) ---
    try:
        content = wiki.get_page_content(WIKI_PAGE_SLUG)
        rules = parse_markdown_table(content)
    except WikiError as exc:
        log.error("Техническая таблица не найдена — останов: %s", exc)
        return 1
    log.info("Техническая таблица: загружено %d правил", len(rules))

    engine = AccessEngine(tracker, identity, graph, temp, rules)
    engine.set_inactive_emails(inactive_emails)

    # --- 1. Новые пользователи Cloud ---
    try:
        specific_for_scan = (
            {e.lower() for e in SPECIFIC_USERS_EMAILS} or None
        )
        engine.scan_new_cloud_users(
            ignore_delta=IGNORE_DELTA_ALL_USERS,
            specific_emails=specific_for_scan,
        )
    except Exception as exc:
        log.exception("Сканирование новых пользователей Cloud прервано: %s", exc)

    # --- 2. Открытые заявки ---
    try:
        # Фильтр resolution: empty() добавляется внутри search_issues —
        # закрытые задачи не выкачиваются, число запросов мало.
        issues = tracker.search_issues({"queue": QUEUE_KEY, "type": ISSUE_TYPE_KEY})
    except Exception as exc:
        log.exception("Поиск открытых заявок прерван: %s", exc)
        issues = []

    # Режим конкретного юзера (самый высокий приоритет)
    if SPECIFIC_USERS_EMAILS:
        lower_specific = {e.lower() for e in SPECIFIC_USERS_EMAILS}
        log.info(
            "Режим «конкретные юзеры» активен — фильтрую заявки по email: %s",
            ", ".join(sorted(lower_specific)),
        )

    open_issues = []
    seen_keys: set[str] = set()
    for i in issues:
        if (i.get("status") or {}).get("key") != STATUS_CLOSED:
            key = i.get("key") or ""
            if key in seen_keys:
                # Защита от дублей: при пагинации Трекер пересчитывает
                # результаты между страницами, одна задача может попасть
                # в выборку повторно. Каждая заявка обрабатывается один раз.
                continue
            seen_keys.add(key)
            open_issues.append(i)
    log.info("Заявок со статусом, отличным от «Закрыт»: %d", len(open_issues))

    # Режим конкретного юзера (самый высокий приоритет).
    # 1. В cloud: обработку указанных email берёт на себя
    #    scan_new_cloud_users (этап 1) — там же применяется фильтр
    #    по неактивности и независимо от режима «новые/все» (ТЗ:
    #    «не важно новые юзеры или нет»).
    # 2. В заявках: ниже фильтруем по email'ам из конфига.
    # Если список SPECIFIC_USERS_EMAILS пустой — режим не срабатывает
    # и все заявки обрабатываются в обычном режиме.
    if SPECIFIC_USERS_EMAILS:
        filtered: list[dict] = []
        for iss in open_issues:
            desc = iss.get("description") or ""
            lower_desc = desc.lower()
            if any(email.lower() in lower_desc for email in SPECIFIC_USERS_EMAILS):
                filtered.append(iss)
        log.info(
            "Режим «конкретные юзеры» — отфильтровано заявок: %d из %d",
            len(filtered), len(open_issues),
        )
        open_issues = filtered

    for issue in open_issues:
        try:
            engine.process_issue(issue)
        except Exception as exc:
            log.exception("Задача %s: ошибка обработки: %s", issue.get("key"), exc)

    # --- 3. Отзыв истёкших временных доступов ---
    try:
        engine.expire_temp_accesses()
    except Exception as exc:
        log.exception("Отзыв временных доступов прерван: %s", exc)

    # --- Отчёт об увалённых (отсутствующих в Teams) ---
    # Печатается в конце работы. Выводится «просто почта в столбик»,
    # чтобы оператор сразу скопировал список.
    terminated = getattr(engine, "terminated_cloud_emails", [])
    if terminated:
        log.info(
            "Отчёт об увалённых (отсутствуют в Teams) — %d:",
            len(terminated),
        )
        for email in terminated:
            print(email)
    else:
        log.info("Отчёт об увалённых — нет: никто не отсутствует в Teams")

    log.info("=== Обработка завершена ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

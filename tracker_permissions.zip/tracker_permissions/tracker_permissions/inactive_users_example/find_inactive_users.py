#!/usr/bin/env python3
"""
Скрипт для поиска пользователей, не входивших в Яндекс Трекер более 6 месяцев.

Использует Yandex Tracker API:
1. GET /v3/users/_relative — получение списка всех пользователей с lastLoginDate
2. Фильтрация неактивных пользователей (не входили >6 месяцев)
3. Исключение сервисных аккаунтов и удалённых пользователей
4. Вывод результатов в TXT с тремя секциями (по домену почты)

Паттерны сервисных аккаунтов, которые исключаются из отчёта:
- заканчивается на -robot, -svc, -bot
- начинается на yndx-, svc-, api-
- содержит подстроку @robot, @svc, @bot, @service
"""

import requests
import json
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Set, Optional
import time
import re
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# Конфигурация
ORG_ID = "bpfb300ct6ef4t2kr3l1"
OAUTH_TOKEN = "y0__xDPkN21CBj6rDogoICU4BQwuNPiggh9y4Ud7-_nCR3Xub1D2rDq8pHg0A"
API_BASE_URL = "https://api.tracker.yandex.net/v3"

# Заголовки для API запросов
HEADERS = {
    "Authorization": f"OAuth {OAUTH_TOKEN}",
    "Content-Type": "application/json",
    "X-Cloud-Org-ID": ORG_ID
}

# Паттерны для фильтрации сервисных аккаунтов
# Ловит: yndx-*, -svc, -api, -bot, -robot, svc-*, api-*, bot-*, service-*,
#        логин с @, svc/bot в середине строки (az.svc.gitlab.tracker)
SERVICE_ACCOUNT_PATTERNS = [
    re.compile(r"^yndx-", re.IGNORECASE),
    re.compile(r"^-svc$", re.IGNORECASE),
    re.compile(r"^-svc-", re.IGNORECASE),
    re.compile(r"^-api$", re.IGNORECASE),
    re.compile(r"^-api-", re.IGNORECASE),
    re.compile(r"^-bot$", re.IGNORECASE),
    re.compile(r"^-bot-", re.IGNORECASE),
    re.compile(r"^-robot$", re.IGNORECASE),
    re.compile(r"^-robot-", re.IGNORECASE),
    re.compile(r"^svc-", re.IGNORECASE),
    re.compile(r"^api-", re.IGNORECASE),
    re.compile(r"^bot-", re.IGNORECASE),
    re.compile(r"^service-", re.IGNORECASE),
    re.compile(r"@", re.IGNORECASE),  # логины с @ — обычно сервисные
    re.compile(r"\bsvc\b", re.IGNORECASE),   # svc в любом месте строки
    re.compile(r"\bbot\b", re.IGNORECASE),   # bot в любом месте строки
]


def create_session() -> requests.Session:
    """Создать session с retry-механизмом для устойчивости к 504/502/503."""
    session = requests.Session()
    retry_strategy = Retry(
        total=5,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"],
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update(HEADERS)
    return session


def is_service_account(login: str) -> bool:
    """Проверить, является ли логин сервисным аккаунтом."""
    if not login:
        return True
    for pattern in SERVICE_ACCOUNT_PATTERNS:
        if pattern.search(login):
            return True
    return False


def api_request(session: requests.Session, method: str, url: str,
                params: Optional[Dict] = None, payload: Optional[Dict] = None) -> Optional[Dict]:
    """Выполнить API-запрос с обработкой ошибок.
    Retry-механизм встроен в HTTPAdapter (session.create_session).
    Возвращает распарсенный JSON или None при ошибке."""
    try:
        if method.upper() == "GET":
            response = session.get(url, params=params, timeout=30)
        else:
            response = session.post(url, params=params, json=payload, timeout=30)

        if response.status_code == 200:
            try:
                return response.json()
            except json.JSONDecodeError as e:
                print(f"  Ошибка парсинга JSON: {e}")
                print(f"  Ответ слишком большой или повреждён, пропускаем...")
                return None
        elif response.status_code in (502, 503, 504):
            print(f"  Критическая ошибка API: HTTP {response.status_code} (исчерпаны все повторные попытки)")
            print(f"  Ответ: {response.text[:500]}")
            return None
        elif response.status_code == 429:
            print("  Критическая ошибка: исчерпан лимит запросов (429 Too Many Requests)")
            print(f"  Ответ: {response.text[:500]}")
            return None
        else:
            print(f"  Критическая ошибка API: HTTP {response.status_code}")
            print(f"  Ответ: {response.text[:500]}")
            return None
    except requests.exceptions.ConnectionError as e:
        print(f"  Критическая ошибка: сетевая ошибка — {e}")
        return None
    except requests.exceptions.Timeout as e:
        print(f"  Критическая ошибка: таймаут запроса — {e}")
        return None
    except Exception as e:
        print(f"  Неожиданная ошибка: {e}")
        return None


def get_all_users_with_last_login(session: requests.Session) -> List[Dict]:
    """Получить всех пользователей организации с lastLoginDate через _relative endpoint.

    Использует GET /v3/users/_relative, который возвращает lastLoginDate
    для каждого пользователя без необходимости искать issue.
    """
    all_users = []
    per_page = 100
    last_uid = None  # для пагинации по uid (id=last_uid)

    while True:
        url = f"{API_BASE_URL}/users/_relative"
        params = {"perPage": per_page}
        if last_uid:
            params["id"] = last_uid

        data = api_request(session, "GET", url, params=params)
        if data is None:
            break

        users_list = data.get("users", [])
        if not users_list:
            break

        all_users.extend(users_list)

        has_next = data.get("hasNext", False)
        if not has_next:
            break

        # Берём uid последнего пользователя для следующей страницы
        last_user = users_list[-1]
        last_uid = last_user.get("uid") or last_user.get("trackerUid")

        time.sleep(0.1)

    return all_users


def categorize_users(inactive_users: List[Dict]) -> Dict[str, Dict[str, List[Dict]]]:
    """Разделить неактивных пользователей на категории по домену email и уровню доступа.
    
    Каждая категория (astrazeneca, alexion, others) содержит:
    - full_access: пользователи с полным доступом
    - read_only: пользователи с доступом только на чтение
    """
    astrazeneca = {"full_access": [], "read_only": []}
    alexion = {"full_access": [], "read_only": []}
    others = {"full_access": [], "read_only": []}

    for user in inactive_users:
        email = user.get("email", "")
        access = user.get("access_level", "unknown")

        if email.endswith("@astrazeneca.com"):
            target = astrazeneca
        elif email.endswith("@alexion.com"):
            target = alexion
        else:
            target = others

        if access == "read_only":
            target["read_only"].append(user)
        else:
            target["full_access"].append(user)

    return {
        "astrazeneca": astrazeneca,
        "alexion": alexion,
        "others": others,
    }


def parse_last_login_date(date_str: str) -> Optional[datetime]:
    """Парсить lastLoginDate из API в datetime."""
    if not date_str:
        return None
    try:
        # Формат: YYYY-MM-DDThh:mm:ss.sss±hhmm или YYYY-MM-DDThh:mm:ss.sss+0000
        return datetime.fromisoformat(date_str)
    except (ValueError, TypeError):
        return None


def format_last_login(last_login_dt: Optional[datetime]) -> str:
    """Форматировать дату последнего входа."""
    if not last_login_dt:
        return "не входил в Трекер"
    return last_login_dt.strftime("%Y-%m-%d %H:%M:%S")


def format_inactive_period(last_login_dt: Optional[datetime]) -> str:
    """Форматировать период неактивности в днях."""
    if not last_login_dt:
        return "не входил"
    now = datetime.now(timezone.utc)
    delta = now - last_login_dt
    days = delta.days
    if days < 1:
        return "менее 1 дня"
    elif days == 1:
        return "1 день"
    elif days < 5:
        return f"{days} дня"
    elif days < 21:
        return f"{days} дней"
    else:
        months = days // 30
        remaining_days = days % 30
        if months == 0:
            return f"{remaining_days} дней"
        elif months == 1:
            if remaining_days > 0:
                return f"1 месяц {remaining_days} дней"
            return "1 месяц"
        elif months < 5:
            if remaining_days > 0:
                return f"{months} месяца {remaining_days} дней"
            return f"{months} месяца"
        else:
            if remaining_days > 0:
                return f"{months} месяцев {remaining_days} дней"
            return f"{months} месяцев"


def _format_user_entry(user: Dict, index: int) -> List[str]:
    """Сформировать блок информации о пользователе (с почтой к каждому)."""
    last_login_dt = user.get("last_login_dt")
    last_login = format_last_login(last_login_dt)
    inactive_period = format_inactive_period(last_login_dt)
    access = user.get("access_level", "unknown")
    access_label = "полный доступ" if access == "full_access" else "только на чтение" if access == "read_only" else "не определен"

    lines = []
    lines.append(f"{index}. {user['display']} ({user['login']})")
    lines.append(f"   Email: {user['email']}")
    lines.append(f"   Последний вход: {last_login}")
    lines.append(f"   Не заходил: {inactive_period}")
    lines.append(f"   Уровень доступа: {access_label}")
    lines.append("")
    return lines


def generate_txt_report(categorized: Dict[str, Dict[str, List[Dict]]],
                        total_users: int,
                        inactive_count: int,
                        now: datetime) -> str:
    """Сгенерировать TXT-отчёт с секциями по доменам и уровням доступа."""
    section_titles = {
        "astrazeneca": "СЕКЦИЯ 1: Пользователи с почтой @astrazeneca.com",
        "alexion": "СЕКЦИЯ 2: Пользователи с почтой @alexion.com",
        "others": "СЕКЦИЯ 3: Пользователи с другой почтой",
    }

    lines = []
    lines.append("=" * 80)
    lines.append("ОТЧЁТ: НЕАКТИВНЫЕ ПОЛЬЗОВАТЕЛИ ЯНДЕКС ТРЕКЕР")
    lines.append(f"Дата отчёта: {now.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"Порог неактивности: 6 месяцев (180 дней)")
    lines.append("=" * 80)
    lines.append("")
    lines.append(f"Всего пользователей: {total_users}")
    lines.append(f"Неактивных пользователей: {inactive_count}")
    lines.append("")

    for category_key in ["astrazeneca", "alexion", "others"]:
        section_data = categorized[category_key]
        full = section_data.get("full_access", [])
        read = section_data.get("read_only", [])

        lines.append("=" * 80)
        lines.append(section_titles[category_key])
        lines.append("=" * 80)

        # Блок: полный доступ
        lines.append(f"  --- Полный доступ ({len(full)} чел.) ---")
        if full:
            for i, user in enumerate(full, 1):
                lines.extend(_format_user_entry(user, i))
        else:
            lines.append("    Не найдено.")
            lines.append("")

        # Блок: только на чтение
        lines.append(f"  --- Только на чтение ({len(read)} чел.) ---")
        if read:
            for i, user in enumerate(read, 1):
                lines.extend(_format_user_entry(user, i))
        else:
            lines.append("    Не найдено.")
            lines.append("")

    lines.append("=" * 80)
    lines.append("КОНЕЦ ОТЧЁТА")
    lines.append("=" * 80)

    return "\n".join(lines)


def find_inactive_users():
    """Найти пользователей, неактивных более 6 месяцев."""
    print("=" * 80)
    print("СКРИПТ ДЛЯ ПОИСКА НЕАКТИВНЫХ ПОЛЬЗОВАТЕЛЕЙ ЯНДЕКС ТРЕКЕР")
    print("=" * 80)

    now = datetime.now(timezone.utc)
    six_months_ago = now - timedelta(days=180)

    # Создаём session с retry-механизмом
    session = create_session()

    # Получаем всех пользователей с lastLoginDate через _relative endpoint
    print("\n1. Получение списка всех пользователей (с lastLoginDate)...")
    all_users = get_all_users_with_last_login(session)

    if not all_users:
        print("Ошибка: не удалось получить список пользователей.")
        return

    print(f"   Всего пользователей в организации: {len(all_users)}")

    # Фильтруем: неактивные (lastLoginDate > 6 месяцев назад), не dismissed
    # Сервисные аккаунты НЕ исключаем — они попадают в блок "только на чтение"
    print("\n2. Фильтрация неактивных пользователей...")
    inactive_users = []
    dismissed_count = 0

    for user in all_users:
        login = user.get("login")
        if not login:
            continue

        # Пропускаем удалённых пользователей
        if user.get("dismissed"):
            dismissed_count += 1
            continue

        # Парсим lastLoginDate
        last_login_str = user.get("lastLoginDate")
        last_login_dt = None
        if last_login_str:
            last_login_dt = parse_last_login_date(last_login_str)

        # Если lastLoginDate отсутствует или старше 6 месяцев — неактивный
        is_inactive = False
        if not last_login_dt:
            # Нет даты последнего входа — считаем неактивным
            is_inactive = True
            last_login_dt = None
        elif last_login_dt < six_months_ago:
            is_inactive = True

        if is_inactive:
            # Используем accessLevel из API (если доступен), иначе определяем по hasLicense
            raw_access = user.get("accessLevel", "")
            if raw_access == "read_only":
                access_level = "read_only"
            elif raw_access == "full_access":
                access_level = "full_access"
            else:
                has_license = user.get("hasLicense", False)
                access_level = "full_access" if has_license else "read_only"
            inactive_users.append({
                "login": login,
                "display": user.get("display", ""),
                "email": user.get("email", ""),
                "firstName": user.get("firstName", ""),
                "lastName": user.get("lastName", ""),
                "last_login_dt": last_login_dt,
                "access_level": access_level,
            })

    print(f"   Удалённых пользователей (dismissed): {dismissed_count}")
    print(f"   Неактивных пользователей: {len(inactive_users)}")

    # Разделяем по секциям
    categorized = categorize_users(inactive_users)

    # Генерируем TXT-отчёт
    print("\n3. Формирование отчёта...")
    report_text = generate_txt_report(
        categorized=categorized,
        total_users=len(all_users),
        inactive_count=len(inactive_users),
        now=now,
    )

    output_file = "inactive_users_report.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(report_text)

    print(f"   Отчёт сохранён в файл: {output_file}")

    # Также сохраняем в JSON для программной обработки
    json_users = []
    for u in inactive_users:
        entry = {k: v for k, v in u.items()}
        if entry.get("last_login_dt"):
            entry["last_login_dt"] = entry["last_login_dt"].isoformat()
        json_users.append(entry)

    json_report = {
        "report_date": now.isoformat(),
        "total_users": len(all_users),
        "inactive_users_count": len(inactive_users),
        "astrazeneca_count": len(categorized["astrazeneca"]["full_access"]) + len(categorized["astrazeneca"]["read_only"]),
        "astrazeneca_full_access": len(categorized["astrazeneca"]["full_access"]),
        "astrazeneca_read_only": len(categorized["astrazeneca"]["read_only"]),
        "alexion_count": len(categorized["alexion"]["full_access"]) + len(categorized["alexion"]["read_only"]),
        "alexion_full_access": len(categorized["alexion"]["full_access"]),
        "alexion_read_only": len(categorized["alexion"]["read_only"]),
        "others_count": len(categorized["others"]["full_access"]) + len(categorized["others"]["read_only"]),
        "others_full_access": len(categorized["others"]["full_access"]),
        "others_read_only": len(categorized["others"]["read_only"]),
        "users": json_users,
    }

    json_file = "inactive_users_report.json"
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(json_report, f, ensure_ascii=False, indent=2)

    print(f"   JSON-отчёт сохранён в файл: {json_file}")
    print("\nГотово!")


if __name__ == "__main__":
    find_inactive_users()

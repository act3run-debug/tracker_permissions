# -*- coding: utf-8 -*-
"""Конфигурация скрипта tracker_permissions.

Секреты берутся из файлов каталога ``credentials`` проекта (не хранятся в
исходном коде). Все изменяемые параметры собраны в этом модуле.
"""

import os
import re

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CRED_DIR = os.path.join(BASE_DIR, "credentials")

# =====================================================================
# Параметры сканирования (меняются администратором при необходимости)
# =====================================================================
# Очередь, в которой создаются заявки на доступ.
QUEUE_KEY = "TRACKERSUPPORT"
# Тип задач в очереди, которые обрабатывает скрипт.
ISSUE_TYPE_KEY = "dostup"

# Интервал (в днях) для сканирования пользователей, присоединившихся к
# Cloud Identity Hub. 0 — сканирование новых пользователей отключено.
JOINED_INTERVAL_DAYS = 0

# Режим игнорирования дельты новых юзеров. При True обрабатываются ВСЕ
# пользователи, которые есть в организации, без привязки ко времени.
IGNORE_DELTA_ALL_USERS = True

# Порог неактивности пользователя (в днях) в Яндекс Трекере.
# Если пользователь не заходил в Трекер дольше этого срока, он
# считается неактивным и пропускается при обработке. 0 — отключено.
INACTIVE_THRESHOLD_DAYS = 0

# Режим обработки конкретных пользователей (самый высокий приоритет).
# При заполненном списке — обрабатываются ТОЛЬКО указанные почтовые
# адреса в cloud и в заявках. Если список пустой — режим не срабатывает.
SPECIFIC_USERS_EMAILS: list[str] = [
    "aisana.boldyreva@astrazeneca.com"
]

# С какого пользователя (корпоративный e-mail, любой регистр) стартует
# выдача дефолт-доступа при сканировании Cloud Identity Hub. Позволяет
# продолжить прерванный запуск (скрипт упал при выдаче дефолт-доступа):
# уже обработанных пользователей (до стартового по алфавиту) касаться не
# нужно, а обрабатываются все от стартового и ниже. Пустое значение —
# старт с начала списка. Порядок обработки детерминирован (sorted), поэтому
# «продолжение» корректно. Работает в режимах «все юзеры» (IGNORE_DELTA_ALL_USERS)
# и «конкретные юзеры» (SPECIFIC_USERS_EMAILS); в дельта-режиме дельта
# вычисляется от снимка, сделанного в начале запуска, поэтому для
# «продолжения» рекомендуется режим «все юзеры».
DEFAULT_ACCESS_START_EMAIL = ""

# Ключи статусов Трекера (Russian display: Согласование/На доработку/
# Ожидание решения/Закрыт).
STATUS_AGREEMENT = "agreement"          # "Согласование"
STATUS_DORABOTKA = "dorabotka"          # "На доработку"
STATUS_OZIDANIE = "ozidanieResenia"     # "Ожидание решения"
STATUS_CLOSED = "closed"                # "Закрыт"

# Служебные строки, дописываемые скриптом в description (для поиска/дедупликации)
TEXT_RIGHTS_NOT_FIXED = "Права не зафиксированы ни в одной не-дефолтной группе очереди"
PREFIX_AGREE_ALL = "Согласиться со всем:"
PREFIX_PROPOSE = "Предлагаемые группы для юзера/юзеров"
PREFIX_CONFLICT = "Предлагаемые конфликтные группы для юзера/юзеров"
PREFIX_NON_CONFLICT = "Предлагаемые не конфликтные группы для юзера/юзеров"
PREFIX_CUSTOM_QUEUE = "Кастом:"
PREFIX_CUSTOM_GROUP = "Кастом группы:"

# Вики-страница с Технической таблицей (slug из URL)
WIKI_PAGE_SLUG = (
    "homepage/datadigital/it/support/podderzhka-trekera/"
    "ad07416490ac/absoljutnoe-opisanie-vsex-grupp-trekera"
)

# Домены внутренних сотрудников
INTERNAL_DOMAINS = ("astrazeneca.com", "alexion.com")

# Инициаторы спец-логики (см. special_logic.py)
SPECIAL_INITIATOR_RWE = "albina.khabibullina@astrazeneca.com"
SPECIAL_INITIATOR_EXTERNAL_TRANSLATIONS = "anastasiya.kornilova@astrazeneca.com"
SPECIAL_GROUP_ETS = "tracker-ets"
SPECIAL_GROUP_TDD = "tracker-data-and-digital"
SPECIAL_GROUP_RWE = "rwe-research"
SPECIAL_GROUP_EXTERNAL_TRANSLATIONS = "autsors-external-translations"
RWE_SUMMARY_MARKER = "Wiki + Cloud"

# =====================================================================
# Загрузка секретов из каталога credentials
# =====================================================================
_YA_RE = re.compile(r'token:\s*"([^"]+)"')
_ORG_RE = re.compile(r'x-cloud-org-id:\s*"([^"]+)"')


def _read_first(rel_path):
    full = os.path.join(CRED_DIR, rel_path)
    if not os.path.exists(full):
        return ""
    with open(full, "r", encoding="utf-8") as fh:
        return fh.read()


def load_ya_credentials():
    """OAuth-токен и org-id для Яндекс Трекер/Вики."""
    text = _read_first("tracker_and_wiki_api.md")
    token = _YA_RE.search(text)
    org = _ORG_RE.search(text)
    return (token.group(1) if token else "", org.group(1) if org else "")


def load_iam_token():
    """IAM-токен для Cloud Identity Hub (organization-manager API)."""
    text = _read_first("cloud_identity_hub.md")
    token = text.strip().split(":", 1)[-1].strip() if ":" in text else text.strip()
    return token


# =====================================================================
# Microsoft Graph API (client_id/tenant_id не секреты; токен получаем
# через MSAL, см. credentials/microsoft_graph_api/use_example.py)
# =====================================================================
GRAPH_CLIENT_ID = "14d82eec-204b-4c2f-b7e8-296a70dab67e"
GRAPH_TENANT_ID = "af8e89a3-d9ac-422f-ad06-cc4eb4214314"
GRAPH_SCOPE = ["https://graph.microsoft.com/.default"]
GRAPH_CRED_DIR = os.path.join(CRED_DIR, "microsoft_graph_api")
GRAPH_CACHE_FILE = os.path.join(GRAPH_CRED_DIR, "token_cache.json")
GRAPH_ACCESS_TOKEN_FILE = os.path.join(GRAPH_CRED_DIR, "access-token.txt")

# Файл временных доступов лежит в одной папке со скриптом (требование ТЗ)
TEMP_ACCESS_FILE = os.path.join(BASE_DIR, "temp_access.json")

# Снимок участников Cloud Identity Hub с прошлого запуска — через него
# вычисляются пользователи, присоединившиеся за интервал (API не отдаёт
# дату присоединения, поэтому используем дельту между запусками).
CLOUD_SNAPSHOT_FILE = os.path.join(BASE_DIR, "cloud_users_snapshot.json")

# API endpoints
TRACKER_API = "https://api.tracker.yandex.net/v3"
WIKI_API = "https://api.wiki.yandex.net/v1"
ORG_MANAGER_API = "https://organization-manager.api.cloud.yandex.net"
GRAPH_API = "https://graph.microsoft.com/v1.0"

# x-cloud-org-id организации (не секрет, но храним рядом с токеном)
YA_ORG_ID = load_ya_credentials()[1]
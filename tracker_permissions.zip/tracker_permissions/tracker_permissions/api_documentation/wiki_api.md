# Yandex Wiki API

*Собрано 59 страниц, начиная с https://yandex.ru/support/wiki/en/api-ref/access*


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/access -->

# API access

- [Headers](en/api-ref/access#headers)
- [Getting access to the API using the OAuth protocol](en/api-ref/access#about_oauth)
- [Getting access to the API with an IAM token](en/api-ref/access#iam-token)

If the Wiki administrator has disabled API access, you won't be able to set up the integration.

When working with Yandex Wiki API, requests are made on behalf of a user. To perform actions through the API, the user on whose behalf the request is made must have the appropriate permissions in Wiki. For example, if the user does not have permission to edit a page, the corresponding API requests will be unavailable. For more information about user permissions, see [Roles](https://yandex.ru/support/wiki/roles).

To access the Yandex Wiki API, you can use one of these authorization methods:

- OAuth 2.0 protocol — can be used in both Yandex 360 for Business and Yandex Cloud Organization organizations. For more information, see [Getting access to the API using the OAuth protocol](en/api-ref/access#about_oauth).
- IAM token — can only be used in Yandex Cloud organizations. For more information, see [Getting access to the API with an IAM token](en/api-ref/access#iam-token).

You cannot use a Yandex Cloud [service account](https://yandex.cloud/en/docs/iam/concepts/users/service-accounts) for authorization in the Yandex Wiki API. Send requests only from a user account.

## Headers

In Yandex Wiki API requests, specify the following headers:

- `Host: api.wiki.yandex.net`
- Authorization header:

  - `Authorization: OAuth <OAuth token>` — when using the OAuth 2.0 protocol.
  - `Authorization: Bearer <IAM token>` — when using an IAM token.
- Organization ID:

  - `X-Org-Id` — for Yandex 360 for Business organizations.
  - `X-Cloud-Org-Id` — for Yandex Cloud Organization organizations.

  To find your organization ID, open [Yandex Tracker](https://tracker.yandex.com/admin/orgs), go to **Administration** → [**Organizations**](https://tracker.yandex.com/admin/orgs), and copy the **ID** field value.

> Example:
>
> ```
> Host: api.wiki.yandex.net
> Authorization: OAuth y0__xAbc******
> X-Org-Id: 1234******
> ```

## Getting access to the API using the OAuth protocol

If you are using a federated account, authorize using an [IAM token](en/api-ref/access#iam-token).

To get a token:

1. Click the link <https://oauth.yandex.com>.
2. On the **Your apps** page, click  **Create**.
3. In the window that opens, select **For API access or debugging** and click **Create new token**.
4. Enter the app name and contact email.
5. Add permissions for accessing user data. To select a permission, start typing its name in the **Permission name** field:

   - **Write to Wiki (wiki:write)** — all data operations: creating, deleting, editing.
   - **Read from Wiki (wiki:read)** — only reading data.
6. Click **Create app**.
7. In your [Yandex OAuth](https://oauth.yandex.com) account, select the previously created application and copy its ID from the **ClientID** field.
8. Generate a link to request a token:

   ```
   https://oauth.yandex.com/authorize?response_type=token&client_id=<application_ID>
   ```
9. Log in to the account you will use to access the API, then follow the generated link.

   A sequence of characters will appear on the page — that is your OAuth token. Copy and save it.

To check if you have access to the API, send any request. If access has not been granted, the request will return a `401 Unauthorized` response.

For example, you can request information about the `mypage` page using curl:

Unix

Windows

```
curl -X GET 'https://api.wiki.yandex.net/v1/pages?slug=mypage' \
     -H 'Authorization: OAuth y0__xAbc******' \
     -H 'X-Org-Id: 1234******'
```

```
curl -X GET "https://api.wiki.yandex.net/v1/pages?slug=mypage" ^
     -H "Authorization: OAuth y0__xAbc******" ^
     -H "X-Org-Id: 1234******"
```

## Getting access to the API with an IAM token

If you are using Wiki as part of a Yandex Cloud organization, you can authorize with the API using an IAM token.

An IAM token is a unique sequence of characters issued to a user after authentication. The user uses this token to authorize with the Yandex Wiki API and perform operations on resources. For more information about this authentication method, see the [documentation of the identity and access management service](https://yandex.cloud/en/docs/iam/concepts/authorization/iam-token).

- [How to get an IAM token for a Yandex account](https://yandex.cloud/en/docs/iam/operations/iam-token/create)
- [How to get an IAM token for a federated account](https://yandex.cloud/en/docs/iam/operations/iam-token/create-for-federation)

The IAM token is valid for no more than 12 часов and is limited by the cookie lifetime for the [federation](https://yandex.cloud/en/docs/organization/concepts/add-federation). When the token expires, the `401 Unauthorized` error is returned.


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/examples -->

# Yandex Wiki API usage examples

- [1. Creating a page and adding content](en/api-ref/examples#create-page)
- [2. Creating a dynamic table, adding columns and rows](en/api-ref/examples#grid)
- [3. Creating a page and leaving comments](en/api-ref/examples#comments)
- [4. Retrieving a page subtree](en/api-ref/examples#descendants)
- [5. Deleting and recovering a page using a recovery token](en/api-ref/examples#delete-and-recover)
- [6. Uploading a file and attaching it to a page](en/api-ref/examples#upload-files)

This section provides examples of Python scripts that use the Yandex Wiki API to manage pages and responses.

In all examples, an OAuth token is used for authentication. For information on obtaining a token, see [API access](en/api-ref/access).

## 1. Creating a page and adding content

Below is an example of a script that performs the following actions:

- Creating a new page
- Editing page content
- Retrieving page attributes by its slug (path)

Text of the api\_example\_1.py script

```
import os
import requests
import sys

WIKI_PUBLIC_API = 'https://api.wiki.yandex.net/v1'
WIKI_TOKEN = os.environ.get('WIKI_TOKEN')
ORG_ID = os.environ.get('ORG_ID')

HEADERS = {
    'Authorization': f'OAuth {WIKI_TOKEN}',
    'X-Org-Id': ORG_ID,
}

def create_wiki_page(
    slug: str,
    title: str,
    content: str,
) -> int:
    """
    Create a new page

    Parameters:
    - slug: slug of the page being created
    - title: page title
    - content: page text
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    body = {
        'slug': slug,
        'title': title,
        'content': content,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create page: {response.status_code} {response.text}')
        return None

    res = response.json()
    return res.get('id')

def change_wiki_page(
    page_id: int,
    title: str = None,
    content: str = None,
) -> bool:
    """
    Edit an existing page

    Parameters:
    - page_id: page code
    - title: page title
    - content: page text
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}'
    body = {}
    if title:
        body['title'] = title
    if content:
        body['content'] = content
    response = requests.post(url, json=body, headers=HEADERS)
    return response.status_code == 200

def append_wiki_page_content(
    page_id: int,
    content: str,
    location: str = None,
) -> bool:
    """
    Add content to an existing page

    Parameters:
    - page_id: page code
    - content: text to insert
    - location: position to insert text;
      you can insert at the top of the page using `top`, at the bottom using `bottom`, or under an anchor, for example `#fragment`
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/append-content'
    body = {
        'content': content,
    }
    if location in ('top', 'bottom'):
        body['body'] = {'location': location}
    elif isinstance(location, str) and location.startswith('#'):
        body['anchor'] = {'name': location}
    else:
        body['body'] = {'location': 'bottom'}
    response = requests.post(url, json=body, headers=HEADERS)
    return response.status_code == 200

def get_wiki_page_attributes(slug: str) -> int:
    """
    Get the attributes of an existing page by its slug

    Parameters:
    - slug: slug of an existing page
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    params = {
        'slug': slug,
    }
    response = requests.get(url, params=params, headers=HEADERS)
    if response.status_code == 200:
        return response.json()

def main():
    if len(sys.argv) < 2:
        return
    slug = sys.argv[1]

    # Create a new page
    new_page_id = create_wiki_page(
        slug=slug,
        title='Test page',
        content=(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, '
            'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n'
        ),
    )
    if new_page_id:
        print(f'Created page with code {new_page_id}')

    # Update page content (note: this method replaces the entire page)
    is_changed = change_wiki_page(
        page_id=new_page_id,
        title='Updated test page',
        content=(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, '
            'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n'
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris '
            'nisi ut aliquip ex ea commodo consequat.\n'
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum '
            'dolore eu fugiat nulla pariatur.\n'
            'Excepteur sint occaecat cupidatat non proident, '
            'sunt in culpa qui officia deserunt mollit anim id est laborum.\n'
        ),
    )
    if is_changed:
        print('Page content updated')

    # Retrieve page attributes by its slug
    page_attributes = get_wiki_page_attributes(slug=slug)
    if not page_attributes:
        print('Wiki page not found')
        sys.exit(1)
    page_id = page_attributes.get('id')
    print(f'Found page with code {page_id}')

if __name__ == '__main__':
    main()
```

Here is an example of how to run the script (the slug of the page to be created is passed as an argument):

```
$ WIKI_TOKEN=$(cat .wiki-token) ORG_ID=$(cat .org-id) python api_example_1.py 'users/test/page'
Created page with code 49497033
Page content updated
Found page with code 49497033
```

## 2. Creating a dynamic table, adding columns and rows

Below is an example of a script that performs the following actions:

- Adding a new dynamic table to an existing page
- Adding columns and rows to the table
- Editing cells in a row
- Publishing the table on the page

Text of the api\_example\_2.py script

```
import os
import requests
import sys

WIKI_PUBLIC_API = 'https://api.wiki.yandex.net/v1'
WIKI_TOKEN = os.environ.get('WIKI_TOKEN')
ORG_ID = os.environ.get('ORG_ID')

HEADERS = {
    'Authorization': f'OAuth {WIKI_TOKEN}',
    'X-Org-Id': ORG_ID,
}

def get_wiki_page_attributes(slug: str) -> int:
    """
    Get the attributes of an existing page by its slug

    Parameters:
    - slug: slug of an existing page
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    params = {
        'slug': slug,
    }
    response = requests.get(url, params=params, headers=HEADERS)
    if response.status_code == 200:
        return response.json()

def append_wiki_page_content(
    page_id: int,
    content: str,
    location: str = None,
) -> bool:
    """
    Add content to an existing page

    Parameters:
    - page_id: page code
    - content: text to insert
    - location: position to insert text;
      you can insert at the top of the page using `top`, at the bottom using `bottom`,
      or under an anchor, for example `#fragment`
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/append-content'
    body = {
        'content': content,
    }
    if location in ('top', 'bottom'):
        body['body'] = {'location': location}
    elif isinstance(location, str) and location.startswith('#'):
        body['anchor'] = {'name': location}
    else:
        body['body'] = {'location': 'bottom'}
    response = requests.post(url, json=body, headers=HEADERS)
    return response.status_code == 200

def create_wiki_grid(page_id: int, title: str) -> int:
    """
    Create a new table

    Parameters:
    - page_id: page code
    - title: table title

    Note: after creation, the table is only accessible through the resource view interface;
    you still need to add it to a page.
    """
    url = f'{WIKI_PUBLIC_API}/grids'
    body = {
        'page': {'id': page_id},
        'title': title,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code == 200:
        res = response.json()
        return res.get('id')

def insert_grid_columns(grid_id: str, columns: list[dict]) -> bool:
    """
    Add columns to a table

    Parameters:
    - grid_id: table code
    - columns: list of columns to add
    """
    url = f'{WIKI_PUBLIC_API}/grids/{grid_id}/columns'
    body = {
        'columns': columns,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    return response.status_code == 200

def insert_grid_rows(grid_id: str, rows: list[dict]) -> bool:
    """
    Add rows to a table

    Parameters:
    - grid_id: table code
    - rows: list of rows to add
    """
    url = f'{WIKI_PUBLIC_API}/grids/{grid_id}/rows'
    body = {
        'rows': rows,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    return response.status_code == 200

def change_grid_cells(grid_id: str, cells: list[dict]) -> bool:
    """
    Edit cells in a table

    Parameters:
    - grid_id: table code
    - cells: list of cells to edit
    """
    url = f'{WIKI_PUBLIC_API}/grids/{grid_id}/cells'
    body = {
        'cells': cells,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    return response.status_code == 200

def main():
    if len(sys.argv) < 2:
        return
    slug = sys.argv[1]

    # Retrieve page attributes by its slug
    page_attributes = get_wiki_page_attributes(
        slug=slug,
    )
    if not page_attributes:
        print('Wiki page not found')
        sys.exit(1)
    page_id = page_attributes.get('id')
    print(f'Found page with code {page_id}')

    # Create a new table
    grid_id = create_wiki_grid(
        page_id=page_id,
        title='New table',
    )
    if grid_id:
        print(f'Created table with code {grid_id}')

    # Add columns to the new table (columns can be of different types)
    is_changed = insert_grid_columns(
        grid_id=grid_id,
        columns=[
            {
                'slug': 'id',
                'title': 'ID',
                'type': 'number',
                'required': True,
            },
            {
                'slug': 'name',
                'title': 'Name',
                'type': 'string',
                'required': False,
            },
        ],
    )
    if is_changed:
        print('New columns added to table')

    # Add rows to the new table
    is_changed = insert_grid_rows(
        grid_id=grid_id,
        rows=[
            {'id': 1, 'name': 'One'},
            {'id': 2, 'name': 'Two'},
            {'id': 3, 'name': 'Three'},
            {'id': 4, 'name': 'Four'},
            {'id': 5, 'name': 'Five'},
        ],
    )
    if is_changed:
        print('New rows added to table')

    # Edit cells in the second row of the table
    is_changed = change_grid_cells(
        grid_id=grid_id,
        cells=[
            {'row_id': 2, 'column_slug': 'id', 'value': 22},
            {'row_id': 2, 'column_slug': 'name', 'value': 'Twenty-two'},
        ],
    )
    if is_changed:
        print('Second row in table updated')

    # Place the new table at the bottom of the page
    is_changed = append_wiki_page_content(
        page_id=page_id,
        content=f'\n{{% wgrid id="{grid_id}" %}}',
    )
    if is_changed:
        print('Created table added to the bottom of the page')

if __name__ == '__main__':
    main()
```

```
$ WIKI_TOKEN=$(cat .wiki-token) ORG_ID=$(cat .org-id) python api_example_2.py 'users/test/page'
Found page with code 49497033
Created table with code 7d8f08c1-fbbf-4015-83b5-362ca2fc965c
New columns added to table
New rows added to table
Second row in table updated
Created table added to the bottom of the page
```

## 3. Creating a page and leaving comments

Below is an example of a script that performs the following actions:

- Creating a page at the specified address
- Adding comments, including reply comments

Text of the api\_example\_3.py script

```
import os
import requests
import sys

WIKI_PUBLIC_API = 'https://api.wiki.yandex.net/v1'
WIKI_TOKEN = os.environ.get('WIKI_TOKEN')
ORG_ID = os.environ.get('ORG_ID')

HEADERS = {
    'Authorization': f'OAuth {WIKI_TOKEN}',
    'X-Org-Id': ORG_ID,
}

def create_wiki_page(slug: str, title: str, content: str) -> int | None:
    """
    Create a new page
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    body = {
        'slug': slug,
        'title': title,
        'content': content,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create page: {response.status_code} {response.text}')
        return None
    return response.json().get('id')

def get_wiki_page_id(slug: str) -> int | None:
    """
    Get the code of an existing page by its slug (address)
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    response = requests.get(url, params={'slug': slug}, headers=HEADERS)
    if response.status_code != 200:
        return None
    return response.json().get('id')

def create_comment(page_id: int, body: str, parent_id: int = None, thread_id: int = None) -> int | None:
    """
    Create a comment on a page
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/comments'
    data = {'body': body}
    if parent_id is not None:
        data['parent_id'] = parent_id
    if thread_id is not None:
        data['thread_id'] = thread_id
    response = requests.post(url, json=data, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create comment: {response.status_code} {response.text}')
        return None
    return response.json().get('id')

def get_page_comments(page_id: int) -> list | None:
    """
    Get the list of comments on a page
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/comments'
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to retrieve comments: {response.status_code} {response.text}')
        return None
    return response.json().get('results')

def main():
    if len(sys.argv) < 2:
        return
    slug = sys.argv[1]

    # Retrieve an existing page or create a new one
    page_id = get_wiki_page_id(slug=slug)
    if page_id:
        print(f'Found page with code {page_id}')
    else:
        page_id = create_wiki_page(
            slug=slug,
            title='Test page with comments',
            content='See comments.\n',
        )
        if not page_id:
            return
        print(f'Created page with code {page_id}')

    # Create two root comments and three replies:
    comment_1 = create_comment(page_id=page_id, body='First comment')
    if comment_1:
        print(f'Created comment {comment_1}')

    comment_2 = create_comment(page_id=page_id, body='Second comment')
    if comment_2:
        print(f'Created comment {comment_2}')

    comment_3 = create_comment(page_id=page_id, body='Third comment', parent_id=comment_1, thread_id=comment_1)
    if comment_3:
        print(f'Created comment {comment_3}')

    comment_4 = create_comment(page_id=page_id, body='Fourth comment', parent_id=comment_1, thread_id=comment_1)
    if comment_4:
        print(f'Created comment {comment_4}')

    comment_5 = create_comment(page_id=page_id, body='Fifth comment', parent_id=comment_2, thread_id=comment_2)
    if comment_5:
        print(f'Created comment {comment_5}')

if __name__ == '__main__':
    main()
```

```
$ WIKI_TOKEN=$(cat .wiki-token) ORG_ID=$(cat .org-id) python api_example_3.py 'users/test/page'
Created page with code 49497133
Created comment 856798
Created comment 856799
Created comment 856800
Created comment 856801
Created comment 856802
```

## 4. Retrieving a page subtree

Below is an example of a script that performs the following actions:

- Creating a tree of 10 pages at the specified address
- Retrieving and printing the subtree for the specified page

Text of the api\_example\_4.py script

```
import os
import requests
import sys

WIKI_PUBLIC_API = 'https://api.wiki.yandex.net/v1'
WIKI_TOKEN = os.environ.get('WIKI_TOKEN')
ORG_ID = os.environ.get('ORG_ID')

HEADERS = {
    'Authorization': f'OAuth {WIKI_TOKEN}',
    'X-Org-Id': ORG_ID,
}

def create_wiki_page(slug: str, title: str, content: str) -> int | None:
    """
    Create a new page
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    body = {
        'slug': slug,
        'title': title,
        'content': content,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create page {slug}: {response.status_code} {response.text}')
        return None
    return response.json().get('id')

def get_wiki_page_id(slug: str) -> int | None:
    """
    Get the code of an existing page by its slug
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    response = requests.get(url, params={'slug': slug}, headers=HEADERS)
    if response.status_code != 200:
        return None
    return response.json().get('id')

def get_descendants(slug: str, include_self: bool = False) -> list | None:
    """
    Get the list of descendants of a page by its slug
    """
    url = f'{WIKI_PUBLIC_API}/pages/descendants'
    params = {
        'slug': slug,
        'include_self': include_self,
        'page_size': 100,
    }
    response = requests.get(url, params=params, headers=HEADERS)
    if response.status_code != 200:
        return None
    return response.json().get('results')

def main():
    if len(sys.argv) < 2:
        return
    slug = sys.argv[1]

    pages = [
        (slug, 'Test page for subpages'),
        (f'{slug}/page-1', 'Page 1'),
        (f'{slug}/page-1/sub-1', 'Subpage 1-1'),
        (f'{slug}/page-1/sub-2', 'Subpage 1-2'),
        (f'{slug}/page-2', 'Page 2'),
        (f'{slug}/page-2/sub-1', 'Subpage 2-1'),
        (f'{slug}/page-2/sub-2', 'Subpage 2-2'),
        (f'{slug}/page-3', 'Page 3'),
        (f'{slug}/page-4', 'Page 4'),
        (f'{slug}/page-5', 'Page 5'),
    ]

    # Create a page tree
    for page_slug, title in pages:
        page_id = get_wiki_page_id(slug=page_slug)
        if page_id:
            print(f'Page found: {page_slug} (code {page_id})')
        else:
            page_id = create_wiki_page(slug=page_slug, title=title, content=f'{title}.\n')
            if not page_id:
                return
            print(f'Page created: {page_slug} (code {page_id})')

    # Retrieve descendants of the specified page (including the page itself)
    print(f'Descendants of {slug} (inclusive):')
    subtree = get_descendants(slug=slug, include_self=True)
    if subtree is not None:
        for page in subtree:
            print(f'- {page.get("slug")}')
        print(f'Total: {len(subtree)}')

if __name__ == '__main__':
    main()
```

```
$ WIKI_TOKEN=$(cat .wiki-token) ORG_ID=$(cat .org-id) python api_example_4.py 'users/test/descendants'
Page created: users/test/descendants (code 49497245)
Page created: users/test/descendants/page-1 (code 49497246)
Page created: users/test/descendants/page-1/sub-1 (code 49497247)
Page created: users/test/descendants/page-1/sub-2 (code 49497248)
Page created: users/test/descendants/page-2 (code 49497249)
Page created: users/test/descendants/page-2/sub-1 (code 49497250)
Page created: users/test/descendants/page-2/sub-2 (code 49497252)
Page created: users/test/descendants/page-3 (code 49497253)
Page created: users/test/descendants/page-4 (code 49497254)
Page created: users/test/descendants/page-5 (code 49497255)
Descendants of users/test/descendants (inclusive):
- users/test/descendants
- users/test/descendants/page-1
- users/test/descendants/page-1/sub-1
- users/test/descendants/page-1/sub-2
- users/test/descendants/page-2
- users/test/descendants/page-2/sub-1
- users/test/descendants/page-2/sub-2
- users/test/descendants/page-3
- users/test/descendants/page-4
- users/test/descendants/page-5
Total: 10
```

## 5. Deleting and recovering a page using a recovery token

Below is an example of a script that performs the following actions:

- Creating a page at the specified address
- Deleting the created page and obtaining a recovery token
- Recovering the page using the obtained token

Text of the api\_example\_5.py script

```
import os
import requests
import sys

WIKI_PUBLIC_API = 'https://api.wiki.yandex.net/v1'
WIKI_TOKEN = os.environ.get('WIKI_TOKEN')
ORG_ID = os.environ.get('ORG_ID')

HEADERS = {
    'Authorization': f'OAuth {WIKI_TOKEN}',
    'X-Org-Id': ORG_ID,
}

def create_wiki_page(slug: str, title: str, content: str) -> int | None:
    """
    Create a new page
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    body = {
        'slug': slug,
        'title': title,
        'content': content,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create page: {response.status_code} {response.text}')
        return None
    return response.json().get('id')

def get_wiki_page_id(slug: str) -> int | None:
    """
    Get the code of an existing page by its slug
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    response = requests.get(url, params={'slug': slug}, headers=HEADERS)
    if response.status_code != 200:
        return None
    return response.json().get('id')

def delete_wiki_page(page_id: int) -> str | None:
    """
    Delete a page and return the recovery token
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}'
    response = requests.delete(url, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to delete page: {response.status_code} {response.text}')
        return None
    return response.json().get('recovery_token')

def recover_wiki_page(token: str) -> int | None:
    """
    Recover a deleted page using a recovery token
    """
    url = f'{WIKI_PUBLIC_API}/recovery_tokens/{token}/recover'
    response = requests.post(url, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to recover page: {response.status_code} {response.text}')
        return None
    return response.json().get('id')

def main():
    if len(sys.argv) < 2:
        return
    slug = sys.argv[1]

    # Retrieve an existing page or create a new one
    page_id = get_wiki_page_id(slug=slug)
    if page_id:
        print(f'Found page with code {page_id}')
    else:
        page_id = create_wiki_page(
            slug=slug,
            title='Test page for recovery',
            content='Test page content.\n',
        )
        if not page_id:
            return
        print(f'Created page with code {page_id}')

    # Delete the page and obtain the recovery token
    recovery_token = delete_wiki_page(page_id=page_id)
    if not recovery_token:
        return
    print(f'Page deleted, recovery token: {recovery_token}')

    # Recover the page using the token
    restored_id = recover_wiki_page(token=recovery_token)
    if not restored_id:
        return
    print(f'Page recovered with code {restored_id}')

if __name__ == '__main__':
    main()
```

```
$ WIKI_TOKEN=$(cat .wiki-token) ORG_ID=$(cat .org-id) python api_example_5.py 'users/test/page-recover'
Created page with code 49497351
Page deleted, recovery token: b5807bca-4a69-4148-bb43-fab64fd20942
Page recovered with code 49497351
```

## 6. Uploading a file and attaching it to a page

File uploads are performed through multipart upload sessions (each part up to 5 MB).

Below is an example of a script that performs the following actions:

- Creating a page
- Uploading a file
- Attaching the file to the page
- Printing all resources and attachments of the page

Text of the api\_example\_6.py script

```
import os
import requests
import sys

WIKI_PUBLIC_API = 'https://api.wiki.yandex.net/v1'
WIKI_TOKEN = os.environ.get('WIKI_TOKEN')
ORG_ID = os.environ.get('ORG_ID')

CHUNK_SIZE = 5 * 1024 * 1024  # 5 MB — minimum part size for multipart upload

HEADERS = {
    'Authorization': f'OAuth {WIKI_TOKEN}',
    'X-Org-Id': ORG_ID,
}

def get_file_pattern(file_url: str, file_name: str) -> str:
    return f'{{% file src="{file_url}" name="{file_name}" %}}'

def create_wiki_page(slug: str, title: str, content: str) -> int | None:
    """
    Create a new page
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    body = {
        'slug': slug,
        'title': title,
        'content': content,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create page: {response.status_code} {response.text}')
        return None
    return response.json().get('id')

def get_wiki_page_id(slug: str) -> int | None:
    """
    Get the code of an existing page by its slug (address)
    """
    url = f'{WIKI_PUBLIC_API}/pages'
    response = requests.get(url, params={'slug': slug}, headers=HEADERS)
    if response.status_code != 200:
        return None
    return response.json().get('id')

def create_upload_session(file_name: str, file_size: int) -> str | None:
    """
    Create a file upload session
    """
    url = f'{WIKI_PUBLIC_API}/upload_sessions'
    body = {
        'file_name': file_name,
        'file_size': file_size,
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to create upload session: {response.status_code} {response.text}')
        return None
    return response.json().get('session_id')

def upload_file_part(session_id: str, part_number: int, data: bytes) -> bool:
    """
    Upload a part of the file within a session
    """
    url = f'{WIKI_PUBLIC_API}/upload_sessions/{session_id}/upload_part'
    headers = {**HEADERS, 'Content-Type': 'application/octet-stream'}
    response = requests.put(
        url,
        params={'part_number': part_number},
        data=data,
        headers=headers,
        stream=True,
    )
    return response.status_code == 200

def finish_upload_session(session_id: str) -> bool:
    """
    Finish the file upload session
    """
    url = f'{WIKI_PUBLIC_API}/upload_sessions/{session_id}/finish'
    response = requests.post(url, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to finish upload session: {response.status_code} {response.text}')
        return False
    return True

def attach_file_to_page(page_id: int, session_id: str) -> list | None:
    """
    Attach an uploaded file to a page
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/attachments'
    body = {
        'upload_sessions': [session_id],
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to attach file to page: {response.status_code} {response.text}')
        return None
    return response.json().get('results')

def append_wiki_page_content(page_id: int, content: str) -> bool:
    """
    Add content to the bottom of a page
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/append-content'
    body = {
        'content': content,
        'body': {'location': 'bottom'},
    }
    response = requests.post(url, json=body, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to add content to page: {response.status_code} {response.text}')
        return False
    return True

def get_page_resources(page_id: int) -> list | None:
    """
    Get the list of page resources (attachments, tables)
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/resources'
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to retrieve page resources: {response.status_code} {response.text}')
        return None
    return response.json().get('results')

def get_page_attachments(page_id: int) -> list | None:
    """
    Get the list of page attachments
    """
    url = f'{WIKI_PUBLIC_API}/pages/{page_id}/attachments'
    response = requests.get(url, headers=HEADERS)
    if response.status_code != 200:
        print(f'Failed to retrieve page attachments: {response.status_code} {response.text}')
        return None
    return response.json().get('results')

def main():
    if len(sys.argv) < 3:
        return
    slug = sys.argv[1]
    file_path = sys.argv[2]

    # Retrieve an existing page or create a new one
    page_id = get_wiki_page_id(slug=slug)
    if page_id:
        print(f'Found page with code {page_id}')
    else:
        page_id = create_wiki_page(
            slug=slug,
            title='Test page with attachments',
            content='Some text.\n',
        )
        if not page_id:
            return
        print(f'Created page with code {page_id}')

    # Read the file for upload
    file_name = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)

    # Create an upload session
    session_id = create_upload_session(
        file_name=file_name,
        file_size=file_size,
    )
    if not session_id:
        return
    print(f'Created upload session {session_id}')

    # Upload the file in parts (each part is at least 5 MB, except the last one)
    with open(file_path, 'rb') as f:
        part_number = 1
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            if not upload_file_part(session_id=session_id, part_number=part_number, data=chunk):
                return
            print(f'Uploaded part {part_number}')
            part_number += 1

    # Finish the upload session
    if not finish_upload_session(session_id=session_id):
        return
    print('Upload session finished')

    # Attach the file to the page
    attached = attach_file_to_page(page_id=page_id, session_id=session_id)
    if not attached:
        return
    print('File attached to page')

    # Insert a file reference at the bottom of the page
    file_url = attached[0].get('download_url')
    file_name = attached[0].get('name')
    text = f'Attached file: {get_file_pattern(file_url, file_name)}'
    if append_wiki_page_content(page_id=page_id, content=text):
        print(f'Reference to file {file_name} added to page')

    # Get the list of page resources
    resources = get_page_resources(page_id=page_id)
    if resources is not None:
        print(f'\nPage resources ({len(resources)}):')
        for resource in resources:
            resource_type = resource.get('type')
            item = resource.get('item', {})
            print(f'- Type: {resource_type}, name: {item.get('name')}')

    # Get the list of page attachments
    attachments = get_page_attachments(page_id=page_id)
    if attachments is not None:
        print(f'\nPage attachments ({len(attachments)}):')
        for attachment in attachments:
            print(
                f'- Code: {attachment.get('id')}, '
                f'name: {attachment.get('name')}, '
                f'size: {attachment.get('size')} MB, '
                f'type: {attachment.get('mimetype')}'
            )

if __name__ == '__main__':
    main()
```

```
$ WIKI_TOKEN=$(cat .wiki-token) ORG_ID=$(cat .org-id) python api_example_6.py 'users/test/upload' 'file.zip'
Created page with code 49497369
Created upload session e127b2a1-e183-4abd-b6c7-3131ea637f14
Uploaded part 1
Upload session finished
File attached to page
Reference to file file.zip added to page

Page resources (1):
- Type: attachment, name: file.zip

Page attachments (1):
- Code: 23066834, name: file.zip, size: 2.04 MB, type: application/zip
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/ -->

# Wiki Public API

`version: 1.0.0`

### Error format

In general, an error message has the following structure:

```
{
    "debug_message": "",
    "details": {},
    "error_code": ""
}
```

For example:

```
{
    "debug_message": "Validation failed",
    "details": {
        "body": {
            "data": [
                {
                    "debug_message": "field required",
                    "error_code": "value_error.missing"
                }
            ]
        }
    },
    "error_code": "VALIDATION_ERROR"
}
```

Use `error_code` as the primary reference. The `debug_message` field contains a human-readable description of the error. The `details` field provides additional information when available, or `null` if not applicable.

#### Validation error message format

```
{
    "debug_message": "Validation failed",
    "details": {
        "<source>": {
            "<field>": [
                {
                    "debug_message": "<validation debug message>",
                    "error_code": "<validation error code>"
                }
            ]
        }
    },
    "error_code": "VALIDATION_ERROR"
}
```

`<source>` — the data source where the validation error occurred; possible values: `[body, query]`

`<field>` — the name of the field that failed validation. The value is a list containing the local `debug_message` and `error_code` with details about the error.

## Sections

- [Pages](en/api-ref/pages/)
- [Attached Files](en/api-ref/attachments/)
- [Page Access](en/api-ref/pages_access/)
- [Page Resources](en/api-ref/pagesresources/)
- [Comments](en/api-ref/comments/)
- [Dynamic Tables](en/api-ref/grids/)
- [Users](en/api-ref/users/)
- [Upload Sessions](en/api-ref/upload_sessions/)
- [Operations](en/api-ref/operations/)
- [Page Recovery](en/api-ref/recovery_tokens/)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/attachments/ -->

# Attached Files

## Endpoints

- [Download By Filename Slug Pair](en/api-ref/attachments/pagesattachments__download_by_filename_slug_pair)
- [Attachments](en/api-ref/attachments/pagesattachments__attachments)
- [Attach File](en/api-ref/attachments/pagesattachments__attach_file)
- [Download By File Id](en/api-ref/attachments/pagesattachments__download_by_file_id)
- [Delete Attach](en/api-ref/attachments/pagesattachments__delete_attach)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/attachments/pagesattachments__attach_file -->

- [Request](en/api-ref/attachments/pagesattachments__attach_file#request)
  - [Path parameters](en/api-ref/attachments/pagesattachments__attach_file#path-parameters)
  - [Body](en/api-ref/attachments/pagesattachments__attach_file#body)
- [Responses](en/api-ref/attachments/pagesattachments__attach_file#responses)
- [200 OK](en/api-ref/attachments/pagesattachments__attach_file#200-ok)
  - [Body](en/api-ref/attachments/pagesattachments__attach_file#body1)
  - [UserIdentity](en/api-ref/attachments/pagesattachments__attach_file#entity-UserIdentity)
  - [UserSchema](en/api-ref/attachments/pagesattachments__attach_file#entity-UserSchema)
  - [FileCheckStatusType](en/api-ref/attachments/pagesattachments__attach_file#entity-FileCheckStatusType)
  - [AttachmentSchema](en/api-ref/attachments/pagesattachments__attach_file#entity-AttachmentSchema)

# Attach File

Add a file from the specified upload session to the page. [How to create a file upload session](en/api-ref/upload_sessions/upload_sessions__create_upload_session)

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}/attachments
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Body

application/json

```
{
  "upload_sessions": [
    "example"
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *upload\_sessions* | **Type**: string<uuid4>[] **Example** ``` [   "example" ] ``` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": 0,
      "name": "example",
      "is_downloadable": true,
      "download_url": "example",
      "size": "example",
      "description": "example",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "created_at": "2025-01-01T00:00:00Z",
      "mimetype": "example",
      "has_preview": true,
      "check_status": "ready"
    }
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *results* | **Type**: [AttachmentSchema](en/api-ref/attachments/pagesattachments__attach_file#entity-AttachmentSchema)[] **Example** ``` [   {     "id": 0,     "name": "example",     "is_downloadable": true,     "download_url": "example",     "size": "example",     "description": "example",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z",     "mimetype": "example",     "has_preview": true,     "check_status": "ready"   } ] ``` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/attachments/pagesattachments__attach_file#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### FileCheckStatusType

Antivirus file check status:

- `check` — the file is being checked
- `ready` — the file has been checked and is safe
- `deleted` — the file has been deleted
- `infected` — a virus has been detected
- `error` — an error occurred during the check

**Type**: string

*Enum:* `check`, `ready`, `deleted`, `infected`, `error`

### AttachmentSchema

A file attached to the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the file was uploaded  *Example:* `2025-01-01T00:00:00Z` |
| *description* | **Type**: string  File description  *Example:* `example` |
| *download\_url* | **Type**: string  File download URL  *Example:* `example` |
| *has\_preview* | **Type**: boolean  Whether a file preview is available |
| *id* | **Type**: integer  Unique file identifier |
| *mimetype* | **Type**: string  File MIME type  *Example:* `example` |
| *name* | **Type**: string  File name  *Example:* `example` |
| *size* | **Type**: string  File size  *Example:* `example` |
| *check\_status* | **All of 1 type** - **FileCheckStatusType**  **Type**: [FileCheckStatusType](en/api-ref/attachments/pagesattachments__attach_file#entity-FileCheckStatusType)  Antivirus file check status:    - `check` — the file is being checked   - `ready` — the file has been checked and is safe   - `deleted` — the file has been deleted   - `infected` — a virus has been detected   - `error` — an error occurred during the check *Enum:* `check`, `ready`, `deleted`, `infected`, `error`  Antivirus file check status  *Default:* `ready` |
| *is\_downloadable* | **Type**: boolean  Whether the file is available for download  *Default:* `true` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/attachments/pagesattachments__attach_file#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who uploaded the file **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": 0,
  "name": "example",
  "is_downloadable": true,
  "download_url": "example",
  "size": "example",
  "description": "example",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "mimetype": "example",
  "has_preview": true,
  "check_status": "ready"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/attachments/pagesattachments__download_by_filename_slug_pair -->

- [Request](en/api-ref/attachments/pagesattachments__download_by_filename_slug_pair#request)
  - [Query parameters](en/api-ref/attachments/pagesattachments__download_by_filename_slug_pair#query-parameters)
- [Responses](en/api-ref/attachments/pagesattachments__download_by_filename_slug_pair#responses)
- [200 OK](en/api-ref/attachments/pagesattachments__download_by_filename_slug_pair#200-ok)

# Download By Filename Slug Pair

Download a file by the slug of the page it was uploaded to and the file name.

If the page has been moved (along with its files), the system attempts to find the new address using redirects.

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/attachments/download_by_url
```

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *url* | **Type**: string  *Min length:* `1`  *Pattern:* `^(?P<tag>((\.templates\.\d+)&#124;(\w&#124;\-)[\w\-\.:\+]*)(/(\w&#124;\-)[\w\-\.:\+]*)*/?)/.files/(?P<filename>.+)$`  *Example:* `` |
| *download* | **Type**: boolean  Download the file instead of displaying it in the browser, regardless of the MIME type  *Default:* `false` |

## Responses

## 200 OK

OK


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/comments/ -->

# Comments

## Endpoints

- [Comments](en/api-ref/comments/pagescomments__comments)
- [Create Comment](en/api-ref/comments/pagescomments__create_comment)
- [Thread Comments](en/api-ref/comments/pagescomments__thread_comments)
- [Delete Comment](en/api-ref/comments/pagescomments__delete_comment)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/about -->

You can find the API documentation for other Yandex 360 for Business services in [Yandex 360 for Business Help](https://360.yandex.ru/business/help/#dev-block).


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/ -->

# Dynamic Tables

## Endpoints

- [Create Grid](en/api-ref/grids/grids__create_grid)
- [Get Grid](en/api-ref/grids/grids__get_grid)
- [Update Grid](en/api-ref/grids/grids__update_grid)
- [Delete Grid](en/api-ref/grids/grids__delete_grid)
- [Add Rows](en/api-ref/grids/grids__add_rows)
- [Remove Rows](en/api-ref/grids/grids__remove_rows)
- [Add Columns](en/api-ref/grids/grids__add_columns)
- [Remove Columns](en/api-ref/grids/grids__remove_columns)
- [Update Cells](en/api-ref/grids/grids__update_cells)
- [Move Rows](en/api-ref/grids/grids__move_rows)
- [Move Columns](en/api-ref/grids/grids__move_columns)
- [Clone Grid](en/api-ref/grids/grids__clone_grid)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/recovery_tokens/ -->

# Page Recovery

## Endpoints

- [Recover Page By Token](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/comments/pagescomments__delete_comment -->

- [Request](en/api-ref/comments/pagescomments__delete_comment#request)
  - [Path parameters](en/api-ref/comments/pagescomments__delete_comment#path-parameters)
- [Responses](en/api-ref/comments/pagescomments__delete_comment#responses)
- [200 OK](en/api-ref/comments/pagescomments__delete_comment#200-ok)
  - [Body](en/api-ref/comments/pagescomments__delete_comment#body)

# Delete Comment

## Request

DELETE

```
https://api.wiki.yandex.net/v1/pages/{idx}/comments/{comment_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comment\_id* | **Type**: integer |
| *idx* | **Type**: integer |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "comments_count": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comments\_count* | **Type**: integer |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__delete_grid -->

- [Request](en/api-ref/grids/grids__delete_grid#request)
  - [Path parameters](en/api-ref/grids/grids__delete_grid#path-parameters)
- [Responses](en/api-ref/grids/grids__delete_grid#responses)
- [204 No Content](en/api-ref/grids/grids__delete_grid#204-no-content)
  - [Body](en/api-ref/grids/grids__delete_grid#body)

# Delete Grid

## Request

DELETE

```
https://api.wiki.yandex.net/v1/grids/{idx}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

## Responses

## 204 No Content

No Content

### Body

application/json

```
{}
```

|  |  |
| --- | --- |
| **Name** | **Description** |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__update_cells -->

- [Request](en/api-ref/grids/grids__update_cells#request)
  - [Path parameters](en/api-ref/grids/grids__update_cells#path-parameters)
  - [Body](en/api-ref/grids/grids__update_cells#body)
  - [UserIdentityExtended](en/api-ref/grids/grids__update_cells#entity-UserIdentityExtended)
  - [UpdateCellSchema](en/api-ref/grids/grids__update_cells#entity-UpdateCellSchema)
- [Responses](en/api-ref/grids/grids__update_cells#responses)
- [200 OK](en/api-ref/grids/grids__update_cells#200-ok)
  - [Body](en/api-ref/grids/grids__update_cells#body1)
  - [TicketSchema](en/api-ref/grids/grids__update_cells#entity-TicketSchema)
  - [UserIdentity](en/api-ref/grids/grids__update_cells#entity-UserIdentity)
  - [UserSchema](en/api-ref/grids/grids__update_cells#entity-UserSchema)
  - [UnresolvedUserSchema](en/api-ref/grids/grids__update_cells#entity-UnresolvedUserSchema)
  - [TrackerEnumField](en/api-ref/grids/grids__update_cells#entity-TrackerEnumField)
  - [CellSchema](en/api-ref/grids/grids__update_cells#entity-CellSchema)

# Update Cells

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}/cells
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "cells": [
    {
      "row_id": 0,
      "column_slug": "example",
      "value": 0
    }
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cells* | **Type**: [UpdateCellSchema](en/api-ref/grids/grids__update_cells#entity-UpdateCellSchema)[] **Example** ``` [   {     "row_id": 0,     "column_slug": "example",     "value": 0   } ] ``` |
| *revision* | **Type**: string  *Example:* `example` |

### UserIdentityExtended

Extended user identifier with additional fields

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in Yandex Cloud  *Example:* `example` |
| *uid* | **Type**: string  Unique user identifier (UID) in Yandex  *Example:* `example` |
| *username* | **Type**: string  User login  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example",
  "username": "example"
}
```

### UpdateCellSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *column\_slug* | **Type**: string  *Example:* `example` |
| *row\_id* | **Type**: integer |
| *value* | **Any of 6 types** - **Type**: integer - **Type**: number - **Type**: boolean - **Type**: string  *Example:* `example` - **Type**: string[] **Example** ```   [     "example"   ]   ``` - **Type**: [UserIdentityExtended](en/api-ref/grids/grids__update_cells#entity-UserIdentityExtended)[] **Example** ```   [     {       "uid": "example",       "cloud_uid": "example",       "username": "example"     }   ]   ```  *Example:* `0` |

**Example**

```
{
  "row_id": 0,
  "column_slug": "example",
  "value": 0
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example",
  "cells": [
    {
      "row_id": "example",
      "column_slug": "example",
      "value": 0
    }
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cells* | **Type**: [CellSchema](en/api-ref/grids/grids__update_cells#entity-CellSchema)[] **Example** ``` [   {     "row_id": "example",     "column_slug": "example",     "value": 0   } ] ``` |
| *revision* | **Type**: string  *Example:* `example` |

### TicketSchema

Ticket schema from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *key* | **Type**: string  Ticket key (for example, `WIKI-123`)  *Example:* `example` |
| *resolved* | **Type**: boolean  The ticket is resolved (closed) |

**Example**

```
{
  "key": "example",
  "resolved": true
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__update_cells#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### UnresolvedUserSchema

Schema for a user that was not found in the system

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__update_cells#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |
| *username* | **Type**: string  User login  *Example:* `example` |

**Example**

```
{
  "username": "example",
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  }
}
```

### TrackerEnumField

Enumeration field from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *display* | **Type**: string  Displayed field value  *Example:* `example` |
| *key* | **Type**: string  Field value key  *Example:* `example` |

**Example**

```
{
  "display": "example",
  "key": "example"
}
```

### CellSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *column\_slug* | **Type**: string  *Example:* `example` |
| *row\_id* | **Type**: string  *Example:* `example` |
| *value* | **Any of 10 types** - **Type**: integer - **Type**: number - **Type**: boolean - **Type**: string  *Example:* `example` - **TicketSchema**  **Type**: [TicketSchema](en/api-ref/grids/grids__update_cells#entity-TicketSchema)  Ticket schema from Yandex Tracker **Example** ```   {     "key": "example",     "resolved": true   }   ``` - **Type**: string[] **Example** ```   [     "example"   ]   ``` - **Type**: array **Any of 2 types** - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__update_cells#entity-UserSchema)  Information about the user **Example** ```     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }     ```   - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__update_cells#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```     {       "username": "example",       "identity": {         "uid": "example",         "cloud_uid": "example"       }     }     ``` **Example** ```   [     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }   ]   ``` - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__update_cells#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ``` - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__update_cells#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```   {     "username": "example",     "identity": {       "uid": "example",       "cloud_uid": "example"     }   }   ``` - **TrackerEnumField**  **Type**: [TrackerEnumField](en/api-ref/grids/grids__update_cells#entity-TrackerEnumField)  Enumeration field from Yandex Tracker **Example** ```   {     "display": "example",     "key": "example"   }   ```  *Example:* `0` |

**Example**

```
{
  "row_id": "example",
  "column_slug": "example",
  "value": 0
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/users/users__me -->

- [Request](en/api-ref/users/users__me#request)
- [Responses](en/api-ref/users/users__me#responses)
- [200 OK](en/api-ref/users/users__me#200-ok)
  - [Body](en/api-ref/users/users__me#body)
  - [UserIdentity](en/api-ref/users/users__me#entity-UserIdentity)
  - [OrganizationIdentity](en/api-ref/users/users__me#entity-OrganizationIdentity)

# Me

Returns information about the current user.

## Request

GET

```
https://api.wiki.yandex.net/v1/users/me
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "username": "example",
  "home_cluster": "example",
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "org": {
    "dir_id": "example",
    "collab_id": "123e4567-e89b-12d3-a456-426614174000"
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **Type**: [UserIdentity](en/api-ref/users/users__me#entity-UserIdentity)  User identifier **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |
| *org* | **Type**: [OrganizationIdentity](en/api-ref/users/users__me#entity-OrganizationIdentity) **Example** ``` {   "dir_id": "example",   "collab_id": "123e4567-e89b-12d3-a456-426614174000" } ``` |
| *username* | **Type**: string  *Example:* `example` |
| *home\_cluster* | **Type**: string  *Example:* `example` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### OrganizationIdentity

|  |  |
| --- | --- |
| **Name** | **Description** |
| *collab\_id* | **Type**: string<uuid>  *Example:* `123e4567-e89b-12d3-a456-426614174000` |
| *dir\_id* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "dir_id": "example",
  "collab_id": "123e4567-e89b-12d3-a456-426614174000"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__add_columns -->

- [Request](en/api-ref/grids/grids__add_columns#request)
  - [Path parameters](en/api-ref/grids/grids__add_columns#path-parameters)
  - [Body](en/api-ref/grids/grids__add_columns#body)
  - [ColumnType](en/api-ref/grids/grids__add_columns#entity-ColumnType)
  - [WidthUnits](en/api-ref/grids/grids__add_columns#entity-WidthUnits)
  - [ColumnPinTypes](en/api-ref/grids/grids__add_columns#entity-ColumnPinTypes)
  - [BGColor](en/api-ref/grids/grids__add_columns#entity-BGColor)
  - [TextFormat](en/api-ref/grids/grids__add_columns#entity-TextFormat)
  - [TicketField](en/api-ref/grids/grids__add_columns#entity-TicketField)
  - [NewColumnSchema](en/api-ref/grids/grids__add_columns#entity-NewColumnSchema)
- [Responses](en/api-ref/grids/grids__add_columns#responses)
- [200 OK](en/api-ref/grids/grids__add_columns#200-ok)
  - [Body](en/api-ref/grids/grids__add_columns#body1)

# Add Columns

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}/columns
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "position": 0,
  "columns": [
    {
      "id": "example",
      "slug": "example",
      "title": "example",
      "type": "string",
      "required": true,
      "width": 0,
      "width_units": "%",
      "pinned": "left",
      "color": "blue",
      "multiple": true,
      "format": "yfm",
      "ticket_field": "assignee",
      "select_options": [
        "example"
      ],
      "mark_rows": true,
      "description": "example"
    }
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *columns* | **Type**: [NewColumnSchema](en/api-ref/grids/grids__add_columns#entity-NewColumnSchema)[] **Example** ``` [   {     "id": "example",     "slug": "example",     "title": "example",     "type": "string",     "required": true,     "width": 0,     "width_units": "%",     "pinned": "left",     "color": "blue",     "multiple": true,     "format": "yfm",     "ticket_field": "assignee",     "select_options": [       "example"     ],     "mark_rows": true,     "description": "example"   } ] ``` |
| *position* | **Type**: integer |
| *revision* | **Type**: string  *Example:* `example` |

### ColumnType

An enumeration.

**Type**: string

*Enum:* `string`, `number`, `date`, `select`, `staff`, `checkbox`, `ticket`, `ticket_field`

### WidthUnits

An enumeration.

**Type**: string

*Enum:* `%`, `px`

### ColumnPinTypes

An enumeration.

**Type**: string

*Enum:* `left`, `right`

### BGColor

An enumeration.

**Type**: string

*Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`

### TextFormat

Text format:

- `yfm` — Yandex Flavored Markdown
- `wom` — Wiki Old Markup (the old markup)
- `plain` — plain text

**Type**: string

*Enum:* `yfm`, `wom`, `plain`

### TicketField

An enumeration.

**Type**: string

*Enum:* `assignee`, `components`, `created_at`, `deadline`, `description`, `end`, `estimation`, `fixversions`, `followers`, `last_comment_updated_at`, `original_estimation`, `parent`, `pending_reply_from`, `priority`, `project`, `queue`, `reporter`, `resolution`, `resolved_at`, `sprint`, `start`, `status`, `status_start_time`, `status_type`, `storypoints`, `subject`, `tags`, `type`, `updated_at`, `votes`

### NewColumnSchema

Schema for creating a new column in a dynamic table

|  |  |
| --- | --- |
| **Name** | **Description** |
| *required* | **Type**: boolean  Whether the column is required |
| *slug* | **Type**: string  Unique text identifier of the column (used in formulas and the API)  *Example:* `example` |
| *title* | **Type**: string  Column title (displayed in the interface)  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |
| *type* | **All of 1 type** - **ColumnType**  **Type**: [ColumnType](en/api-ref/grids/grids__add_columns#entity-ColumnType)  An enumeration.  *Enum:* `string`, `number`, `date`, `select`, `staff`, `checkbox`, `ticket`, `ticket_field`  Column data type  *Example:* `string` |
| *color* | **All of 1 type** - **BGColor**  **Type**: [BGColor](en/api-ref/grids/grids__add_columns#entity-BGColor)  An enumeration.  *Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`  Column background color  *Example:* `blue` |
| *description* | **Type**: string  Column description  *Max length:* `1024`  *Example:* `example` |
| *format* | **All of 1 type** - **TextFormat**  **Type**: [TextFormat](en/api-ref/grids/grids__add_columns#entity-TextFormat)  Text format:    - `yfm` — Yandex Flavored Markdown   - `wom` — Wiki Old Markup (the old markup)   - `plain` — plain text *Enum:* `yfm`, `wom`, `plain`  For `text` only; text format (None means plain text without formatting)  *Example:* `yfm` |
| *id* | **Type**: string  Unique column identifier  *Example:* `example` |
| *mark\_rows* | **Type**: boolean  For `checkbox` only; marks the row as completed in the interface |
| *multiple* | **Type**: boolean  For `select` and `staff` only; enables multiple selection |
| *pinned* | **All of 1 type** - **ColumnPinTypes**  **Type**: [ColumnPinTypes](en/api-ref/grids/grids__add_columns#entity-ColumnPinTypes)  An enumeration.  *Enum:* `left`, `right`  Column pinning (left, right, or unpinned)  *Example:* `left` |
| *select\_options* | **Type**: string[]  For `select` only; defines the available options **Example** ``` [   "example" ] ``` |
| *ticket\_field* | **All of 1 type** - **TicketField**  **Type**: [TicketField](en/api-ref/grids/grids__add_columns#entity-TicketField)  An enumeration.  *Enum:* `assignee`, `components`, `created_at`, `deadline`, `description`, `end`, `estimation`, `fixversions`, `followers`, `last_comment_updated_at`, `original_estimation`, `parent`, `pending_reply_from`, `priority`, `project`, `queue`, `reporter`, `resolution`, `resolved_at`, `sprint`, `start`, `status`, `status_start_time`, `status_type`, `storypoints`, `subject`, `tags`, `type`, `updated_at`, `votes`  For `ticket-field` only; the ticket field from Tracker  *Example:* `assignee` |
| *width* | **Type**: integer  Column width |
| *width\_units* | **All of 1 type** - **WidthUnits**  **Type**: [WidthUnits](en/api-ref/grids/grids__add_columns#entity-WidthUnits)  An enumeration.  *Enum:* `%`, `px`  Column width units  *Example:* `%` |

**Example**

```
{
  "id": "example",
  "slug": "example",
  "title": "example",
  "type": "string",
  "required": true,
  "width": 0,
  "width_units": "%",
  "pinned": "left",
  "color": "blue",
  "multiple": true,
  "format": "yfm",
  "ticket_field": "assignee",
  "select_options": [
    "example"
  ],
  "mark_rows": true,
  "description": "example"
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__clone_grid -->

- [Request](en/api-ref/grids/grids__clone_grid#request)
  - [Path parameters](en/api-ref/grids/grids__clone_grid#path-parameters)
  - [Body](en/api-ref/grids/grids__clone_grid#body)
- [Responses](en/api-ref/grids/grids__clone_grid#responses)
- [200 OK](en/api-ref/grids/grids__clone_grid#200-ok)
  - [Body](en/api-ref/grids/grids__clone_grid#body1)
  - [B2BOperationType](en/api-ref/grids/grids__clone_grid#entity-B2BOperationType)
  - [B2BOperationIdentity](en/api-ref/grids/grids__clone_grid#entity-B2BOperationIdentity)

# Clone Grid

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}/clone
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "target": "example",
  "title": "example",
  "with_data": false
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *target* | **Type**: string  The slug of the page to copy the table to. If the page does not exist, it will be created.  *Example:* `example` |
| *title* | **Type**: string  If provided, the title after cloning  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |
| *with\_data* | **Type**: boolean  *Default:* `false` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "operation": {
    "type": "clone",
    "id": "example"
  },
  "dry_run": false,
  "status_url": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *operation* | **Type**: [B2BOperationIdentity](en/api-ref/grids/grids__clone_grid#entity-B2BOperationIdentity) **Example** ``` {   "type": "clone",   "id": "example" } ``` |
| *status\_url* | **Type**: string  The URL where the operation progress is returned  *Example:* `example` |
| *dry\_run* | **Type**: boolean  *Default:* `false` |

### B2BOperationType

An enumeration.

**Type**: string

*Enum:* `clone`, `clone_inline_grid`

### B2BOperationIdentity

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  *Example:* `example` |
| *type* | **Type**: [B2BOperationType](en/api-ref/grids/grids__clone_grid#entity-B2BOperationType)  An enumeration.  *Enum:* `clone`, `clone_inline_grid` |

**Example**

```
{
  "type": "clone",
  "id": "example"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__remove_columns -->

- [Request](en/api-ref/grids/grids__remove_columns#request)
  - [Path parameters](en/api-ref/grids/grids__remove_columns#path-parameters)
  - [Body](en/api-ref/grids/grids__remove_columns#body)
- [Responses](en/api-ref/grids/grids__remove_columns#responses)
- [200 OK](en/api-ref/grids/grids__remove_columns#200-ok)
  - [Body](en/api-ref/grids/grids__remove_columns#body1)

# Remove Columns

## Request

DELETE

```
https://api.wiki.yandex.net/v1/grids/{idx}/columns
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "column_slugs": [
    "example"
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *column\_slugs* | **Type**: string[] **Example** ``` [   "example" ] ``` |
| *revision* | **Type**: string  *Example:* `example` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/operations/operations__get_clone_inline_grid_operation_status -->

- [Request](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#request)
  - [Path parameters](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#path-parameters)
- [Responses](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#responses)
- [200 OK](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#200-ok)
  - [Body](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#body)
  - [Status](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-Status)
  - [Progress](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-Progress)
  - [PageSchema](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-PageSchema)
  - [GridCloneResponse](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-GridCloneResponse)

# Get Clone Inline Grid Operation Status

## Request

GET

```
https://api.wiki.yandex.net/v1/operations/clone_inline_grid/{task_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *task\_id* | **Type**: string  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "status": "scheduled",
  "progress": {
    "percentage": 0.5,
    "details": "example"
  },
  "result": {
    "grid": {
      "id": 0,
      "slug": "example"
    },
    "page": null,
    "grid_id": "example"
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **Type**: [Status](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-Status)  An enumeration.  *Enum:* `scheduled`, `in_progress`, `success`, `failed` |
| *progress* | **Type**: [Progress](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-Progress) **Example** ``` {   "percentage": 0.5,   "details": "example" } ``` |
| *result* | **Type**: [GridCloneResponse](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-GridCloneResponse) **Example** ``` {   "grid": {     "id": 0,     "slug": "example"   },   "page": null,   "grid_id": "example" } ``` |

### Status

An enumeration.

**Type**: string

*Enum:* `scheduled`, `in_progress`, `success`, `failed`

### Progress

|  |  |
| --- | --- |
| **Name** | **Description** |
| *details* | **Type**: string  *Example:* `example` |
| *percentage* | **Type**: number |

**Example**

```
{
  "percentage": 0.5,
  "details": "example"
}
```

### PageSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer |
| *slug* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```

### GridCloneResponse

|  |  |
| --- | --- |
| **Name** | **Description** |
| *grid\_id* | **Any of 2 types** - **Type**: string<uuid4>  *Example:* `example` - **Type**: integer  *Example:* `example` |
| *page* | **All of 1 type** - **PageSchema**  **Type**: [PageSchema](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-PageSchema) **Example** ```   {     "id": 0,     "slug": "example"   }   ```  The page to which the dynamic table was copied **Example** ``` {   "id": 0,   "slug": "example" } ``` |
| *grid* | **All of 1 type** - **PageSchema**  **Type**: [PageSchema](en/api-ref/operations/operations__get_clone_inline_grid_operation_status#entity-PageSchema) **Example** ```   {     "id": 0,     "slug": "example"   }   ```  During the transition period, the page schema for the legacy table type **Example** ``` {   "id": 0,   "slug": "example" } ``` |

**Example**

```
{
  "grid": {
    "id": 0,
    "slug": "example"
  },
  "page": null,
  "grid_id": "example"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__move_rows -->

- [Request](en/api-ref/grids/grids__move_rows#request)
  - [Path parameters](en/api-ref/grids/grids__move_rows#path-parameters)
  - [Body](en/api-ref/grids/grids__move_rows#body)
- [Responses](en/api-ref/grids/grids__move_rows#responses)
- [200 OK](en/api-ref/grids/grids__move_rows#200-ok)
  - [Body](en/api-ref/grids/grids__move_rows#body1)

# Move Rows

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}/rows/move
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "position": 0,
  "after_row_id": "example",
  "row_id": "example",
  "rows_count": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *row\_id* | **Type**: string  *Example:* `example` |
| *after\_row\_id* | **Type**: string  *Example:* `example` |
| *position* | **Type**: integer |
| *revision* | **Type**: string  *Example:* `example` |
| *rows\_count* | **Type**: integer  *Exclusive min:* `false` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token -->

- [Request](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token#request)
  - [Path parameters](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token#path-parameters)
- [Responses](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token#responses)
- [200 OK](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token#200-ok)
  - [Body](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token#body)

# Recover Page By Token

Restores a page that was deleted using the [Delete Page](en/api-ref/pages/pages__delete_page) method.

## Request

POST

```
https://api.wiki.yandex.net/v1/recovery_tokens/{idx}/recover
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  The value of the `recovery_token` parameter returned in response to a page deletion request.  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "slug": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer |
| *slug* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/upload_sessions__create_upload_session -->

- [Request](en/api-ref/upload_sessions/upload_sessions__create_upload_session#request)
  - [Body](en/api-ref/upload_sessions/upload_sessions__create_upload_session#body)
- [Responses](en/api-ref/upload_sessions/upload_sessions__create_upload_session#responses)
- [200 OK](en/api-ref/upload_sessions/upload_sessions__create_upload_session#200-ok)
  - [Body](en/api-ref/upload_sessions/upload_sessions__create_upload_session#body1)
  - [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-UploadSessionStatusType)
  - [UserIdentity](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-UserIdentity)
  - [UserSchema](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-UserSchema)
  - [StorageType](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-StorageType)

# Create Upload Session

Creates a session for uploading a file. File upload procedure:

1. Create a file upload session.
2. Upload the file in parts using the [Upload File Part](en/api-ref/upload_sessions/upload_sessions__upload_part) method.
3. Complete the upload session using the [Complete Upload Session](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload) method.

After the upload is complete, you can attach the file to a page: [Add Attachment](en/api-ref/attachments/pagesattachments__attach_file).

## Request

POST

```
https://api.wiki.yandex.net/v1/upload_sessions
```

### Body

application/json

```
{
  "file_name": "example",
  "file_size": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *file\_name* | **Type**: string  *Example:* `example` |
| *file\_size* | **Type**: integer |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "session_id": "example",
  "file_name": "example",
  "file_size": 0,
  "status": "not_started",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "finished_at": "2025-01-01T00:00:00Z",
  "storage_type": "mds"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *file\_name* | **Type**: string  *Example:* `example` |
| *file\_size* | **Type**: integer |
| *session\_id* | **Type**: string<uuid4>  *Example:* `example` |
| *status* | **Type**: [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-UploadSessionStatusType)  An enumeration.  *Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup` |
| *user* | **Type**: [UserSchema](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *finished\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *storage\_type* | **Type**: [StorageType](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-StorageType)  An enumeration.  *Enum:* `mds`, `s3`, `custom_s3` |

### UploadSessionStatusType

An enumeration.

**Type**: string

*Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup`

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/upload_sessions/upload_sessions__create_upload_session#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### StorageType

An enumeration.

**Type**: string

*Enum:* `mds`, `s3`, `custom_s3`


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload -->

- [Request](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#request)
  - [Path parameters](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#path-parameters)
- [Responses](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#responses)
- [200 OK](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#200-ok)
  - [Body](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#body)
  - [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-UploadSessionStatusType)
  - [UserIdentity](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-UserIdentity)
  - [UserSchema](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-UserSchema)
  - [StorageType](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-StorageType)

# Complete Multipart Upload

Completes the file upload session. [How to create a file upload session](en/api-ref/upload_sessions/upload_sessions__create_upload_session)

## Request

POST

```
https://api.wiki.yandex.net/v1/upload_sessions/{session_id}/finish
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *session\_id* | **Type**: string<uuid4>  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "session_id": "example",
  "file_name": "example",
  "file_size": 0,
  "status": "not_started",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "finished_at": "2025-01-01T00:00:00Z",
  "storage_type": "mds"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *file\_name* | **Type**: string  *Example:* `example` |
| *file\_size* | **Type**: integer |
| *session\_id* | **Type**: string<uuid4>  *Example:* `example` |
| *status* | **Type**: [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-UploadSessionStatusType)  An enumeration.  *Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup` |
| *user* | **Type**: [UserSchema](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *finished\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *storage\_type* | **Type**: [StorageType](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-StorageType)  An enumeration.  *Enum:* `mds`, `s3`, `custom_s3` |

### UploadSessionStatusType

An enumeration.

**Type**: string

*Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup`

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### StorageType

An enumeration.

**Type**: string

*Enum:* `mds`, `s3`, `custom_s3`


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__update_grid -->

- [Request](en/api-ref/grids/grids__update_grid#request)
  - [Path parameters](en/api-ref/grids/grids__update_grid#path-parameters)
  - [Body](en/api-ref/grids/grids__update_grid#body)
  - [SortDirection](en/api-ref/grids/grids__update_grid#entity-SortDirection)
- [Responses](en/api-ref/grids/grids__update_grid#responses)
- [200 OK](en/api-ref/grids/grids__update_grid#200-ok)
  - [Body](en/api-ref/grids/grids__update_grid#body1)

# Update Grid

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "title": "example",
  "default_sort": [
    {}
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *default\_sort* | **Type**: object[] |  |  | | --- | --- | | *[additional]* | **Type**: [SortDirection](en/api-ref/grids/grids__update_grid#entity-SortDirection)  Sort direction:   - `asc` — ascending (from smallest to largest, from A to Z) - `desc` — descending (from largest to smallest, from Z to A)   *Enum:* `asc`, `desc` | **Example** ``` [   {} ] ``` |
| *revision* | **Type**: string  *Example:* `example` |
| *title* | **Type**: string  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |

### SortDirection

Sort direction:

- `asc` — ascending (from smallest to largest, from A to Z)
- `desc` — descending (from largest to smallest, from Z to A)

**Type**: string

*Enum:* `asc`, `desc`

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload -->

- [Request](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#request)
  - [Path parameters](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#path-parameters)
- [Responses](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#responses)
- [200 OK](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#200-ok)
  - [Body](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#body)
  - [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-UploadSessionStatusType)
  - [UserIdentity](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-UserIdentity)
  - [UserSchema](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-UserSchema)
  - [StorageType](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-StorageType)

# Abort Multipart Upload

Cancels the file upload. [How to create a file upload session](en/api-ref/upload_sessions/upload_sessions__create_upload_session)

## Request

POST

```
https://api.wiki.yandex.net/v1/upload_sessions/{session_id}/abort
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *session\_id* | **Type**: string<uuid4>  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "session_id": "example",
  "file_name": "example",
  "file_size": 0,
  "status": "not_started",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "finished_at": "2025-01-01T00:00:00Z",
  "storage_type": "mds"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *file\_name* | **Type**: string  *Example:* `example` |
| *file\_size* | **Type**: integer |
| *session\_id* | **Type**: string<uuid4>  *Example:* `example` |
| *status* | **Type**: [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-UploadSessionStatusType)  An enumeration.  *Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup` |
| *user* | **Type**: [UserSchema](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *finished\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *storage\_type* | **Type**: [StorageType](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-StorageType)  An enumeration.  *Enum:* `mds`, `s3`, `custom_s3` |

### UploadSessionStatusType

An enumeration.

**Type**: string

*Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup`

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### StorageType

An enumeration.

**Type**: string

*Enum:* `mds`, `s3`, `custom_s3`


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/comments/pagescomments__thread_comments -->

- [Request](en/api-ref/comments/pagescomments__thread_comments#request)
  - [Path parameters](en/api-ref/comments/pagescomments__thread_comments#path-parameters)
  - [Query parameters](en/api-ref/comments/pagescomments__thread_comments#query-parameters)
- [Responses](en/api-ref/comments/pagescomments__thread_comments#responses)
- [200 OK](en/api-ref/comments/pagescomments__thread_comments#200-ok)
  - [Body](en/api-ref/comments/pagescomments__thread_comments#body)
  - [UserIdentity](en/api-ref/comments/pagescomments__thread_comments#entity-UserIdentity)
  - [UserSchema](en/api-ref/comments/pagescomments__thread_comments#entity-UserSchema)
  - [CommentResolveStatus](en/api-ref/comments/pagescomments__thread_comments#entity-CommentResolveStatus)
  - [ReactionType](en/api-ref/comments/pagescomments__thread_comments#entity-ReactionType)
  - [CommentReactionSchema](en/api-ref/comments/pagescomments__thread_comments#entity-CommentReactionSchema)
  - [CommentSchema](en/api-ref/comments/pagescomments__thread_comments#entity-CommentSchema)

# Thread Comments

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/comments/{comment_id}/thread
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comment\_id* | **Type**: integer |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cursor* | **Type**: string  *Example:* `` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": 0,
      "body": "example",
      "inline_text": "example",
      "parent_id": 0,
      "author": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "thread_id": 0,
      "created_at": "2025-01-01T00:00:00Z",
      "is_deleted": true,
      "resolve_status": "resolved",
      "reactions": [
        {
          "type": "like",
          "author": null,
          "created_at": "2025-01-01T00:00:00Z"
        }
      ]
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example",
  "page_id": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_id* | **Type**: integer  For backward compatibility: always equals 1 when a cursor is set |
| *results* | **Type**: [CommentSchema](en/api-ref/comments/pagescomments__thread_comments#entity-CommentSchema)[] **Example** ``` [   {     "id": 0,     "body": "example",     "inline_text": "example",     "parent_id": 0,     "author": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "thread_id": 0,     "created_at": "2025-01-01T00:00:00Z",     "is_deleted": true,     "resolve_status": "resolved",     "reactions": [       {         "type": "like",         "author": null,         "created_at": "2025-01-01T00:00:00Z"       }     ]   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/comments/pagescomments__thread_comments#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### CommentResolveStatus

Comment resolve status:

- `resolved` — the comment is resolved
- `unresolved` — the comment is not resolved

**Type**: string

*Enum:* `resolved`, `unresolved`

### ReactionType

Comment reaction type:

- `like` — like
- `hooray` — hooray
- `confused` — confused
- `heart` — heart
- `rocket` — rocket
- `eyes` — eyes
- `fire` — fire
- `ok` — ok
- `facepalm` — facepalm
- `check` — check mark
- `laugh` — laugh
- `dislike` — dislike

**Type**: string

*Enum:* `like`, `hooray`, `confused`, `heart`, `rocket`, `eyes`, `fire`, `ok`, `facepalm`, `check`, `laugh`, `dislike`

### CommentReactionSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **Type**: [UserSchema](en/api-ref/comments/pagescomments__thread_comments#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *type* | **Type**: [ReactionType](en/api-ref/comments/pagescomments__thread_comments#entity-ReactionType)  Comment reaction type:   - `like` — like - `hooray` — hooray - `confused` — confused - `heart` — heart - `rocket` — rocket - `eyes` — eyes - `fire` — fire - `ok` — ok - `facepalm` — facepalm - `check` — check mark - `laugh` — laugh - `dislike` — dislike   *Enum:* `like`, `hooray`, `confused`, `heart`, `rocket`, `eyes`, `fire`, `ok`, `facepalm`, `check`, `laugh`, `dislike` |

**Example**

```
{
  "type": "like",
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z"
}
```

### CommentSchema

A comment on the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/comments/pagescomments__thread_comments#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  Comment author **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *body* | **Type**: string  Comment text  *Example:* `example` |
| *created\_at* | **Type**: string<date-time>  Date and time the comment was created  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Type**: integer  Unique comment identifier |
| *is\_deleted* | **Type**: boolean  Comment deletion flag |
| *reactions* | **Type**: [CommentReactionSchema](en/api-ref/comments/pagescomments__thread_comments#entity-CommentReactionSchema)[]  Reactions to the comment **Example** ``` [   {     "type": "like",     "author": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z"   } ] ``` |
| *resolve\_status* | **All of 1 type** - **CommentResolveStatus**  **Type**: [CommentResolveStatus](en/api-ref/comments/pagescomments__thread_comments#entity-CommentResolveStatus)  Comment resolve status:    - `resolved` — the comment is resolved   - `unresolved` — the comment is not resolved *Enum:* `resolved`, `unresolved`  Comment resolve status  *Example:* `resolved` |
| *inline\_text* | **Type**: string  The text the comment is attached to (for inline comments)  *Example:* `example` |
| *parent\_id* | **Type**: integer  The ID of the parent comment (for replies in a thread) |
| *thread\_id* | **Type**: integer  Comment thread ID |

**Example**

```
{
  "id": 0,
  "body": "example",
  "inline_text": "example",
  "parent_id": 0,
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "thread_id": 0,
  "created_at": "2025-01-01T00:00:00Z",
  "is_deleted": true,
  "resolve_status": "resolved",
  "reactions": [
    {
      "type": "like",
      "author": null,
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__remove_rows -->

- [Request](en/api-ref/grids/grids__remove_rows#request)
  - [Path parameters](en/api-ref/grids/grids__remove_rows#path-parameters)
  - [Body](en/api-ref/grids/grids__remove_rows#body)
- [Responses](en/api-ref/grids/grids__remove_rows#responses)
- [200 OK](en/api-ref/grids/grids__remove_rows#200-ok)
  - [Body](en/api-ref/grids/grids__remove_rows#body1)

# Remove Rows

## Request

DELETE

```
https://api.wiki.yandex.net/v1/grids/{idx}/rows
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "row_ids": [
    "example"
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *row\_ids* | **Type**: string[]  *Min items:* `1` **Example** ``` [   "example" ] ``` |
| *revision* | **Type**: string  *Example:* `example` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__move_columns -->

- [Request](en/api-ref/grids/grids__move_columns#request)
  - [Path parameters](en/api-ref/grids/grids__move_columns#path-parameters)
  - [Body](en/api-ref/grids/grids__move_columns#body)
- [Responses](en/api-ref/grids/grids__move_columns#responses)
- [200 OK](en/api-ref/grids/grids__move_columns#200-ok)
  - [Body](en/api-ref/grids/grids__move_columns#body1)

# Move Columns

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}/columns/move
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "position": 0,
  "column_slug": "example",
  "columns_count": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *column\_slug* | **Type**: string  *Example:* `example` |
| *position* | **Type**: integer |
| *columns\_count* | **Type**: integer  *Exclusive min:* `false` |
| *revision* | **Type**: string  *Example:* `example` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/upload_sessions__get_upload_session -->

- [Request](en/api-ref/upload_sessions/upload_sessions__get_upload_session#request)
  - [Path parameters](en/api-ref/upload_sessions/upload_sessions__get_upload_session#path-parameters)
- [Responses](en/api-ref/upload_sessions/upload_sessions__get_upload_session#responses)
- [200 OK](en/api-ref/upload_sessions/upload_sessions__get_upload_session#200-ok)
  - [Body](en/api-ref/upload_sessions/upload_sessions__get_upload_session#body)
  - [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-UploadSessionStatusType)
  - [UserIdentity](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-UserIdentity)
  - [UserSchema](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-UserSchema)
  - [StorageType](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-StorageType)

# Get Upload Session

Returns active file upload sessions. [How to create a file upload session](en/api-ref/upload_sessions/upload_sessions__create_upload_session)

## Request

GET

```
https://api.wiki.yandex.net/v1/upload_sessions/{session_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *session\_id* | **Type**: string<uuid4>  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "session_id": "example",
  "file_name": "example",
  "file_size": 0,
  "status": "not_started",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "finished_at": "2025-01-01T00:00:00Z",
  "storage_type": "mds"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *file\_name* | **Type**: string  *Example:* `example` |
| *file\_size* | **Type**: integer |
| *session\_id* | **Type**: string<uuid4>  *Example:* `example` |
| *status* | **Type**: [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-UploadSessionStatusType)  An enumeration.  *Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup` |
| *user* | **Type**: [UserSchema](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *finished\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *storage\_type* | **Type**: [StorageType](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-StorageType)  An enumeration.  *Enum:* `mds`, `s3`, `custom_s3` |

### UploadSessionStatusType

An enumeration.

**Type**: string

*Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup`

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/upload_sessions/upload_sessions__get_upload_session#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### StorageType

An enumeration.

**Type**: string

*Enum:* `mds`, `s3`, `custom_s3`


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__descendants_by_slug -->

- [Request](en/api-ref/pages/pages__descendants_by_slug#request)
  - [Query parameters](en/api-ref/pages/pages__descendants_by_slug#query-parameters)
- [Responses](en/api-ref/pages/pages__descendants_by_slug#responses)
- [200 OK](en/api-ref/pages/pages__descendants_by_slug#200-ok)
  - [Body](en/api-ref/pages/pages__descendants_by_slug#body)
  - [PageSchema](en/api-ref/pages/pages__descendants_by_slug#entity-PageSchema)

# Get Page Descendants by Slug

Returns the list of subpages by page slug.

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/descendants
```

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *slug* | **Type**: string  *Example:* `` |
| *actuality* | **Type**: string  An enumeration.  *Enum:* `actual`, `obsolete` |
| *cursor* | **Type**: string  *Example:* `` |
| *include\_self* | **Type**: boolean  *Default:* `false` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": 0,
      "slug": "example"
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *results* | **Type**: [PageSchema](en/api-ref/pages/pages__descendants_by_slug#entity-PageSchema)[] **Example** ``` [   {     "id": 0,     "slug": "example"   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### PageSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer |
| *slug* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__create_grid -->

- [Request](en/api-ref/grids/grids__create_grid#request)
  - [Body](en/api-ref/grids/grids__create_grid#body)
  - [PageIdentity](en/api-ref/grids/grids__create_grid#entity-PageIdentity)
- [Responses](en/api-ref/grids/grids__create_grid#responses)
- [200 OK](en/api-ref/grids/grids__create_grid#200-ok)
  - [Body](en/api-ref/grids/grids__create_grid#body1)
  - [SortDirection](en/api-ref/grids/grids__create_grid#entity-SortDirection)
  - [ColumnSortSchema](en/api-ref/grids/grids__create_grid#entity-ColumnSortSchema)
  - [ColumnType](en/api-ref/grids/grids__create_grid#entity-ColumnType)
  - [WidthUnits](en/api-ref/grids/grids__create_grid#entity-WidthUnits)
  - [ColumnPinTypes](en/api-ref/grids/grids__create_grid#entity-ColumnPinTypes)
  - [BGColor](en/api-ref/grids/grids__create_grid#entity-BGColor)
  - [TextFormat](en/api-ref/grids/grids__create_grid#entity-TextFormat)
  - [TicketField](en/api-ref/grids/grids__create_grid#entity-TicketField)
  - [ColumnSchema](en/api-ref/grids/grids__create_grid#entity-ColumnSchema)
  - [GridStructureSchema](en/api-ref/grids/grids__create_grid#entity-GridStructureSchema)
  - [TicketSchema](en/api-ref/grids/grids__create_grid#entity-TicketSchema)
  - [UserIdentity](en/api-ref/grids/grids__create_grid#entity-UserIdentity)
  - [UserSchema](en/api-ref/grids/grids__create_grid#entity-UserSchema)
  - [UnresolvedUserSchema](en/api-ref/grids/grids__create_grid#entity-UnresolvedUserSchema)
  - [TrackerEnumField](en/api-ref/grids/grids__create_grid#entity-TrackerEnumField)
  - [GridRowSchema](en/api-ref/grids/grids__create_grid#entity-GridRowSchema)
  - [UserPermission](en/api-ref/grids/grids__create_grid#entity-UserPermission)
  - [GridAttributesSchema](en/api-ref/grids/grids__create_grid#entity-GridAttributesSchema)

# Create Grid

Create a new dynamic table as a page resource.

## Request

POST

```
https://api.wiki.yandex.net/v1/grids
```

### Body

application/json

```
{
  "title": "example",
  "page": {
    "id": 0,
    "slug": "example"
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page* | **Type**: [PageIdentity](en/api-ref/grids/grids__create_grid#entity-PageIdentity)  Page identifier **Example** ``` {   "id": 0,   "slug": "example" } ``` |
| *title* | **Type**: string  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |

### PageIdentity

Page identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID. Either `id` or `slug` is required. If both are provided, `id` takes priority and `slug` is ignored |
| *slug* | **Type**: string  Page address (slug). Either `id` or `slug` is required  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "title": "example",
  "page": {
    "id": 0,
    "slug": "example"
  },
  "structure": {
    "default_sort": [
      {
        "slug": "example",
        "title": "example",
        "direction": null
      }
    ],
    "columns": [
      {
        "id": "example",
        "slug": "example",
        "title": "example",
        "type": null,
        "required": true,
        "width": 0,
        "width_units": null,
        "pinned": null,
        "color": null,
        "multiple": true,
        "format": null,
        "ticket_field": null,
        "select_options": [
          null
        ],
        "mark_rows": true,
        "description": "example"
      }
    ]
  },
  "rich_text_format": "yfm",
  "rows": [
    {
      "id": "example",
      "row": [
        0
      ],
      "pinned": true,
      "color": "blue"
    }
  ],
  "revision": "example",
  "user_permissions": [
    "create_page"
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z"
  },
  "template_id": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the table was created  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Any of 2 types** - **Type**: string<uuid4>  *Example:* `example` - **Type**: integer  Unique table identifier  *Example:* `example` |
| *page* | **All of 1 type** - **PageIdentity**  **Type**: [PageIdentity](en/api-ref/grids/grids__create_grid#entity-PageIdentity)  Page identifier **Example** ```   {     "id": 0,     "slug": "example"   }   ```  The page the table is attached to **Example** ``` {   "id": 0,   "slug": "example" } ``` |
| *revision* | **Type**: string  Table revision  *Example:* `example` |
| *rich\_text\_format* | **All of 1 type** - **TextFormat**  **Type**: [TextFormat](en/api-ref/grids/grids__create_grid#entity-TextFormat)  Text format:    - `yfm` — Yandex Flavored Markdown   - `wom` — Wiki Old Markup (the old markup)   - `plain` — plain text *Enum:* `yfm`, `wom`, `plain`  The rich-text content format in the table  *Example:* `yfm` |
| *rows* | **Type**: [GridRowSchema](en/api-ref/grids/grids__create_grid#entity-GridRowSchema)[]  Table rows **Example** ``` [   {     "id": "example",     "row": [       0     ],     "pinned": true,     "color": "blue"   } ] ``` |
| *structure* | **All of 1 type** - **GridStructureSchema**  **Type**: [GridStructureSchema](en/api-ref/grids/grids__create_grid#entity-GridStructureSchema)  Dynamic table structure **Example** ```   {     "default_sort": [       {         "slug": "example",         "title": "example",         "direction": "asc"       }     ],     "columns": [       {         "id": "example",         "slug": "example",         "title": "example",         "type": "string",         "required": true,         "width": 0,         "width_units": "%",         "pinned": "left",         "color": "blue",         "multiple": true,         "format": "yfm",         "ticket_field": "assignee",         "select_options": [           "example"         ],         "mark_rows": true,         "description": "example"       }     ]   }   ```  Table structure (columns, data types) **Example** ``` {   "default_sort": [     {       "slug": "example",       "title": "example",       "direction": "asc"     }   ],   "columns": [     {       "id": "example",       "slug": "example",       "title": "example",       "type": "string",       "required": true,       "width": 0,       "width_units": "%",       "pinned": "left",       "color": "blue",       "multiple": true,       "format": "yfm",       "ticket_field": "assignee",       "select_options": [         "example"       ],       "mark_rows": true,       "description": "example"     }   ] } ``` |
| *title* | **Type**: string  Table title  *Example:* `example` |
| *attributes* | **All of 1 type** - **GridAttributesSchema**  **Type**: [GridAttributesSchema](en/api-ref/grids/grids__create_grid#entity-GridAttributesSchema)  Dynamic table attributes (metadata) **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z"   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response.  Returns additional attributes of the dynamic table. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z" } ``` |
| *template\_id* | **Type**: integer |
| *user\_permissions* | **Type**: [UserPermission](en/api-ref/grids/grids__create_grid#entity-UserPermission)[]  **Not returned by default**  Specify `user_permissions` in the `?fields=user_permissions, ...` list to include it in the response.  Returns the access permissions of the page that owns the dynamic table. **Example** ``` [   "create_page" ] ``` |

### SortDirection

Sort direction:

- `asc` — ascending (from smallest to largest, from A to Z)
- `desc` — descending (from largest to smallest, from Z to A)

**Type**: string

*Enum:* `asc`, `desc`

### ColumnSortSchema

Column sorting schema in a dynamic table

|  |  |
| --- | --- |
| **Name** | **Description** |
| *direction* | **All of 1 type** - **SortDirection**  **Type**: [SortDirection](en/api-ref/grids/grids__create_grid#entity-SortDirection)  Sort direction:    - `asc` — ascending (from smallest to largest, from A to Z)   - `desc` — descending (from largest to smallest, from Z to A) *Enum:* `asc`, `desc`  Sort direction  *Example:* `asc` |
| *slug* | **Type**: string  Unique text identifier of the column  *Example:* `example` |
| *title* | **Type**: string  Column title  *Example:* `example` |

**Example**

```
{
  "slug": "example",
  "title": "example",
  "direction": "asc"
}
```

### ColumnType

An enumeration.

**Type**: string

*Enum:* `string`, `number`, `date`, `select`, `staff`, `checkbox`, `ticket`, `ticket_field`

### WidthUnits

An enumeration.

**Type**: string

*Enum:* `%`, `px`

### ColumnPinTypes

An enumeration.

**Type**: string

*Enum:* `left`, `right`

### BGColor

An enumeration.

**Type**: string

*Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`

### TextFormat

Text format:

- `yfm` — Yandex Flavored Markdown
- `wom` — Wiki Old Markup (the old markup)
- `plain` — plain text

**Type**: string

*Enum:* `yfm`, `wom`, `plain`

### TicketField

An enumeration.

**Type**: string

*Enum:* `assignee`, `components`, `created_at`, `deadline`, `description`, `end`, `estimation`, `fixversions`, `followers`, `last_comment_updated_at`, `original_estimation`, `parent`, `pending_reply_from`, `priority`, `project`, `queue`, `reporter`, `resolution`, `resolved_at`, `sprint`, `start`, `status`, `status_start_time`, `status_type`, `storypoints`, `subject`, `tags`, `type`, `updated_at`, `votes`

### ColumnSchema

Dynamic table column schema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *required* | **Type**: boolean  Whether the column is required |
| *slug* | **Type**: string  Unique text identifier of the column (used in formulas and the API)  *Example:* `example` |
| *title* | **Type**: string  Column title (displayed in the interface)  *Example:* `example` |
| *type* | **All of 1 type** - **ColumnType**  **Type**: [ColumnType](en/api-ref/grids/grids__create_grid#entity-ColumnType)  An enumeration.  *Enum:* `string`, `number`, `date`, `select`, `staff`, `checkbox`, `ticket`, `ticket_field`  Column data type  *Example:* `string` |
| *color* | **All of 1 type** - **BGColor**  **Type**: [BGColor](en/api-ref/grids/grids__create_grid#entity-BGColor)  An enumeration.  *Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`  Column background color  *Example:* `blue` |
| *description* | **Type**: string  Column description  *Example:* `example` |
| *format* | **All of 1 type** - **TextFormat**  **Type**: [TextFormat](en/api-ref/grids/grids__create_grid#entity-TextFormat)  Text format:    - `yfm` — Yandex Flavored Markdown   - `wom` — Wiki Old Markup (the old markup)   - `plain` — plain text *Enum:* `yfm`, `wom`, `plain`  For `text` only; text format (None means plain text without formatting)  *Example:* `yfm` |
| *id* | **Type**: string  Unique column identifier  *Example:* `example` |
| *mark\_rows* | **Type**: boolean  For `checkbox` only; marks the row as completed in the interface |
| *multiple* | **Type**: boolean  For `select` and `staff` only; enables multiple selection |
| *pinned* | **All of 1 type** - **ColumnPinTypes**  **Type**: [ColumnPinTypes](en/api-ref/grids/grids__create_grid#entity-ColumnPinTypes)  An enumeration.  *Enum:* `left`, `right`  Column pinning (left, right, or unpinned)  *Example:* `left` |
| *select\_options* | **Type**: string[]  For `select` only; defines the available options **Example** ``` [   "example" ] ``` |
| *ticket\_field* | **All of 1 type** - **TicketField**  **Type**: [TicketField](en/api-ref/grids/grids__create_grid#entity-TicketField)  An enumeration.  *Enum:* `assignee`, `components`, `created_at`, `deadline`, `description`, `end`, `estimation`, `fixversions`, `followers`, `last_comment_updated_at`, `original_estimation`, `parent`, `pending_reply_from`, `priority`, `project`, `queue`, `reporter`, `resolution`, `resolved_at`, `sprint`, `start`, `status`, `status_start_time`, `status_type`, `storypoints`, `subject`, `tags`, `type`, `updated_at`, `votes`  For `ticket-field` only; the ticket field from Tracker  *Example:* `assignee` |
| *width* | **Type**: integer  Column width |
| *width\_units* | **All of 1 type** - **WidthUnits**  **Type**: [WidthUnits](en/api-ref/grids/grids__create_grid#entity-WidthUnits)  An enumeration.  *Enum:* `%`, `px`  Column width units  *Example:* `%` |

**Example**

```
{
  "id": "example",
  "slug": "example",
  "title": "example",
  "type": "string",
  "required": true,
  "width": 0,
  "width_units": "%",
  "pinned": "left",
  "color": "blue",
  "multiple": true,
  "format": "yfm",
  "ticket_field": "assignee",
  "select_options": [
    "example"
  ],
  "mark_rows": true,
  "description": "example"
}
```

### GridStructureSchema

Dynamic table structure

|  |  |
| --- | --- |
| **Name** | **Description** |
| *columns* | **Type**: [ColumnSchema](en/api-ref/grids/grids__create_grid#entity-ColumnSchema)[]  Table columns **Example** ``` [   {     "id": "example",     "slug": "example",     "title": "example",     "type": "string",     "required": true,     "width": 0,     "width_units": "%",     "pinned": "left",     "color": "blue",     "multiple": true,     "format": "yfm",     "ticket_field": "assignee",     "select_options": [       "example"     ],     "mark_rows": true,     "description": "example"   } ] ``` |
| *default\_sort* | **Type**: [ColumnSortSchema](en/api-ref/grids/grids__create_grid#entity-ColumnSortSchema)[]  Default sorting **Example** ``` [   {     "slug": "example",     "title": "example",     "direction": "asc"   } ] ``` |

**Example**

```
{
  "default_sort": [
    {
      "slug": "example",
      "title": "example",
      "direction": "asc"
    }
  ],
  "columns": [
    {
      "id": "example",
      "slug": "example",
      "title": "example",
      "type": "string",
      "required": true,
      "width": 0,
      "width_units": "%",
      "pinned": "left",
      "color": "blue",
      "multiple": true,
      "format": "yfm",
      "ticket_field": "assignee",
      "select_options": [
        "example"
      ],
      "mark_rows": true,
      "description": "example"
    }
  ]
}
```

### TicketSchema

Ticket schema from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *key* | **Type**: string  Ticket key (for example, `WIKI-123`)  *Example:* `example` |
| *resolved* | **Type**: boolean  The ticket is resolved (closed) |

**Example**

```
{
  "key": "example",
  "resolved": true
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__create_grid#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### UnresolvedUserSchema

Schema for a user that was not found in the system

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__create_grid#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |
| *username* | **Type**: string  User login  *Example:* `example` |

**Example**

```
{
  "username": "example",
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  }
}
```

### TrackerEnumField

Enumeration field from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *display* | **Type**: string  Displayed field value  *Example:* `example` |
| *key* | **Type**: string  Field value key  *Example:* `example` |

**Example**

```
{
  "display": "example",
  "key": "example"
}
```

### GridRowSchema

Dynamic table row schema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique row identifier  *Example:* `example` |
| *row* | **Type**: array **Any of 10 types** - **Type**: integer - **Type**: number - **Type**: boolean - **Type**: string  *Example:* `example` - **TicketSchema**  **Type**: [TicketSchema](en/api-ref/grids/grids__create_grid#entity-TicketSchema)  Ticket schema from Yandex Tracker **Example** ```   {     "key": "example",     "resolved": true   }   ``` - **Type**: string[] **Example** ```   [     "example"   ]   ``` - **Type**: array **Any of 2 types** - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__create_grid#entity-UserSchema)  Information about the user **Example** ```     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }     ```   - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__create_grid#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```     {       "username": "example",       "identity": {         "uid": "example",         "cloud_uid": "example"       }     }     ``` **Example** ```   [     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }   ]   ``` - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__create_grid#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ``` - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__create_grid#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```   {     "username": "example",     "identity": {       "uid": "example",       "cloud_uid": "example"     }   }   ``` - **TrackerEnumField**  **Type**: [TrackerEnumField](en/api-ref/grids/grids__create_grid#entity-TrackerEnumField)  Enumeration field from Yandex Tracker **Example** ```   {     "display": "example",     "key": "example"   }   ```  Array of the row's cell values (the order matches the column order) **Example** ``` [   0 ] ``` |
| *color* | **All of 1 type** - **BGColor**  **Type**: [BGColor](en/api-ref/grids/grids__create_grid#entity-BGColor)  An enumeration.  *Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`  Row background color  *Example:* `blue` |
| *pinned* | **Type**: boolean  The row is pinned |

**Example**

```
{
  "id": "example",
  "row": [
    0
  ],
  "pinned": true,
  "color": "blue"
}
```

### UserPermission

User access permissions for the page:

- `create_page` — create subpages
- `delete` — delete the page
- `edit` — edit the page
- `view` — view the page
- `comment` — comment
- `change_authors` — change authors
- `change_acl` — change the access list
- `set_redirect` — set a redirect
- `manage_invite` — manage invitations
- `view_invite` — view invitations
- `admin` — administrative permissions

**Type**: string

*Enum:* `create_page`, `delete`, `edit`, `view`, `comment`, `change_authors`, `change_acl`, `set_redirect`, `manage_invite`, `view_invite`, `admin`

### GridAttributesSchema

Dynamic table attributes (metadata)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the table was created  *Example:* `2025-01-01T00:00:00Z` |
| *modified\_at* | **Type**: string<date-time>  Date and time the table was last modified  *Example:* `2025-01-01T00:00:00Z` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__get_grid -->

- [Request](en/api-ref/grids/grids__get_grid#request)
  - [Path parameters](en/api-ref/grids/grids__get_grid#path-parameters)
  - [Query parameters](en/api-ref/grids/grids__get_grid#query-parameters)
- [Responses](en/api-ref/grids/grids__get_grid#responses)
- [200 OK](en/api-ref/grids/grids__get_grid#200-ok)
  - [Body](en/api-ref/grids/grids__get_grid#body)
  - [PageIdentity](en/api-ref/grids/grids__get_grid#entity-PageIdentity)
  - [SortDirection](en/api-ref/grids/grids__get_grid#entity-SortDirection)
  - [ColumnSortSchema](en/api-ref/grids/grids__get_grid#entity-ColumnSortSchema)
  - [ColumnType](en/api-ref/grids/grids__get_grid#entity-ColumnType)
  - [WidthUnits](en/api-ref/grids/grids__get_grid#entity-WidthUnits)
  - [ColumnPinTypes](en/api-ref/grids/grids__get_grid#entity-ColumnPinTypes)
  - [BGColor](en/api-ref/grids/grids__get_grid#entity-BGColor)
  - [TextFormat](en/api-ref/grids/grids__get_grid#entity-TextFormat)
  - [TicketField](en/api-ref/grids/grids__get_grid#entity-TicketField)
  - [ColumnSchema](en/api-ref/grids/grids__get_grid#entity-ColumnSchema)
  - [GridStructureSchema](en/api-ref/grids/grids__get_grid#entity-GridStructureSchema)
  - [TicketSchema](en/api-ref/grids/grids__get_grid#entity-TicketSchema)
  - [UserIdentity](en/api-ref/grids/grids__get_grid#entity-UserIdentity)
  - [UserSchema](en/api-ref/grids/grids__get_grid#entity-UserSchema)
  - [UnresolvedUserSchema](en/api-ref/grids/grids__get_grid#entity-UnresolvedUserSchema)
  - [TrackerEnumField](en/api-ref/grids/grids__get_grid#entity-TrackerEnumField)
  - [GridRowSchema](en/api-ref/grids/grids__get_grid#entity-GridRowSchema)
  - [UserPermission](en/api-ref/grids/grids__get_grid#entity-UserPermission)
  - [GridAttributesSchema](en/api-ref/grids/grids__get_grid#entity-GridAttributesSchema)

# Get Grid

## Request

GET

```
https://api.wiki.yandex.net/v1/grids/{idx}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *fields* | **Type**: string  Additional fields, comma-separated; see the response format description.  *Example:* `` |
| *filter* | **Type**: string  Filter rows; for example `[slug] ~ wiki AND [slug2]<32`  *Example:* `` |
| *only\_cols* | **Type**: string  Return only specific columns. Comma-separated slugs  *Example:* `` |
| *only\_rows* | **Type**: string  Return only specific rows. Comma-separated IDs  *Example:* `` |
| *revision* | **Type**: integer  Load an older version of the dynamic table |
| *sort* | **Type**: string  Sort rows by columns; for example `slug, -slug2, slug3`  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "title": "example",
  "page": {
    "id": 0,
    "slug": "example"
  },
  "structure": {
    "default_sort": [
      {
        "slug": "example",
        "title": "example",
        "direction": null
      }
    ],
    "columns": [
      {
        "id": "example",
        "slug": "example",
        "title": "example",
        "type": null,
        "required": true,
        "width": 0,
        "width_units": null,
        "pinned": null,
        "color": null,
        "multiple": true,
        "format": null,
        "ticket_field": null,
        "select_options": [
          null
        ],
        "mark_rows": true,
        "description": "example"
      }
    ]
  },
  "rich_text_format": "yfm",
  "rows": [
    {
      "id": "example",
      "row": [
        0
      ],
      "pinned": true,
      "color": "blue"
    }
  ],
  "revision": "example",
  "user_permissions": [
    "create_page"
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z"
  },
  "template_id": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the table was created  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Any of 2 types** - **Type**: string<uuid4>  *Example:* `example` - **Type**: integer  Unique table identifier  *Example:* `example` |
| *page* | **All of 1 type** - **PageIdentity**  **Type**: [PageIdentity](en/api-ref/grids/grids__get_grid#entity-PageIdentity)  Page identifier **Example** ```   {     "id": 0,     "slug": "example"   }   ```  The page the table is attached to **Example** ``` {   "id": 0,   "slug": "example" } ``` |
| *revision* | **Type**: string  Table revision  *Example:* `example` |
| *rich\_text\_format* | **All of 1 type** - **TextFormat**  **Type**: [TextFormat](en/api-ref/grids/grids__get_grid#entity-TextFormat)  Text format:    - `yfm` — Yandex Flavored Markdown   - `wom` — Wiki Old Markup (the old markup)   - `plain` — plain text *Enum:* `yfm`, `wom`, `plain`  The rich-text content format in the table  *Example:* `yfm` |
| *rows* | **Type**: [GridRowSchema](en/api-ref/grids/grids__get_grid#entity-GridRowSchema)[]  Table rows **Example** ``` [   {     "id": "example",     "row": [       0     ],     "pinned": true,     "color": "blue"   } ] ``` |
| *structure* | **All of 1 type** - **GridStructureSchema**  **Type**: [GridStructureSchema](en/api-ref/grids/grids__get_grid#entity-GridStructureSchema)  Dynamic table structure **Example** ```   {     "default_sort": [       {         "slug": "example",         "title": "example",         "direction": "asc"       }     ],     "columns": [       {         "id": "example",         "slug": "example",         "title": "example",         "type": "string",         "required": true,         "width": 0,         "width_units": "%",         "pinned": "left",         "color": "blue",         "multiple": true,         "format": "yfm",         "ticket_field": "assignee",         "select_options": [           "example"         ],         "mark_rows": true,         "description": "example"       }     ]   }   ```  Table structure (columns, data types) **Example** ``` {   "default_sort": [     {       "slug": "example",       "title": "example",       "direction": "asc"     }   ],   "columns": [     {       "id": "example",       "slug": "example",       "title": "example",       "type": "string",       "required": true,       "width": 0,       "width_units": "%",       "pinned": "left",       "color": "blue",       "multiple": true,       "format": "yfm",       "ticket_field": "assignee",       "select_options": [         "example"       ],       "mark_rows": true,       "description": "example"     }   ] } ``` |
| *title* | **Type**: string  Table title  *Example:* `example` |
| *attributes* | **All of 1 type** - **GridAttributesSchema**  **Type**: [GridAttributesSchema](en/api-ref/grids/grids__get_grid#entity-GridAttributesSchema)  Dynamic table attributes (metadata) **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z"   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response.  Returns additional attributes of the dynamic table. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z" } ``` |
| *template\_id* | **Type**: integer |
| *user\_permissions* | **Type**: [UserPermission](en/api-ref/grids/grids__get_grid#entity-UserPermission)[]  **Not returned by default**  Specify `user_permissions` in the `?fields=user_permissions, ...` list to include it in the response.  Returns the access permissions of the page that owns the dynamic table. **Example** ``` [   "create_page" ] ``` |

### PageIdentity

Page identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID. Either `id` or `slug` is required. If both are provided, `id` takes priority and `slug` is ignored |
| *slug* | **Type**: string  Page address (slug). Either `id` or `slug` is required  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```

### SortDirection

Sort direction:

- `asc` — ascending (from smallest to largest, from A to Z)
- `desc` — descending (from largest to smallest, from Z to A)

**Type**: string

*Enum:* `asc`, `desc`

### ColumnSortSchema

Column sorting schema in a dynamic table

|  |  |
| --- | --- |
| **Name** | **Description** |
| *direction* | **All of 1 type** - **SortDirection**  **Type**: [SortDirection](en/api-ref/grids/grids__get_grid#entity-SortDirection)  Sort direction:    - `asc` — ascending (from smallest to largest, from A to Z)   - `desc` — descending (from largest to smallest, from Z to A) *Enum:* `asc`, `desc`  Sort direction  *Example:* `asc` |
| *slug* | **Type**: string  Unique text identifier of the column  *Example:* `example` |
| *title* | **Type**: string  Column title  *Example:* `example` |

**Example**

```
{
  "slug": "example",
  "title": "example",
  "direction": "asc"
}
```

### ColumnType

An enumeration.

**Type**: string

*Enum:* `string`, `number`, `date`, `select`, `staff`, `checkbox`, `ticket`, `ticket_field`

### WidthUnits

An enumeration.

**Type**: string

*Enum:* `%`, `px`

### ColumnPinTypes

An enumeration.

**Type**: string

*Enum:* `left`, `right`

### BGColor

An enumeration.

**Type**: string

*Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`

### TextFormat

Text format:

- `yfm` — Yandex Flavored Markdown
- `wom` — Wiki Old Markup (the old markup)
- `plain` — plain text

**Type**: string

*Enum:* `yfm`, `wom`, `plain`

### TicketField

An enumeration.

**Type**: string

*Enum:* `assignee`, `components`, `created_at`, `deadline`, `description`, `end`, `estimation`, `fixversions`, `followers`, `last_comment_updated_at`, `original_estimation`, `parent`, `pending_reply_from`, `priority`, `project`, `queue`, `reporter`, `resolution`, `resolved_at`, `sprint`, `start`, `status`, `status_start_time`, `status_type`, `storypoints`, `subject`, `tags`, `type`, `updated_at`, `votes`

### ColumnSchema

Dynamic table column schema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *required* | **Type**: boolean  Whether the column is required |
| *slug* | **Type**: string  Unique text identifier of the column (used in formulas and the API)  *Example:* `example` |
| *title* | **Type**: string  Column title (displayed in the interface)  *Example:* `example` |
| *type* | **All of 1 type** - **ColumnType**  **Type**: [ColumnType](en/api-ref/grids/grids__get_grid#entity-ColumnType)  An enumeration.  *Enum:* `string`, `number`, `date`, `select`, `staff`, `checkbox`, `ticket`, `ticket_field`  Column data type  *Example:* `string` |
| *color* | **All of 1 type** - **BGColor**  **Type**: [BGColor](en/api-ref/grids/grids__get_grid#entity-BGColor)  An enumeration.  *Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`  Column background color  *Example:* `blue` |
| *description* | **Type**: string  Column description  *Example:* `example` |
| *format* | **All of 1 type** - **TextFormat**  **Type**: [TextFormat](en/api-ref/grids/grids__get_grid#entity-TextFormat)  Text format:    - `yfm` — Yandex Flavored Markdown   - `wom` — Wiki Old Markup (the old markup)   - `plain` — plain text *Enum:* `yfm`, `wom`, `plain`  For `text` only; text format (None means plain text without formatting)  *Example:* `yfm` |
| *id* | **Type**: string  Unique column identifier  *Example:* `example` |
| *mark\_rows* | **Type**: boolean  For `checkbox` only; marks the row as completed in the interface |
| *multiple* | **Type**: boolean  For `select` and `staff` only; enables multiple selection |
| *pinned* | **All of 1 type** - **ColumnPinTypes**  **Type**: [ColumnPinTypes](en/api-ref/grids/grids__get_grid#entity-ColumnPinTypes)  An enumeration.  *Enum:* `left`, `right`  Column pinning (left, right, or unpinned)  *Example:* `left` |
| *select\_options* | **Type**: string[]  For `select` only; defines the available options **Example** ``` [   "example" ] ``` |
| *ticket\_field* | **All of 1 type** - **TicketField**  **Type**: [TicketField](en/api-ref/grids/grids__get_grid#entity-TicketField)  An enumeration.  *Enum:* `assignee`, `components`, `created_at`, `deadline`, `description`, `end`, `estimation`, `fixversions`, `followers`, `last_comment_updated_at`, `original_estimation`, `parent`, `pending_reply_from`, `priority`, `project`, `queue`, `reporter`, `resolution`, `resolved_at`, `sprint`, `start`, `status`, `status_start_time`, `status_type`, `storypoints`, `subject`, `tags`, `type`, `updated_at`, `votes`  For `ticket-field` only; the ticket field from Tracker  *Example:* `assignee` |
| *width* | **Type**: integer  Column width |
| *width\_units* | **All of 1 type** - **WidthUnits**  **Type**: [WidthUnits](en/api-ref/grids/grids__get_grid#entity-WidthUnits)  An enumeration.  *Enum:* `%`, `px`  Column width units  *Example:* `%` |

**Example**

```
{
  "id": "example",
  "slug": "example",
  "title": "example",
  "type": "string",
  "required": true,
  "width": 0,
  "width_units": "%",
  "pinned": "left",
  "color": "blue",
  "multiple": true,
  "format": "yfm",
  "ticket_field": "assignee",
  "select_options": [
    "example"
  ],
  "mark_rows": true,
  "description": "example"
}
```

### GridStructureSchema

Dynamic table structure

|  |  |
| --- | --- |
| **Name** | **Description** |
| *columns* | **Type**: [ColumnSchema](en/api-ref/grids/grids__get_grid#entity-ColumnSchema)[]  Table columns **Example** ``` [   {     "id": "example",     "slug": "example",     "title": "example",     "type": "string",     "required": true,     "width": 0,     "width_units": "%",     "pinned": "left",     "color": "blue",     "multiple": true,     "format": "yfm",     "ticket_field": "assignee",     "select_options": [       "example"     ],     "mark_rows": true,     "description": "example"   } ] ``` |
| *default\_sort* | **Type**: [ColumnSortSchema](en/api-ref/grids/grids__get_grid#entity-ColumnSortSchema)[]  Default sorting **Example** ``` [   {     "slug": "example",     "title": "example",     "direction": "asc"   } ] ``` |

**Example**

```
{
  "default_sort": [
    {
      "slug": "example",
      "title": "example",
      "direction": "asc"
    }
  ],
  "columns": [
    {
      "id": "example",
      "slug": "example",
      "title": "example",
      "type": "string",
      "required": true,
      "width": 0,
      "width_units": "%",
      "pinned": "left",
      "color": "blue",
      "multiple": true,
      "format": "yfm",
      "ticket_field": "assignee",
      "select_options": [
        "example"
      ],
      "mark_rows": true,
      "description": "example"
    }
  ]
}
```

### TicketSchema

Ticket schema from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *key* | **Type**: string  Ticket key (for example, `WIKI-123`)  *Example:* `example` |
| *resolved* | **Type**: boolean  The ticket is resolved (closed) |

**Example**

```
{
  "key": "example",
  "resolved": true
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__get_grid#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### UnresolvedUserSchema

Schema for a user that was not found in the system

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__get_grid#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |
| *username* | **Type**: string  User login  *Example:* `example` |

**Example**

```
{
  "username": "example",
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  }
}
```

### TrackerEnumField

Enumeration field from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *display* | **Type**: string  Displayed field value  *Example:* `example` |
| *key* | **Type**: string  Field value key  *Example:* `example` |

**Example**

```
{
  "display": "example",
  "key": "example"
}
```

### GridRowSchema

Dynamic table row schema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique row identifier  *Example:* `example` |
| *row* | **Type**: array **Any of 10 types** - **Type**: integer - **Type**: number - **Type**: boolean - **Type**: string  *Example:* `example` - **TicketSchema**  **Type**: [TicketSchema](en/api-ref/grids/grids__get_grid#entity-TicketSchema)  Ticket schema from Yandex Tracker **Example** ```   {     "key": "example",     "resolved": true   }   ``` - **Type**: string[] **Example** ```   [     "example"   ]   ``` - **Type**: array **Any of 2 types** - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__get_grid#entity-UserSchema)  Information about the user **Example** ```     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }     ```   - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__get_grid#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```     {       "username": "example",       "identity": {         "uid": "example",         "cloud_uid": "example"       }     }     ``` **Example** ```   [     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }   ]   ``` - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__get_grid#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ``` - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__get_grid#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```   {     "username": "example",     "identity": {       "uid": "example",       "cloud_uid": "example"     }   }   ``` - **TrackerEnumField**  **Type**: [TrackerEnumField](en/api-ref/grids/grids__get_grid#entity-TrackerEnumField)  Enumeration field from Yandex Tracker **Example** ```   {     "display": "example",     "key": "example"   }   ```  Array of the row's cell values (the order matches the column order) **Example** ``` [   0 ] ``` |
| *color* | **All of 1 type** - **BGColor**  **Type**: [BGColor](en/api-ref/grids/grids__get_grid#entity-BGColor)  An enumeration.  *Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`  Row background color  *Example:* `blue` |
| *pinned* | **Type**: boolean  The row is pinned |

**Example**

```
{
  "id": "example",
  "row": [
    0
  ],
  "pinned": true,
  "color": "blue"
}
```

### UserPermission

User access permissions for the page:

- `create_page` — create subpages
- `delete` — delete the page
- `edit` — edit the page
- `view` — view the page
- `comment` — comment
- `change_authors` — change authors
- `change_acl` — change the access list
- `set_redirect` — set a redirect
- `manage_invite` — manage invitations
- `view_invite` — view invitations
- `admin` — administrative permissions

**Type**: string

*Enum:* `create_page`, `delete`, `edit`, `view`, `comment`, `change_authors`, `change_acl`, `set_redirect`, `manage_invite`, `view_invite`, `admin`

### GridAttributesSchema

Dynamic table attributes (metadata)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the table was created  *Example:* `2025-01-01T00:00:00Z` |
| *modified\_at* | **Type**: string<date-time>  Date and time the table was last modified  *Example:* `2025-01-01T00:00:00Z` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/comments/pagescomments__comments -->

- [Request](en/api-ref/comments/pagescomments__comments#request)
  - [Path parameters](en/api-ref/comments/pagescomments__comments#path-parameters)
  - [Query parameters](en/api-ref/comments/pagescomments__comments#query-parameters)
- [Responses](en/api-ref/comments/pagescomments__comments#responses)
- [200 OK](en/api-ref/comments/pagescomments__comments#200-ok)
  - [Body](en/api-ref/comments/pagescomments__comments#body)
  - [UserIdentity](en/api-ref/comments/pagescomments__comments#entity-UserIdentity)
  - [UserSchema](en/api-ref/comments/pagescomments__comments#entity-UserSchema)
  - [CommentResolveStatus](en/api-ref/comments/pagescomments__comments#entity-CommentResolveStatus)
  - [ReactionType](en/api-ref/comments/pagescomments__comments#entity-ReactionType)
  - [CommentReactionSchema](en/api-ref/comments/pagescomments__comments#entity-CommentReactionSchema)
  - [CommentSchema](en/api-ref/comments/pagescomments__comments#entity-CommentSchema)
  - [ThreadSchema](en/api-ref/comments/pagescomments__comments#entity-ThreadSchema)
  - [CommentSchemaExt](en/api-ref/comments/pagescomments__comments#entity-CommentSchemaExt)

# Comments

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/comments
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cursor* | **Type**: string  *Example:* `` |
| *order\_by* | **Type**: string  If specified, sort the results by this field in the `direction` direction  *Const:* `created_at`  *Example:* `` |
| *order\_direction* | **All of**: OrderDirection - **OrderDirection**  **Type**: string  An enumeration.  *Enum:* `asc`, `desc`  If the `order_by` field is specified, the sort direction  *Default:* `asc`  *Example:* `` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |
| *status\_filter* | **All of**: CommentResolveStatus - **CommentResolveStatus**  **Type**: string  An enumeration.  *Enum:* `resolved`, `unresolved`  Filter by comment status; accepts CommentResolveStatus (resolved, unresolved)  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": 0,
      "body": "example",
      "inline_text": "example",
      "parent_id": 0,
      "author": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "thread_id": 0,
      "created_at": "2025-01-01T00:00:00Z",
      "is_deleted": true,
      "resolve_status": "resolved",
      "reactions": [
        {
          "type": "like",
          "author": null,
          "created_at": "2025-01-01T00:00:00Z"
        }
      ],
      "thread_info": {
        "total_posts": 0,
        "last_comment": {
          "id": 0,
          "body": "example",
          "inline_text": "example",
          "parent_id": 0,
          "author": null,
          "thread_id": 0,
          "created_at": "2025-01-01T00:00:00Z",
          "is_deleted": true,
          "resolve_status": null,
          "reactions": [
            null
          ]
        }
      }
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *results* | **Type**: [CommentSchemaExt](en/api-ref/comments/pagescomments__comments#entity-CommentSchemaExt)[] **Example** ``` [   {     "id": 0,     "body": "example",     "inline_text": "example",     "parent_id": 0,     "author": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "thread_id": 0,     "created_at": "2025-01-01T00:00:00Z",     "is_deleted": true,     "resolve_status": "resolved",     "reactions": [       {         "type": "like",         "author": null,         "created_at": "2025-01-01T00:00:00Z"       }     ],     "thread_info": {       "total_posts": 0,       "last_comment": {         "id": 0,         "body": "example",         "inline_text": "example",         "parent_id": 0,         "author": null,         "thread_id": 0,         "created_at": "2025-01-01T00:00:00Z",         "is_deleted": true,         "resolve_status": null,         "reactions": [           null         ]       }     }   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/comments/pagescomments__comments#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### CommentResolveStatus

Comment resolve status:

- `resolved` — the comment is resolved
- `unresolved` — the comment is not resolved

**Type**: string

*Enum:* `resolved`, `unresolved`

### ReactionType

Comment reaction type:

- `like` — like
- `hooray` — hooray
- `confused` — confused
- `heart` — heart
- `rocket` — rocket
- `eyes` — eyes
- `fire` — fire
- `ok` — ok
- `facepalm` — facepalm
- `check` — check mark
- `laugh` — laugh
- `dislike` — dislike

**Type**: string

*Enum:* `like`, `hooray`, `confused`, `heart`, `rocket`, `eyes`, `fire`, `ok`, `facepalm`, `check`, `laugh`, `dislike`

### CommentReactionSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **Type**: [UserSchema](en/api-ref/comments/pagescomments__comments#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *type* | **Type**: [ReactionType](en/api-ref/comments/pagescomments__comments#entity-ReactionType)  Comment reaction type:   - `like` — like - `hooray` — hooray - `confused` — confused - `heart` — heart - `rocket` — rocket - `eyes` — eyes - `fire` — fire - `ok` — ok - `facepalm` — facepalm - `check` — check mark - `laugh` — laugh - `dislike` — dislike   *Enum:* `like`, `hooray`, `confused`, `heart`, `rocket`, `eyes`, `fire`, `ok`, `facepalm`, `check`, `laugh`, `dislike` |

**Example**

```
{
  "type": "like",
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z"
}
```

### CommentSchema

A comment on the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/comments/pagescomments__comments#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  Comment author **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *body* | **Type**: string  Comment text  *Example:* `example` |
| *created\_at* | **Type**: string<date-time>  Date and time the comment was created  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Type**: integer  Unique comment identifier |
| *is\_deleted* | **Type**: boolean  Comment deletion flag |
| *reactions* | **Type**: [CommentReactionSchema](en/api-ref/comments/pagescomments__comments#entity-CommentReactionSchema)[]  Reactions to the comment **Example** ``` [   {     "type": "like",     "author": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z"   } ] ``` |
| *resolve\_status* | **All of 1 type** - **CommentResolveStatus**  **Type**: [CommentResolveStatus](en/api-ref/comments/pagescomments__comments#entity-CommentResolveStatus)  Comment resolve status:    - `resolved` — the comment is resolved   - `unresolved` — the comment is not resolved *Enum:* `resolved`, `unresolved`  Comment resolve status  *Example:* `resolved` |
| *inline\_text* | **Type**: string  The text the comment is attached to (for inline comments)  *Example:* `example` |
| *parent\_id* | **Type**: integer  The ID of the parent comment (for replies in a thread) |
| *thread\_id* | **Type**: integer  Comment thread ID |

**Example**

```
{
  "id": 0,
  "body": "example",
  "inline_text": "example",
  "parent_id": 0,
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "thread_id": 0,
  "created_at": "2025-01-01T00:00:00Z",
  "is_deleted": true,
  "resolve_status": "resolved",
  "reactions": [
    {
      "type": "like",
      "author": null,
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```

### ThreadSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *last\_comment* | **Type**: [CommentSchema](en/api-ref/comments/pagescomments__comments#entity-CommentSchema)  A comment on the page **Example** ``` {   "id": 0,   "body": "example",   "inline_text": "example",   "parent_id": 0,   "author": {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "thread_id": 0,   "created_at": "2025-01-01T00:00:00Z",   "is_deleted": true,   "resolve_status": "resolved",   "reactions": [     {       "type": "like",       "author": null,       "created_at": "2025-01-01T00:00:00Z"     }   ] } ``` |
| *total\_posts* | **Type**: integer |

**Example**

```
{
  "total_posts": 0,
  "last_comment": {
    "id": 0,
    "body": "example",
    "inline_text": "example",
    "parent_id": 0,
    "author": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "thread_id": 0,
    "created_at": "2025-01-01T00:00:00Z",
    "is_deleted": true,
    "resolve_status": "resolved",
    "reactions": [
      {
        "type": "like",
        "author": null,
        "created_at": "2025-01-01T00:00:00Z"
      }
    ]
  }
}
```

### CommentSchemaExt

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **Type**: [UserSchema](en/api-ref/comments/pagescomments__comments#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *body* | **Type**: string  *Example:* `example` |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Type**: integer |
| *is\_deleted* | **Type**: boolean |
| *reactions* | **Type**: [CommentReactionSchema](en/api-ref/comments/pagescomments__comments#entity-CommentReactionSchema)[] **Example** ``` [   {     "type": "like",     "author": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z"   } ] ``` |
| *resolve\_status* | **Type**: [CommentResolveStatus](en/api-ref/comments/pagescomments__comments#entity-CommentResolveStatus)  Comment resolve status:   - `resolved` — the comment is resolved - `unresolved` — the comment is not resolved   *Enum:* `resolved`, `unresolved` |
| *inline\_text* | **Type**: string  *Example:* `example` |
| *parent\_id* | **Type**: integer |
| *thread\_id* | **Type**: integer |
| *thread\_info* | **Type**: [ThreadSchema](en/api-ref/comments/pagescomments__comments#entity-ThreadSchema) **Example** ``` {   "total_posts": 0,   "last_comment": {     "id": 0,     "body": "example",     "inline_text": "example",     "parent_id": 0,     "author": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "thread_id": 0,     "created_at": "2025-01-01T00:00:00Z",     "is_deleted": true,     "resolve_status": "resolved",     "reactions": [       {         "type": "like",         "author": null,         "created_at": "2025-01-01T00:00:00Z"       }     ]   } } ``` |

**Example**

```
{
  "id": 0,
  "body": "example",
  "inline_text": "example",
  "parent_id": 0,
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "thread_id": 0,
  "created_at": "2025-01-01T00:00:00Z",
  "is_deleted": true,
  "resolve_status": "resolved",
  "reactions": [
    {
      "type": "like",
      "author": null,
      "created_at": "2025-01-01T00:00:00Z"
    }
  ],
  "thread_info": {
    "total_posts": 0,
    "last_comment": {
      "id": 0,
      "body": "example",
      "inline_text": "example",
      "parent_id": 0,
      "author": null,
      "thread_id": 0,
      "created_at": "2025-01-01T00:00:00Z",
      "is_deleted": true,
      "resolve_status": null,
      "reactions": [
        null
      ]
    }
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__create_page -->

- [Request](en/api-ref/pages/pages__create_page#request)
  - [Query parameters](en/api-ref/pages/pages__create_page#query-parameters)
  - [Body](en/api-ref/pages/pages__create_page#body)
  - [PageAccessTypeAPI](en/api-ref/pages/pages__create_page#entity-PageAccessTypeAPI)
  - [RoleAllStaffAPI](en/api-ref/pages/pages__create_page#entity-RoleAllStaffAPI)
  - [AccessPolicyUpdateSchema](en/api-ref/pages/pages__create_page#entity-AccessPolicyUpdateSchema)
- [Responses](en/api-ref/pages/pages__create_page#responses)
- [200 OK](en/api-ref/pages/pages__create_page#200-ok)
  - [Body](en/api-ref/pages/pages__create_page#body1)
  - [PageType](en/api-ref/pages/pages__create_page#entity-PageType)
  - [PageDetailsSchema](en/api-ref/pages/pages__create_page#entity-PageDetailsSchema)
  - [RedirectSchema](en/api-ref/pages/pages__create_page#entity-RedirectSchema)
  - [BreadcrumbSchema](en/api-ref/pages/pages__create_page#entity-BreadcrumbSchema)
  - [PageAttributesSchema](en/api-ref/pages/pages__create_page#entity-PageAttributesSchema)
  - [AccessTypeInheritedAPI](en/api-ref/pages/pages__create_page#entity-AccessTypeInheritedAPI)
  - [PageInviteStatus](en/api-ref/pages/pages__create_page#entity-PageInviteStatus)
  - [AclPreviewInviteSchema](en/api-ref/pages/pages__create_page#entity-AclPreviewInviteSchema)
  - [PageAccessPolicySchema](en/api-ref/pages/pages__create_page#entity-PageAccessPolicySchema)
  - [UserIdentity](en/api-ref/pages/pages__create_page#entity-UserIdentity)
  - [UserSchema](en/api-ref/pages/pages__create_page#entity-UserSchema)
  - [ComSource](en/api-ref/pages/pages__create_page#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages/pages__create_page#entity-ComIdentitySchema)
  - [GroupType](en/api-ref/pages/pages__create_page#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages/pages__create_page#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages/pages__create_page#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages/pages__create_page#entity-GroupSchema)
  - [RoleAPI](en/api-ref/pages/pages__create_page#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages/pages__create_page#entity-InheritanceAPI)
  - [PageAccessItem](en/api-ref/pages/pages__create_page#entity-PageAccessItem)
  - [PageAccessListsSchema](en/api-ref/pages/pages__create_page#entity-PageAccessListsSchema)
  - [PageOwnerSchema](en/api-ref/pages/pages__create_page#entity-PageOwnerSchema)

# Create Page

## Request

POST

```
https://api.wiki.yandex.net/v1/pages
```

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *fields* | **Type**: string  *Example:* `` |
| *is\_silent* | **Type**: boolean  Do not send a page creation notification to subscribers  *Default:* `false` |

### Body

application/json

```
{
  "title": "example",
  "slug": "example",
  "content": "example",
  "access_policy": {
    "access_type": "inherited",
    "all_staff_role": "reader"
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *slug* | **Any of 2 types** - **Type**: string  *Example:* `example` - **Type**: string  *Example:* `example`  *Example:* `example` |
| *title* | **Type**: string  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |
| *access\_policy* | **All of 1 type** - **AccessPolicyUpdateSchema**  **Type**: [AccessPolicyUpdateSchema](en/api-ref/pages/pages__create_page#entity-AccessPolicyUpdateSchema)  Schema for updating the page access policy **Example** ```   {     "access_type": "inherited",     "all_staff_role": "reader"   }   ```  The page access settings **Example** ``` {   "access_type": "inherited",   "all_staff_role": "reader" } ``` |
| *content* | **Type**: string  *Example:* `example` |

### PageAccessTypeAPI

Page access type:

- `inherited` — inherited from the parent page
- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `inherited`, `all_staff`, `custom`

### RoleAllStaffAPI

Role for "all staff members" access:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`

### AccessPolicyUpdateSchema

Schema for updating the page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__create_page#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Page access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__create_page#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access (temporarily, only the `editor` role is available)  *Example:* `reader` |

**Example**

```
{
  "access_type": "inherited",
  "all_staff_role": "reader"
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page",
  "redirect": {
    "page_id": 0,
    "redirect_target": {
      "id": 0,
      "slug": "example",
      "title": "example",
      "page_type": null
    }
  },
  "breadcrumbs": [
    {
      "id": 0,
      "title": "example",
      "slug": "example",
      "page_exists": true
    }
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z",
    "lang": "example",
    "is_readonly": true,
    "comments_count": 0,
    "comments_enabled": true,
    "keywords": [
      "example"
    ],
    "is_collaborative": true,
    "is_draft": true
  },
  "content": "example",
  "access_policy": {
    "access_type": "inherited",
    "inherited_access_type": "all_staff",
    "all_staff_role": "reader",
    "has_external": true,
    "invite": {
      "status": null
    }
  },
  "access_lists": {
    "direct": [
      {
        "id": "example",
        "created_at": "2025-01-01T00:00:00Z",
        "user": null,
        "group": null,
        "role": null,
        "inheritance": null
      }
    ],
    "by_link": [
      null
    ],
    "inherited": [
      null
    ]
  },
  "owner": {
    "user": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "group": {
      "id": "example",
      "identity": null,
      "name": "example",
      "type": null,
      "metadata": null,
      "members_count": 0
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Unique page identifier |
| *page\_type* | **Type**: string  Page type  *Enum:* `page`, `grid`, `wysiwyg`, `template` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *access\_lists* | **All of 1 type** - **PageAccessListsSchema**  **Type**: [PageAccessListsSchema](en/api-ref/pages/pages__create_page#entity-PageAccessListsSchema)  Page access lists **Example** ```   {     "direct": [       {         "id": "example",         "created_at": "2025-01-01T00:00:00Z",         "user": {           "id": 0,           "identity": null,           "username": "example",           "display_name": "example",           "is_dismissed": true,           "affiliation": "example"         },         "group": {           "id": "example",           "identity": null,           "name": "example",           "type": null,           "metadata": null,           "members_count": 0         },         "role": "reader",         "inheritance": "inherited"       }     ],     "by_link": [       null     ],     "inherited": [       null     ]   }   ```  **Not returned by default**  Specify `access_lists` in the `?fields=access_lists, ...` list to include it in the response.  The page access lists **Example** ``` {   "direct": [     {       "id": "example",       "created_at": "2025-01-01T00:00:00Z",       "user": null,       "group": null,       "role": "reader",       "inheritance": "inherited"     }   ],   "by_link": [     null   ],   "inherited": [     null   ] } ``` |
| *access\_policy* | **All of 1 type** - **PageAccessPolicySchema**  **Type**: [PageAccessPolicySchema](en/api-ref/pages/pages__create_page#entity-PageAccessPolicySchema)  Page access policy **Example** ```   {     "access_type": "inherited",     "inherited_access_type": "all_staff",     "all_staff_role": "reader",     "has_external": true,     "invite": {       "status": 0     }   }   ```  **Not returned by default**  Specify `access_policy` in the `?fields=access_policy, ...` list to include it in the response.  The page access settings **Example** ``` {   "access_type": "inherited",   "inherited_access_type": "all_staff",   "all_staff_role": "reader",   "has_external": true,   "invite": {     "status": 0   } } ``` |
| *attributes* | **All of 1 type** - **PageAttributesSchema**  **Type**: [PageAttributesSchema](en/api-ref/pages/pages__create_page#entity-PageAttributesSchema)  Additional page attributes **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z",     "lang": "example",     "is_readonly": true,     "comments_count": 0,     "comments_enabled": true,     "keywords": [       "example"     ],     "is_collaborative": true,     "is_draft": true   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z",   "lang": "example",   "is_readonly": true,   "comments_count": 0,   "comments_enabled": true,   "keywords": [     "example"   ],   "is_collaborative": true,   "is_draft": true } ``` |
| *breadcrumbs* | **Type**: [BreadcrumbSchema](en/api-ref/pages/pages__create_page#entity-BreadcrumbSchema)[]  **Not returned by default**  Specify `breadcrumbs` in the `?fields=breadcrumbs, ...` list to include it in the response. **Example** ``` [   {     "id": 0,     "title": "example",     "slug": "example",     "page_exists": true   } ] ``` |
| *content* | **Type**: string  **Not returned by default**  Specify `content` in the `?fields=content, ...` list to include it in the response.  The page content as a string.  *Example:* `example` |
| *owner* | **All of 1 type** - **PageOwnerSchema**  **Type**: [PageOwnerSchema](en/api-ref/pages/pages__create_page#entity-PageOwnerSchema)  Page owner **Example** ```   {     "user": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": {         "src": null,         "id": "example"       },       "name": "example",       "type": "wiki",       "metadata": {         "url": "example",         "externals_count": 0       },       "members_count": 0     }   }   ```  **Not returned by default**  Specify `owner` in the `?fields=owner, ...` list to include it in the response.  The page owner **Example** ``` {   "user": {     "id": 0,     "identity": null,     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "group": {     "id": "example",     "identity": null,     "name": "example",     "type": "wiki",     "metadata": {},     "members_count": 0   } } ``` |
| *redirect* | **All of 1 type** - **RedirectSchema**  **Type**: [RedirectSchema](en/api-ref/pages/pages__create_page#entity-RedirectSchema)  Information about the page redirect **Example** ```   {     "page_id": 0,     "redirect_target": {       "id": 0,       "slug": "example",       "title": "example",       "page_type": "page"     }   }   ```  **Not returned by default**  Specify `redirect` in the `?fields=redirect, ...` list to include it in the response.  If no redirect is set, `null` is returned **Example** ``` {   "page_id": 0,   "redirect_target": {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   } } ``` |

### PageType

Page type:

- `page` — a regular page
- `grid` — a page with a table
- `cloud_page` — a cloud page
- `wysiwyg` — a page with the visual editor
- `template` — a page template

**Type**: string

*Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`

### PageDetailsSchema

Brief information about the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID |
| *page\_type* | **All of 1 type** - **PageType**  **Type**: [PageType](en/api-ref/pages/pages__create_page#entity-PageType)  Page type:    - `page` — a regular page   - `grid` — a page with a table   - `cloud_page` — a cloud page   - `wysiwyg` — a page with the visual editor   - `template` — a page template *Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`  Page type  *Example:* `page` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page"
}
```

### RedirectSchema

Information about the page redirect

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_id* | **Type**: integer  The ID of the page that the current page redirects to. |
| *redirect\_target* | **All of 1 type** - **PageDetailsSchema**  **Type**: [PageDetailsSchema](en/api-ref/pages/pages__create_page#entity-PageDetailsSchema)  Brief information about the page **Example** ```   {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   }   ```  For example, given a redirect chain A->B->C->D, for A, B, and C this will be page D **Example** ``` {   "id": 0,   "slug": "example",   "title": "example",   "page_type": "page" } ``` |

**Example**

```
{
  "page_id": 0,
  "redirect_target": {
    "id": 0,
    "slug": "example",
    "title": "example",
    "page_type": "page"
  }
}
```

### BreadcrumbSchema

A breadcrumb item (navigation trail)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_exists* | **Type**: boolean  Whether the page exists |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *id* | **Type**: integer  Page ID (if the page exists) |

**Example**

```
{
  "id": 0,
  "title": "example",
  "slug": "example",
  "page_exists": true
}
```

### PageAttributesSchema

Additional page attributes

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comments\_count* | **Type**: integer  Number of comments on the page |
| *comments\_enabled* | **Type**: boolean  Comments are enabled |
| *created\_at* | **Type**: string<date-time>  Date and time the page was created  *Example:* `2025-01-01T00:00:00Z` |
| *is\_readonly* | **Type**: boolean  The page is read-only |
| *lang* | **Type**: string  Page language (for example, `ru`, `en`)  *Example:* `example` |
| *modified\_at* | **Type**: string<date-time>  Date and time the page was last modified  *Example:* `2025-01-01T00:00:00Z` |
| *is\_collaborative* | **Type**: boolean  Collaborative editing is enabled |
| *is\_draft* | **Type**: boolean  The page is a draft |
| *keywords* | **Type**: string[]  Page keywords **Example** ``` [   "example" ] ``` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z",
  "lang": "example",
  "is_readonly": true,
  "comments_count": 0,
  "comments_enabled": true,
  "keywords": [
    "example"
  ],
  "is_collaborative": true,
  "is_draft": true
}
```

### AccessTypeInheritedAPI

Inherited access type:

- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `all_staff`, `custom`

### PageInviteStatus

Invitation link status:

- `0` — deleted
- `1` — enabled
- `2` — disabled

**Type**: integer

*Enum:* `0`, `1`, `2`

### AclPreviewInviteSchema

Information about the invitation link for page access

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **All of 1 type** - **PageInviteStatus**  **Type**: [PageInviteStatus](en/api-ref/pages/pages__create_page#entity-PageInviteStatus)  Invitation link status:    - `0` — deleted   - `1` — enabled   - `2` — disabled *Enum:* `0`, `1`, `2`  *Example:* `0`  Link status:   - 0 - deleted (not returned by the API) - 1 - enabled - 2 - disabled   *Example:* `0` |

**Example**

```
{
  "status": 0
}
```

### PageAccessPolicySchema

Page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__create_page#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__create_page#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access  *Example:* `reader` |
| *has\_external* | **Type**: boolean  Indicates that the page is accessible to external consultants. If None, the status is unknown |
| *inherited\_access\_type* | **All of 1 type** - **AccessTypeInheritedAPI**  **Type**: [AccessTypeInheritedAPI](en/api-ref/pages/pages__create_page#entity-AccessTypeInheritedAPI)  Inherited access type:    - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `all_staff`, `custom`  Inherited access type  *Example:* `all_staff` |
| *invite* | **All of 1 type** - **AclPreviewInviteSchema**  **Type**: [AclPreviewInviteSchema](en/api-ref/pages/pages__create_page#entity-AclPreviewInviteSchema)  Information about the invitation link for page access **Example** ```   {     "status": 0   }   ```  Information about the invitation link for page access **Example** ``` {   "status": 0 } ``` |

**Example**

```
{
  "access_type": "inherited",
  "inherited_access_type": "all_staff",
  "all_staff_role": "reader",
  "has_external": true,
  "invite": {
    "status": 0
  }
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages/pages__create_page#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages/pages__create_page#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages/pages__create_page#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages/pages__create_page#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages/pages__create_page#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages/pages__create_page#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

### PageAccessItem

A personal page access item

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages/pages__create_page#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__create_page#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages/pages__create_page#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__create_page#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

### PageAccessListsSchema

Page access lists

|  |  |
| --- | --- |
| **Name** | **Description** |
| *by\_link* | **Type**: [PageAccessItem](en/api-ref/pages/pages__create_page#entity-PageAccessItem)[]  Accesses via the invitation link **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *direct* | **Type**: [PageAccessItem](en/api-ref/pages/pages__create_page#entity-PageAccessItem)[]  Direct personal accesses to the page **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *inherited* | **Type**: [PageAccessItem](en/api-ref/pages/pages__create_page#entity-PageAccessItem)[]  Accesses inherited from parent pages **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |

**Example**

```
{
  "direct": [
    {
      "id": "example",
      "created_at": "2025-01-01T00:00:00Z",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "group": {
        "id": "example",
        "identity": null,
        "name": "example",
        "type": null,
        "metadata": null,
        "members_count": 0
      },
      "role": "reader",
      "inheritance": "inherited"
    }
  ],
  "by_link": [
    null
  ],
  "inherited": [
    null
  ]
}
```

### PageOwnerSchema

Page owner

|  |  |
| --- | --- |
| **Name** | **Description** |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__create_page#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  **(not implemented)** The group that owns the page **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__create_page#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who owns the page **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pagesresources/pagesresources__resources -->

- [Request](en/api-ref/pagesresources/pagesresources__resources#request)
  - [Path parameters](en/api-ref/pagesresources/pagesresources__resources#path-parameters)
  - [Query parameters](en/api-ref/pagesresources/pagesresources__resources#query-parameters)
- [Responses](en/api-ref/pagesresources/pagesresources__resources#responses)
- [200 OK](en/api-ref/pagesresources/pagesresources__resources#200-ok)
  - [Body](en/api-ref/pagesresources/pagesresources__resources#body)
  - [ResourceType](en/api-ref/pagesresources/pagesresources__resources#entity-ResourceType)
  - [UserIdentity](en/api-ref/pagesresources/pagesresources__resources#entity-UserIdentity)
  - [UserSchema](en/api-ref/pagesresources/pagesresources__resources#entity-UserSchema)
  - [FileCheckStatusType](en/api-ref/pagesresources/pagesresources__resources#entity-FileCheckStatusType)
  - [AttachmentSchema](en/api-ref/pagesresources/pagesresources__resources#entity-AttachmentSchema)
  - [PageGridsSchema](en/api-ref/pagesresources/pagesresources__resources#entity-PageGridsSchema)
  - [Resource](en/api-ref/pagesresources/pagesresources__resources#entity-Resource)

# Get information about resources

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/resources
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cursor* | **Type**: string  *Example:* `` |
| *order\_by* | **Type**: string  If specified, sort the results by this field in the `direction` direction  *Enum:* `name_title`, `created_at` |
| *order\_direction* | **All of**: OrderDirection - **OrderDirection**  **Type**: string  An enumeration.  *Enum:* `asc`, `desc`  If the `order_by` field is specified, the sort direction  *Default:* `asc`  *Example:* `` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |
| *q* | **Type**: string  Search by title  *Max length:* `255`  *Example:* `` |
| *types* | **Type**: string  The resource types to include, comma-separated. Possible values: attachment, grid  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "type": "attachment",
      "item": {
        "id": 0,
        "name": "example",
        "is_downloadable": true,
        "download_url": "example",
        "size": "example",
        "description": "example",
        "user": null,
        "created_at": "2025-01-01T00:00:00Z",
        "mimetype": "example",
        "has_preview": true,
        "check_status": "ready"
      }
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *results* | **Type**: [Resource](en/api-ref/pagesresources/pagesresources__resources#entity-Resource)[] **Example** ``` [   {     "type": "attachment",     "item": {       "id": 0,       "name": "example",       "is_downloadable": true,       "download_url": "example",       "size": "example",       "description": "example",       "user": null,       "created_at": "2025-01-01T00:00:00Z",       "mimetype": "example",       "has_preview": true,       "check_status": "ready"     }   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### ResourceType

Page resource type:

- `attachment` — an attached file
- `grid` — a dynamic table

**Type**: string

*Enum:* `attachment`, `grid`

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pagesresources/pagesresources__resources#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### FileCheckStatusType

Antivirus file check status:

- `check` — the file is being checked
- `ready` — the file has been checked and is safe
- `deleted` — the file has been deleted
- `infected` — a virus has been detected
- `error` — an error occurred during the check

**Type**: string

*Enum:* `check`, `ready`, `deleted`, `infected`, `error`

### AttachmentSchema

A file attached to the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the file was uploaded  *Example:* `2025-01-01T00:00:00Z` |
| *description* | **Type**: string  File description  *Example:* `example` |
| *download\_url* | **Type**: string  File download URL  *Example:* `example` |
| *has\_preview* | **Type**: boolean  Whether a file preview is available |
| *id* | **Type**: integer  Unique file identifier |
| *mimetype* | **Type**: string  File MIME type  *Example:* `example` |
| *name* | **Type**: string  File name  *Example:* `example` |
| *size* | **Type**: string  File size  *Example:* `example` |
| *check\_status* | **All of 1 type** - **FileCheckStatusType**  **Type**: [FileCheckStatusType](en/api-ref/pagesresources/pagesresources__resources#entity-FileCheckStatusType)  Antivirus file check status:    - `check` — the file is being checked   - `ready` — the file has been checked and is safe   - `deleted` — the file has been deleted   - `infected` — a virus has been detected   - `error` — an error occurred during the check *Enum:* `check`, `ready`, `deleted`, `infected`, `error`  Antivirus file check status  *Default:* `ready` |
| *is\_downloadable* | **Type**: boolean  Whether the file is available for download  *Default:* `true` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pagesresources/pagesresources__resources#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who uploaded the file **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": 0,
  "name": "example",
  "is_downloadable": true,
  "download_url": "example",
  "size": "example",
  "description": "example",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "mimetype": "example",
  "has_preview": true,
  "check_status": "ready"
}
```

### PageGridsSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Type**: string<uuid4>  *Example:* `example` |
| *title* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "id": "example",
  "title": "example",
  "created_at": "2025-01-01T00:00:00Z"
}
```

### Resource

|  |  |
| --- | --- |
| **Name** | **Description** |
| *item* | **Any of 2 types** - **AttachmentSchema**  **Type**: [AttachmentSchema](en/api-ref/pagesresources/pagesresources__resources#entity-AttachmentSchema)  A file attached to the page **Example** ```   {     "id": 0,     "name": "example",     "is_downloadable": true,     "download_url": "example",     "size": "example",     "description": "example",     "user": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z",     "mimetype": "example",     "has_preview": true,     "check_status": "ready"   }   ``` - **PageGridsSchema**  **Type**: [PageGridsSchema](en/api-ref/pagesresources/pagesresources__resources#entity-PageGridsSchema) **Example** ```   {     "id": "example",     "title": "example",     "created_at": "2025-01-01T00:00:00Z"   }   ``` **Example** ``` {   "id": 0,   "name": "example",   "is_downloadable": true,   "download_url": "example",   "size": "example",   "description": "example",   "user": {     "id": 0,     "identity": null,     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "created_at": "2025-01-01T00:00:00Z",   "mimetype": "example",   "has_preview": true,   "check_status": "ready" } ``` |
| *type* | **Type**: [ResourceType](en/api-ref/pagesresources/pagesresources__resources#entity-ResourceType)  Page resource type:   - `attachment` — an attached file - `grid` — a dynamic table   *Enum:* `attachment`, `grid` |

**Example**

```
{
  "type": "attachment",
  "item": {
    "id": 0,
    "name": "example",
    "is_downloadable": true,
    "download_url": "example",
    "size": "example",
    "description": "example",
    "user": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "created_at": "2025-01-01T00:00:00Z",
    "mimetype": "example",
    "has_preview": true,
    "check_status": "ready"
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/ -->

# Upload Sessions

## Endpoints

- [Create Upload Session](en/api-ref/upload_sessions/upload_sessions__create_upload_session)
- [Abort All](en/api-ref/upload_sessions/upload_sessions__abort_all)
- [Get Upload Session](en/api-ref/upload_sessions/upload_sessions__get_upload_session)
- [Upload Part](en/api-ref/upload_sessions/upload_sessions__upload_part)
- [Complete Multipart Upload](en/api-ref/upload_sessions/upload_sessions__complete_multipart_upload)
- [Abort Multipart Upload](en/api-ref/upload_sessions/upload_sessions__abort_multipart_upload)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/operations/ -->

# Operations

## Endpoints

- [Get Clone Operation Status](en/api-ref/operations/operations__get_clone_operation_status)
- [Get Clone Inline Grid Operation Status](en/api-ref/operations/operations__get_clone_inline_grid_operation_status)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pagesresources/ -->

# Page Resources

## Endpoints

- [Get information about resources](en/api-ref/pagesresources/pagesresources__resources)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/grids/grids__add_rows -->

- [Request](en/api-ref/grids/grids__add_rows#request)
  - [Path parameters](en/api-ref/grids/grids__add_rows#path-parameters)
  - [Body](en/api-ref/grids/grids__add_rows#body)
  - [UserIdentityExtended](en/api-ref/grids/grids__add_rows#entity-UserIdentityExtended)
- [Responses](en/api-ref/grids/grids__add_rows#responses)
- [200 OK](en/api-ref/grids/grids__add_rows#200-ok)
  - [Body](en/api-ref/grids/grids__add_rows#body1)
  - [TicketSchema](en/api-ref/grids/grids__add_rows#entity-TicketSchema)
  - [UserIdentity](en/api-ref/grids/grids__add_rows#entity-UserIdentity)
  - [UserSchema](en/api-ref/grids/grids__add_rows#entity-UserSchema)
  - [UnresolvedUserSchema](en/api-ref/grids/grids__add_rows#entity-UnresolvedUserSchema)
  - [TrackerEnumField](en/api-ref/grids/grids__add_rows#entity-TrackerEnumField)
  - [BGColor](en/api-ref/grids/grids__add_rows#entity-BGColor)
  - [GridRowSchema](en/api-ref/grids/grids__add_rows#entity-GridRowSchema)

# Add Rows

## Request

POST

```
https://api.wiki.yandex.net/v1/grids/{idx}/rows
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: string<uuid4>  *Example:* `` |

### Body

application/json

```
{
  "revision": "example",
  "position": 0,
  "after_row_id": "example",
  "rows": [
    {}
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *rows* | **Type**: object[] |  |  | | --- | --- | | *[additional]* | **Any of 6 types** - **Type**: integer - **Type**: number - **Type**: boolean - **Type**: string  *Example:* `example` - **Type**: string[] **Example** ```   [     "example"   ]   ``` - **Type**: [UserIdentityExtended](en/api-ref/grids/grids__add_rows#entity-UserIdentityExtended)[] **Example** ```   [     {       "uid": "example",       "cloud_uid": "example",       "username": "example"     }   ]   ```  *Example:* `0` | **Example** ``` [   {} ] ``` |
| *after\_row\_id* | **Type**: string  *Example:* `example` |
| *position* | **Type**: integer |
| *revision* | **Type**: string  *Example:* `example` |

### UserIdentityExtended

Extended user identifier with additional fields

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in Yandex Cloud  *Example:* `example` |
| *uid* | **Type**: string  Unique user identifier (UID) in Yandex  *Example:* `example` |
| *username* | **Type**: string  User login  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example",
  "username": "example"
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "revision": "example",
  "results": [
    {
      "id": "example",
      "row": [
        0
      ],
      "pinned": true,
      "color": "blue"
    }
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *revision* | **Type**: string  *Example:* `example` |
| *results* | **Type**: [GridRowSchema](en/api-ref/grids/grids__add_rows#entity-GridRowSchema)[] **Example** ``` [   {     "id": "example",     "row": [       0     ],     "pinned": true,     "color": "blue"   } ] ``` |

### TicketSchema

Ticket schema from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *key* | **Type**: string  Ticket key (for example, `WIKI-123`)  *Example:* `example` |
| *resolved* | **Type**: boolean  The ticket is resolved (closed) |

**Example**

```
{
  "key": "example",
  "resolved": true
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__add_rows#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### UnresolvedUserSchema

Schema for a user that was not found in the system

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/grids/grids__add_rows#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |
| *username* | **Type**: string  User login  *Example:* `example` |

**Example**

```
{
  "username": "example",
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  }
}
```

### TrackerEnumField

Enumeration field from Yandex Tracker

|  |  |
| --- | --- |
| **Name** | **Description** |
| *display* | **Type**: string  Displayed field value  *Example:* `example` |
| *key* | **Type**: string  Field value key  *Example:* `example` |

**Example**

```
{
  "display": "example",
  "key": "example"
}
```

### BGColor

An enumeration.

**Type**: string

*Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`

### GridRowSchema

Dynamic table row schema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique row identifier  *Example:* `example` |
| *row* | **Type**: array **Any of 10 types** - **Type**: integer - **Type**: number - **Type**: boolean - **Type**: string  *Example:* `example` - **TicketSchema**  **Type**: [TicketSchema](en/api-ref/grids/grids__add_rows#entity-TicketSchema)  Ticket schema from Yandex Tracker **Example** ```   {     "key": "example",     "resolved": true   }   ``` - **Type**: string[] **Example** ```   [     "example"   ]   ``` - **Type**: array **Any of 2 types** - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__add_rows#entity-UserSchema)  Information about the user **Example** ```     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }     ```   - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__add_rows#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```     {       "username": "example",       "identity": {         "uid": "example",         "cloud_uid": "example"       }     }     ``` **Example** ```   [     {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     }   ]   ``` - **UserSchema**  **Type**: [UserSchema](en/api-ref/grids/grids__add_rows#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ``` - **UnresolvedUserSchema**  **Type**: [UnresolvedUserSchema](en/api-ref/grids/grids__add_rows#entity-UnresolvedUserSchema)  Schema for a user that was not found in the system **Example** ```   {     "username": "example",     "identity": {       "uid": "example",       "cloud_uid": "example"     }   }   ``` - **TrackerEnumField**  **Type**: [TrackerEnumField](en/api-ref/grids/grids__add_rows#entity-TrackerEnumField)  Enumeration field from Yandex Tracker **Example** ```   {     "display": "example",     "key": "example"   }   ```  Array of the row's cell values (the order matches the column order) **Example** ``` [   0 ] ``` |
| *color* | **All of 1 type** - **BGColor**  **Type**: [BGColor](en/api-ref/grids/grids__add_rows#entity-BGColor)  An enumeration.  *Enum:* `blue`, `yellow`, `pink`, `red`, `green`, `mint`, `grey`, `orange`, `magenta`, `purple`, `copper`, `ocean`  Row background color  *Example:* `blue` |
| *pinned* | **Type**: boolean  The row is pinned |

**Example**

```
{
  "id": "example",
  "row": [
    0
  ],
  "pinned": true,
  "color": "blue"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/comments/pagescomments__create_comment -->

- [Request](en/api-ref/comments/pagescomments__create_comment#request)
  - [Path parameters](en/api-ref/comments/pagescomments__create_comment#path-parameters)
  - [Body](en/api-ref/comments/pagescomments__create_comment#body)
- [Responses](en/api-ref/comments/pagescomments__create_comment#responses)
- [200 OK](en/api-ref/comments/pagescomments__create_comment#200-ok)
  - [Body](en/api-ref/comments/pagescomments__create_comment#body1)
  - [UserIdentity](en/api-ref/comments/pagescomments__create_comment#entity-UserIdentity)
  - [UserSchema](en/api-ref/comments/pagescomments__create_comment#entity-UserSchema)
  - [CommentResolveStatus](en/api-ref/comments/pagescomments__create_comment#entity-CommentResolveStatus)
  - [ReactionType](en/api-ref/comments/pagescomments__create_comment#entity-ReactionType)
  - [CommentReactionSchema](en/api-ref/comments/pagescomments__create_comment#entity-CommentReactionSchema)

# Create Comment

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}/comments
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Body

application/json

```
{
  "body": "example",
  "inline_text": "example",
  "parent_id": 0,
  "thread_id": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *body* | **Type**: string  *Example:* `example` |
| *inline\_text* | **Type**: string  *Example:* `example` |
| *parent\_id* | **Type**: integer |
| *thread\_id* | **Type**: integer |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "body": "example",
  "inline_text": "example",
  "parent_id": 0,
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "thread_id": 0,
  "created_at": "2025-01-01T00:00:00Z",
  "is_deleted": true,
  "resolve_status": "resolved",
  "reactions": [
    {
      "type": "like",
      "author": null,
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/comments/pagescomments__create_comment#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  Comment author **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *body* | **Type**: string  Comment text  *Example:* `example` |
| *created\_at* | **Type**: string<date-time>  Date and time the comment was created  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Type**: integer  Unique comment identifier |
| *is\_deleted* | **Type**: boolean  Comment deletion flag |
| *reactions* | **Type**: [CommentReactionSchema](en/api-ref/comments/pagescomments__create_comment#entity-CommentReactionSchema)[]  Reactions to the comment **Example** ``` [   {     "type": "like",     "author": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z"   } ] ``` |
| *resolve\_status* | **All of 1 type** - **CommentResolveStatus**  **Type**: [CommentResolveStatus](en/api-ref/comments/pagescomments__create_comment#entity-CommentResolveStatus)  Comment resolve status:    - `resolved` — the comment is resolved   - `unresolved` — the comment is not resolved *Enum:* `resolved`, `unresolved`  Comment resolve status  *Example:* `resolved` |
| *inline\_text* | **Type**: string  The text the comment is attached to (for inline comments)  *Example:* `example` |
| *parent\_id* | **Type**: integer  The ID of the parent comment (for replies in a thread) |
| *thread\_id* | **Type**: integer  Comment thread ID |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/comments/pagescomments__create_comment#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### CommentResolveStatus

Comment resolve status:

- `resolved` — the comment is resolved
- `unresolved` — the comment is not resolved

**Type**: string

*Enum:* `resolved`, `unresolved`

### ReactionType

Comment reaction type:

- `like` — like
- `hooray` — hooray
- `confused` — confused
- `heart` — heart
- `rocket` — rocket
- `eyes` — eyes
- `fire` — fire
- `ok` — ok
- `facepalm` — facepalm
- `check` — check mark
- `laugh` — laugh
- `dislike` — dislike

**Type**: string

*Enum:* `like`, `hooray`, `confused`, `heart`, `rocket`, `eyes`, `fire`, `ok`, `facepalm`, `check`, `laugh`, `dislike`

### CommentReactionSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *author* | **Type**: [UserSchema](en/api-ref/comments/pagescomments__create_comment#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *type* | **Type**: [ReactionType](en/api-ref/comments/pagescomments__create_comment#entity-ReactionType)  Comment reaction type:   - `like` — like - `hooray` — hooray - `confused` — confused - `heart` — heart - `rocket` — rocket - `eyes` — eyes - `fire` — fire - `ok` — ok - `facepalm` — facepalm - `check` — check mark - `laugh` — laugh - `dislike` — dislike   *Enum:* `like`, `hooray`, `confused`, `heart`, `rocket`, `eyes`, `fire`, `ok`, `facepalm`, `check`, `laugh`, `dislike` |

**Example**

```
{
  "type": "like",
  "author": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/attachments/pagesattachments__delete_attach -->

- [Request](en/api-ref/attachments/pagesattachments__delete_attach#request)
  - [Path parameters](en/api-ref/attachments/pagesattachments__delete_attach#path-parameters)
- [Responses](en/api-ref/attachments/pagesattachments__delete_attach#responses)
- [204 No Content](en/api-ref/attachments/pagesattachments__delete_attach#204-no-content)
  - [Body](en/api-ref/attachments/pagesattachments__delete_attach#body)

# Delete Attach

## Request

DELETE

```
https://api.wiki.yandex.net/v1/pages/{idx}/attachments/{file_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *file\_id* | **Type**: integer |
| *idx* | **Type**: integer |

## Responses

## 204 No Content

No Content

### Body

application/json

```
{}
```

|  |  |
| --- | --- |
| **Name** | **Description** |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/attachments/pagesattachments__attachments -->

- [Request](en/api-ref/attachments/pagesattachments__attachments#request)
  - [Path parameters](en/api-ref/attachments/pagesattachments__attachments#path-parameters)
  - [Query parameters](en/api-ref/attachments/pagesattachments__attachments#query-parameters)
- [Responses](en/api-ref/attachments/pagesattachments__attachments#responses)
- [200 OK](en/api-ref/attachments/pagesattachments__attachments#200-ok)
  - [Body](en/api-ref/attachments/pagesattachments__attachments#body)
  - [UserIdentity](en/api-ref/attachments/pagesattachments__attachments#entity-UserIdentity)
  - [UserSchema](en/api-ref/attachments/pagesattachments__attachments#entity-UserSchema)
  - [FileCheckStatusType](en/api-ref/attachments/pagesattachments__attachments#entity-FileCheckStatusType)
  - [AttachmentSchema](en/api-ref/attachments/pagesattachments__attachments#entity-AttachmentSchema)

# Attachments

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/attachments
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cursor* | **Type**: string  *Example:* `` |
| *order\_by* | **Type**: string  If specified, sort the results by this field in the `direction` direction  *Enum:* `name`, `size`, `created_at` |
| *order\_direction* | **All of**: OrderDirection - **OrderDirection**  **Type**: string  An enumeration.  *Enum:* `asc`, `desc`  If the `order_by` field is specified, the sort direction  *Default:* `asc`  *Example:* `` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": 0,
      "name": "example",
      "is_downloadable": true,
      "download_url": "example",
      "size": "example",
      "description": "example",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "created_at": "2025-01-01T00:00:00Z",
      "mimetype": "example",
      "has_preview": true,
      "check_status": "ready"
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *results* | **Type**: [AttachmentSchema](en/api-ref/attachments/pagesattachments__attachments#entity-AttachmentSchema)[] **Example** ``` [   {     "id": 0,     "name": "example",     "is_downloadable": true,     "download_url": "example",     "size": "example",     "description": "example",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "created_at": "2025-01-01T00:00:00Z",     "mimetype": "example",     "has_preview": true,     "check_status": "ready"   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/attachments/pagesattachments__attachments#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### FileCheckStatusType

Antivirus file check status:

- `check` — the file is being checked
- `ready` — the file has been checked and is safe
- `deleted` — the file has been deleted
- `infected` — a virus has been detected
- `error` — an error occurred during the check

**Type**: string

*Enum:* `check`, `ready`, `deleted`, `infected`, `error`

### AttachmentSchema

A file attached to the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  Date and time the file was uploaded  *Example:* `2025-01-01T00:00:00Z` |
| *description* | **Type**: string  File description  *Example:* `example` |
| *download\_url* | **Type**: string  File download URL  *Example:* `example` |
| *has\_preview* | **Type**: boolean  Whether a file preview is available |
| *id* | **Type**: integer  Unique file identifier |
| *mimetype* | **Type**: string  File MIME type  *Example:* `example` |
| *name* | **Type**: string  File name  *Example:* `example` |
| *size* | **Type**: string  File size  *Example:* `example` |
| *check\_status* | **All of 1 type** - **FileCheckStatusType**  **Type**: [FileCheckStatusType](en/api-ref/attachments/pagesattachments__attachments#entity-FileCheckStatusType)  Antivirus file check status:    - `check` — the file is being checked   - `ready` — the file has been checked and is safe   - `deleted` — the file has been deleted   - `infected` — a virus has been detected   - `error` — an error occurred during the check *Enum:* `check`, `ready`, `deleted`, `infected`, `error`  Antivirus file check status  *Default:* `ready` |
| *is\_downloadable* | **Type**: boolean  Whether the file is available for download  *Default:* `true` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/attachments/pagesattachments__attachments#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who uploaded the file **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": 0,
  "name": "example",
  "is_downloadable": true,
  "download_url": "example",
  "size": "example",
  "description": "example",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "mimetype": "example",
  "has_preview": true,
  "check_status": "ready"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages_access/ -->

# Page Access

## Endpoints

- [Add user/group access to a page](en/api-ref/pages_access/pagesaccess__create_page_access)
- [Delete all personal page accesses](en/api-ref/pages_access/pagesaccess__delete_page_accesses)
- [Update user/group access to a page](en/api-ref/pages_access/pagesaccess__update_page_access)
- [Delete user/group access to a page](en/api-ref/pages_access/pagesaccess__delete_page_access)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/ -->

# Pages

## Endpoints

- [Get Page Details](en/api-ref/pages/pages__get_page_details)
- [Create Page](en/api-ref/pages/pages__create_page)
- [Get Page Details By Id](en/api-ref/pages/pages__get_page_details_by_id)
- [Update Page](en/api-ref/pages/pages__update_page_details)
- [Delete Page](en/api-ref/pages/pages__delete_page)
- [Clone Page](en/api-ref/pages/pages__clone_page)
- [Page Grids](en/api-ref/pages/pages__page_grids)
- [Append Content](en/api-ref/pages/pages__append_content)
- [Get Page Descendants](en/api-ref/pages/pages__descendants_by_id)
- [Get Page Descendants by Slug](en/api-ref/pages/pages__descendants_by_slug)


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/operations/operations__get_clone_operation_status -->

- [Request](en/api-ref/operations/operations__get_clone_operation_status#request)
  - [Path parameters](en/api-ref/operations/operations__get_clone_operation_status#path-parameters)
- [Responses](en/api-ref/operations/operations__get_clone_operation_status#responses)
- [200 OK](en/api-ref/operations/operations__get_clone_operation_status#200-ok)
  - [Body](en/api-ref/operations/operations__get_clone_operation_status#body)
  - [Status](en/api-ref/operations/operations__get_clone_operation_status#entity-Status)
  - [Progress](en/api-ref/operations/operations__get_clone_operation_status#entity-Progress)
  - [PageSchema](en/api-ref/operations/operations__get_clone_operation_status#entity-PageSchema)
  - [PageCloneResponse](en/api-ref/operations/operations__get_clone_operation_status#entity-PageCloneResponse)

# Get Clone Operation Status

## Request

GET

```
https://api.wiki.yandex.net/v1/operations/clone/{task_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *task\_id* | **Type**: string  *Example:* `` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "status": "scheduled",
  "progress": {
    "percentage": 0.5,
    "details": "example"
  },
  "result": {
    "page": {
      "id": 0,
      "slug": "example"
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **Type**: [Status](en/api-ref/operations/operations__get_clone_operation_status#entity-Status)  An enumeration.  *Enum:* `scheduled`, `in_progress`, `success`, `failed` |
| *progress* | **Type**: [Progress](en/api-ref/operations/operations__get_clone_operation_status#entity-Progress) **Example** ``` {   "percentage": 0.5,   "details": "example" } ``` |
| *result* | **Type**: [PageCloneResponse](en/api-ref/operations/operations__get_clone_operation_status#entity-PageCloneResponse) **Example** ``` {   "page": {     "id": 0,     "slug": "example"   } } ``` |

### Status

An enumeration.

**Type**: string

*Enum:* `scheduled`, `in_progress`, `success`, `failed`

### Progress

|  |  |
| --- | --- |
| **Name** | **Description** |
| *details* | **Type**: string  *Example:* `example` |
| *percentage* | **Type**: number |

**Example**

```
{
  "percentage": 0.5,
  "details": "example"
}
```

### PageSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer |
| *slug* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```

### PageCloneResponse

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page* | **All of 1 type** - **PageSchema**  **Type**: [PageSchema](en/api-ref/operations/operations__get_clone_operation_status#entity-PageSchema) **Example** ```   {     "id": 0,     "slug": "example"   }   ```  The cloned page **Example** ``` {   "id": 0,   "slug": "example" } ``` |

**Example**

```
{
  "page": {
    "id": 0,
    "slug": "example"
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/attachments/pagesattachments__download_by_file_id -->

- [Request](en/api-ref/attachments/pagesattachments__download_by_file_id#request)
  - [Path parameters](en/api-ref/attachments/pagesattachments__download_by_file_id#path-parameters)
- [Responses](en/api-ref/attachments/pagesattachments__download_by_file_id#responses)
- [200 OK](en/api-ref/attachments/pagesattachments__download_by_file_id#200-ok)

# Download By File Id

Download a file by its permanent identifier

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/attachments/{file_id}/download
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *file\_id* | **Type**: integer |
| *idx* | **Type**: integer |

## Responses

## 200 OK

OK


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/upload_sessions__upload_part -->

- [Request](en/api-ref/upload_sessions/upload_sessions__upload_part#request)
  - [Path parameters](en/api-ref/upload_sessions/upload_sessions__upload_part#path-parameters)
  - [Query parameters](en/api-ref/upload_sessions/upload_sessions__upload_part#query-parameters)
- [Responses](en/api-ref/upload_sessions/upload_sessions__upload_part#responses)
- [200 OK](en/api-ref/upload_sessions/upload_sessions__upload_part#200-ok)
  - [Body](en/api-ref/upload_sessions/upload_sessions__upload_part#body)
  - [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-UploadSessionStatusType)
  - [UserIdentity](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-UserIdentity)
  - [UserSchema](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-UserSchema)
  - [StorageType](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-StorageType)

# Upload Part

Uploads a file in parts. Before starting the upload, you must create a session: [Create File Upload Session](en/api-ref/upload_sessions/upload_sessions__create_upload_session).

- Use `Content-Type: application/octet-stream`
- The file can be split into parts ranging from 5 MB to 16 MB (except for the last part). Parts are sent in the request body.
- For the first part, set `part_number=1`; increment `part_number` by one for each subsequent part.
- Parts can be uploaded in parallel and re-uploaded on error.

## Request

PUT

```
https://api.wiki.yandex.net/v1/upload_sessions/{session_id}/upload_part
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *session\_id* | **Type**: string<uuid4>  *Example:* `` |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *part\_number* | **Type**: integer  *Min value:* `1`  *Max value:* `10000` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "session_id": "example",
  "file_name": "example",
  "file_size": 0,
  "status": "not_started",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "created_at": "2025-01-01T00:00:00Z",
  "finished_at": "2025-01-01T00:00:00Z",
  "storage_type": "mds"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *file\_name* | **Type**: string  *Example:* `example` |
| *file\_size* | **Type**: integer |
| *session\_id* | **Type**: string<uuid4>  *Example:* `example` |
| *status* | **Type**: [UploadSessionStatusType](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-UploadSessionStatusType)  An enumeration.  *Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup` |
| *user* | **Type**: [UserSchema](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-UserSchema)  Information about the user **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |
| *finished\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *storage\_type* | **Type**: [StorageType](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-StorageType)  An enumeration.  *Enum:* `mds`, `s3`, `custom_s3` |

### UploadSessionStatusType

An enumeration.

**Type**: string

*Enum:* `not_started`, `in_progress`, `finished`, `aborted`, `used`, `cleanup`

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/upload_sessions/upload_sessions__upload_part#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### StorageType

An enumeration.

**Type**: string

*Enum:* `mds`, `s3`, `custom_s3`


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages_access/pagesaccess__update_page_access -->

- [Request](en/api-ref/pages_access/pagesaccess__update_page_access#request)
  - [Path parameters](en/api-ref/pages_access/pagesaccess__update_page_access#path-parameters)
  - [Query parameters](en/api-ref/pages_access/pagesaccess__update_page_access#query-parameters)
  - [Body](en/api-ref/pages_access/pagesaccess__update_page_access#body)
  - [RoleAPI](en/api-ref/pages_access/pagesaccess__update_page_access#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages_access/pagesaccess__update_page_access#entity-InheritanceAPI)
- [Responses](en/api-ref/pages_access/pagesaccess__update_page_access#responses)
- [200 OK](en/api-ref/pages_access/pagesaccess__update_page_access#200-ok)
  - [Body](en/api-ref/pages_access/pagesaccess__update_page_access#body1)
  - [UserIdentity](en/api-ref/pages_access/pagesaccess__update_page_access#entity-UserIdentity)
  - [UserSchema](en/api-ref/pages_access/pagesaccess__update_page_access#entity-UserSchema)
  - [ComSource](en/api-ref/pages_access/pagesaccess__update_page_access#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages_access/pagesaccess__update_page_access#entity-ComIdentitySchema)
  - [GroupType](en/api-ref/pages_access/pagesaccess__update_page_access#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages_access/pagesaccess__update_page_access#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages_access/pagesaccess__update_page_access#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages_access/pagesaccess__update_page_access#entity-GroupSchema)

# Update user/group access to a page

Updates an existing personal access to a page.

Lets you change the role of a user or group, as well as configure access inheritance for subpages.

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}/access/{access_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_id* | **Type**: string  Access ID  *Example:* `` |
| *idx* | **Type**: integer  Page ID |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *prevent\_selflock* | **Type**: boolean  If `true`, an error is raised when updating an access would cause the co-author to lose read access or access management permissions  *Default:* `false` |

### Body

application/json

```
{
  "role": "reader",
  "inheritance": "inherited"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages_access/pagesaccess__update_page_access#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance for subpages: `inherited` (inherited), `not_inherited` (not inherited)  *Example:* `inherited` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages_access/pagesaccess__update_page_access#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  The new access role: `reader` (read), `editor` (edit), `extra_editor` (extended editing), `author` (author)  *Example:* `reader` |

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages_access/pagesaccess__update_page_access#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages_access/pagesaccess__update_page_access#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages_access/pagesaccess__update_page_access#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages_access/pagesaccess__update_page_access#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages_access/pagesaccess__update_page_access#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages_access/pagesaccess__update_page_access#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages_access/pagesaccess__update_page_access#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages_access/pagesaccess__update_page_access#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages_access/pagesaccess__update_page_access#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages_access/pagesaccess__update_page_access#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__clone_page -->

- [Request](en/api-ref/pages/pages__clone_page#request)
  - [Path parameters](en/api-ref/pages/pages__clone_page#path-parameters)
  - [Body](en/api-ref/pages/pages__clone_page#body)
- [Responses](en/api-ref/pages/pages__clone_page#responses)
- [200 OK](en/api-ref/pages/pages__clone_page#200-ok)
  - [Body](en/api-ref/pages/pages__clone_page#body1)
  - [B2BOperationType](en/api-ref/pages/pages__clone_page#entity-B2BOperationType)
  - [B2BOperationIdentity](en/api-ref/pages/pages__clone_page#entity-B2BOperationIdentity)

# Clone Page

Copies a page to a new address.

This is an asynchronous operation. If all checks pass, the response contains information on how to check the operation status.

Validation error codes (error\_code)

- `IS_CLOUD_PAGE`: cloud pages cannot be cloned
- `SLUG_OCCUPIED`: after cloning, the page conflicts with an existing page
- `SLUG_RESERVED`: cloning to reserved pages is not allowed
- `FORBIDDEN`: no access to the source page or to the cluster the page is being cloned into
- `QUOTA_EXCEEDED`: the page creation limit for the current organization has been reached
- `CLUSTER_BLOCKED`: the cluster is temporarily blocked for migration.

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}/clone
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Body

application/json

```
{
  "target": "example",
  "title": "example",
  "subscribe_me": false
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *target* | **Type**: string  The page slug after cloning  *Example:* `example` |
| *subscribe\_me* | **Type**: boolean  Subscribe to changes  *Default:* `false` |
| *title* | **Type**: string  If provided, the page title after cloning  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "operation": {
    "type": "clone",
    "id": "example"
  },
  "dry_run": false,
  "status_url": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *operation* | **Type**: [B2BOperationIdentity](en/api-ref/pages/pages__clone_page#entity-B2BOperationIdentity) **Example** ``` {   "type": "clone",   "id": "example" } ``` |
| *status\_url* | **Type**: string  The URL where the operation progress is returned  *Example:* `example` |
| *dry\_run* | **Type**: boolean  *Default:* `false` |

### B2BOperationType

An enumeration.

**Type**: string

*Enum:* `clone`, `clone_inline_grid`

### B2BOperationIdentity

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  *Example:* `example` |
| *type* | **Type**: [B2BOperationType](en/api-ref/pages/pages__clone_page#entity-B2BOperationType)  An enumeration.  *Enum:* `clone`, `clone_inline_grid` |

**Example**

```
{
  "type": "clone",
  "id": "example"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__append_content -->

- [Request](en/api-ref/pages/pages__append_content#request)
  - [Path parameters](en/api-ref/pages/pages__append_content#path-parameters)
  - [Query parameters](en/api-ref/pages/pages__append_content#query-parameters)
  - [Body](en/api-ref/pages/pages__append_content#body)
  - [Location](en/api-ref/pages/pages__append_content#entity-Location)
  - [PageAppendContentBodySchema](en/api-ref/pages/pages__append_content#entity-PageAppendContentBodySchema)
  - [PageAppendContentSectionSchema](en/api-ref/pages/pages__append_content#entity-PageAppendContentSectionSchema)
  - [PageAppendContentAnchorSchema](en/api-ref/pages/pages__append_content#entity-PageAppendContentAnchorSchema)
- [Responses](en/api-ref/pages/pages__append_content#responses)
- [200 OK](en/api-ref/pages/pages__append_content#200-ok)
  - [Body](en/api-ref/pages/pages__append_content#body1)
  - [PageType](en/api-ref/pages/pages__append_content#entity-PageType)
  - [PageDetailsSchema](en/api-ref/pages/pages__append_content#entity-PageDetailsSchema)
  - [RedirectSchema](en/api-ref/pages/pages__append_content#entity-RedirectSchema)
  - [BreadcrumbSchema](en/api-ref/pages/pages__append_content#entity-BreadcrumbSchema)
  - [PageAttributesSchema](en/api-ref/pages/pages__append_content#entity-PageAttributesSchema)
  - [PageAccessTypeAPI](en/api-ref/pages/pages__append_content#entity-PageAccessTypeAPI)
  - [AccessTypeInheritedAPI](en/api-ref/pages/pages__append_content#entity-AccessTypeInheritedAPI)
  - [RoleAllStaffAPI](en/api-ref/pages/pages__append_content#entity-RoleAllStaffAPI)
  - [PageInviteStatus](en/api-ref/pages/pages__append_content#entity-PageInviteStatus)
  - [AclPreviewInviteSchema](en/api-ref/pages/pages__append_content#entity-AclPreviewInviteSchema)
  - [PageAccessPolicySchema](en/api-ref/pages/pages__append_content#entity-PageAccessPolicySchema)
  - [UserIdentity](en/api-ref/pages/pages__append_content#entity-UserIdentity)
  - [UserSchema](en/api-ref/pages/pages__append_content#entity-UserSchema)
  - [ComSource](en/api-ref/pages/pages__append_content#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages/pages__append_content#entity-ComIdentitySchema)
  - [GroupType](en/api-ref/pages/pages__append_content#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages/pages__append_content#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages/pages__append_content#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages/pages__append_content#entity-GroupSchema)
  - [RoleAPI](en/api-ref/pages/pages__append_content#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages/pages__append_content#entity-InheritanceAPI)
  - [PageAccessItem](en/api-ref/pages/pages__append_content#entity-PageAccessItem)
  - [PageAccessListsSchema](en/api-ref/pages/pages__append_content#entity-PageAccessListsSchema)
  - [PageOwnerSchema](en/api-ref/pages/pages__append_content#entity-PageOwnerSchema)

# Append Content

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}/append-content
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *fields* | **Type**: string  *Example:* `` |
| *is\_silent* | **Type**: boolean  Do not send a page update notification to subscribers  *Default:* `false` |

### Body

application/json

```
{
  "content": "example",
  "body": {
    "location": "top"
  },
  "section": {
    "id": 0,
    "location": null
  },
  "anchor": {
    "name": "example",
    "fallback": false,
    "regex": false
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *content* | **Type**: string  *Min length:* `1`  *Example:* `example` |
| *anchor* | **Type**: [PageAppendContentAnchorSchema](en/api-ref/pages/pages__append_content#entity-PageAppendContentAnchorSchema) **Example** ``` {   "name": "example",   "fallback": false,   "regex": false } ``` |
| *body* | **Type**: [PageAppendContentBodySchema](en/api-ref/pages/pages__append_content#entity-PageAppendContentBodySchema) **Example** ``` {   "location": "top" } ``` |
| *section* | **Type**: [PageAppendContentSectionSchema](en/api-ref/pages/pages__append_content#entity-PageAppendContentSectionSchema) **Example** ``` {   "id": 0,   "location": "top" } ``` |

### Location

An enumeration.

**Type**: string

*Enum:* `top`, `bottom`

### PageAppendContentBodySchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *location* | **Type**: [Location](en/api-ref/pages/pages__append_content#entity-Location)  An enumeration.  *Enum:* `top`, `bottom` |

**Example**

```
{
  "location": "top"
}
```

### PageAppendContentSectionSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer |
| *location* | **Type**: [Location](en/api-ref/pages/pages__append_content#entity-Location)  An enumeration.  *Enum:* `top`, `bottom` |

**Example**

```
{
  "id": 0,
  "location": "top"
}
```

### PageAppendContentAnchorSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *name* | **Type**: string  *Example:* `example` |
| *fallback* | **Type**: boolean  *Default:* `false` |
| *regex* | **Type**: boolean  *Default:* `false` |

**Example**

```
{
  "name": "example",
  "fallback": false,
  "regex": false
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page",
  "redirect": {
    "page_id": 0,
    "redirect_target": {
      "id": 0,
      "slug": "example",
      "title": "example",
      "page_type": null
    }
  },
  "breadcrumbs": [
    {
      "id": 0,
      "title": "example",
      "slug": "example",
      "page_exists": true
    }
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z",
    "lang": "example",
    "is_readonly": true,
    "comments_count": 0,
    "comments_enabled": true,
    "keywords": [
      "example"
    ],
    "is_collaborative": true,
    "is_draft": true
  },
  "content": "example",
  "access_policy": {
    "access_type": "inherited",
    "inherited_access_type": "all_staff",
    "all_staff_role": "reader",
    "has_external": true,
    "invite": {
      "status": null
    }
  },
  "access_lists": {
    "direct": [
      {
        "id": "example",
        "created_at": "2025-01-01T00:00:00Z",
        "user": null,
        "group": null,
        "role": null,
        "inheritance": null
      }
    ],
    "by_link": [
      null
    ],
    "inherited": [
      null
    ]
  },
  "owner": {
    "user": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "group": {
      "id": "example",
      "identity": null,
      "name": "example",
      "type": null,
      "metadata": null,
      "members_count": 0
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Unique page identifier |
| *page\_type* | **Type**: string  Page type  *Enum:* `page`, `grid`, `wysiwyg`, `template` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *access\_lists* | **All of 1 type** - **PageAccessListsSchema**  **Type**: [PageAccessListsSchema](en/api-ref/pages/pages__append_content#entity-PageAccessListsSchema)  Page access lists **Example** ```   {     "direct": [       {         "id": "example",         "created_at": "2025-01-01T00:00:00Z",         "user": {           "id": 0,           "identity": null,           "username": "example",           "display_name": "example",           "is_dismissed": true,           "affiliation": "example"         },         "group": {           "id": "example",           "identity": null,           "name": "example",           "type": null,           "metadata": null,           "members_count": 0         },         "role": "reader",         "inheritance": "inherited"       }     ],     "by_link": [       null     ],     "inherited": [       null     ]   }   ```  **Not returned by default**  Specify `access_lists` in the `?fields=access_lists, ...` list to include it in the response.  The page access lists **Example** ``` {   "direct": [     {       "id": "example",       "created_at": "2025-01-01T00:00:00Z",       "user": null,       "group": null,       "role": "reader",       "inheritance": "inherited"     }   ],   "by_link": [     null   ],   "inherited": [     null   ] } ``` |
| *access\_policy* | **All of 1 type** - **PageAccessPolicySchema**  **Type**: [PageAccessPolicySchema](en/api-ref/pages/pages__append_content#entity-PageAccessPolicySchema)  Page access policy **Example** ```   {     "access_type": "inherited",     "inherited_access_type": "all_staff",     "all_staff_role": "reader",     "has_external": true,     "invite": {       "status": 0     }   }   ```  **Not returned by default**  Specify `access_policy` in the `?fields=access_policy, ...` list to include it in the response.  The page access settings **Example** ``` {   "access_type": "inherited",   "inherited_access_type": "all_staff",   "all_staff_role": "reader",   "has_external": true,   "invite": {     "status": 0   } } ``` |
| *attributes* | **All of 1 type** - **PageAttributesSchema**  **Type**: [PageAttributesSchema](en/api-ref/pages/pages__append_content#entity-PageAttributesSchema)  Additional page attributes **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z",     "lang": "example",     "is_readonly": true,     "comments_count": 0,     "comments_enabled": true,     "keywords": [       "example"     ],     "is_collaborative": true,     "is_draft": true   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z",   "lang": "example",   "is_readonly": true,   "comments_count": 0,   "comments_enabled": true,   "keywords": [     "example"   ],   "is_collaborative": true,   "is_draft": true } ``` |
| *breadcrumbs* | **Type**: [BreadcrumbSchema](en/api-ref/pages/pages__append_content#entity-BreadcrumbSchema)[]  **Not returned by default**  Specify `breadcrumbs` in the `?fields=breadcrumbs, ...` list to include it in the response. **Example** ``` [   {     "id": 0,     "title": "example",     "slug": "example",     "page_exists": true   } ] ``` |
| *content* | **Type**: string  **Not returned by default**  Specify `content` in the `?fields=content, ...` list to include it in the response.  The page content as a string.  *Example:* `example` |
| *owner* | **All of 1 type** - **PageOwnerSchema**  **Type**: [PageOwnerSchema](en/api-ref/pages/pages__append_content#entity-PageOwnerSchema)  Page owner **Example** ```   {     "user": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": {         "src": null,         "id": "example"       },       "name": "example",       "type": "wiki",       "metadata": {         "url": "example",         "externals_count": 0       },       "members_count": 0     }   }   ```  **Not returned by default**  Specify `owner` in the `?fields=owner, ...` list to include it in the response.  The page owner **Example** ``` {   "user": {     "id": 0,     "identity": null,     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "group": {     "id": "example",     "identity": null,     "name": "example",     "type": "wiki",     "metadata": {},     "members_count": 0   } } ``` |
| *redirect* | **All of 1 type** - **RedirectSchema**  **Type**: [RedirectSchema](en/api-ref/pages/pages__append_content#entity-RedirectSchema)  Information about the page redirect **Example** ```   {     "page_id": 0,     "redirect_target": {       "id": 0,       "slug": "example",       "title": "example",       "page_type": "page"     }   }   ```  **Not returned by default**  Specify `redirect` in the `?fields=redirect, ...` list to include it in the response.  If no redirect is set, `null` is returned **Example** ``` {   "page_id": 0,   "redirect_target": {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   } } ``` |

### PageType

Page type:

- `page` — a regular page
- `grid` — a page with a table
- `cloud_page` — a cloud page
- `wysiwyg` — a page with the visual editor
- `template` — a page template

**Type**: string

*Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`

### PageDetailsSchema

Brief information about the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID |
| *page\_type* | **All of 1 type** - **PageType**  **Type**: [PageType](en/api-ref/pages/pages__append_content#entity-PageType)  Page type:    - `page` — a regular page   - `grid` — a page with a table   - `cloud_page` — a cloud page   - `wysiwyg` — a page with the visual editor   - `template` — a page template *Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`  Page type  *Example:* `page` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page"
}
```

### RedirectSchema

Information about the page redirect

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_id* | **Type**: integer  The ID of the page that the current page redirects to. |
| *redirect\_target* | **All of 1 type** - **PageDetailsSchema**  **Type**: [PageDetailsSchema](en/api-ref/pages/pages__append_content#entity-PageDetailsSchema)  Brief information about the page **Example** ```   {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   }   ```  For example, given a redirect chain A->B->C->D, for A, B, and C this will be page D **Example** ``` {   "id": 0,   "slug": "example",   "title": "example",   "page_type": "page" } ``` |

**Example**

```
{
  "page_id": 0,
  "redirect_target": {
    "id": 0,
    "slug": "example",
    "title": "example",
    "page_type": "page"
  }
}
```

### BreadcrumbSchema

A breadcrumb item (navigation trail)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_exists* | **Type**: boolean  Whether the page exists |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *id* | **Type**: integer  Page ID (if the page exists) |

**Example**

```
{
  "id": 0,
  "title": "example",
  "slug": "example",
  "page_exists": true
}
```

### PageAttributesSchema

Additional page attributes

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comments\_count* | **Type**: integer  Number of comments on the page |
| *comments\_enabled* | **Type**: boolean  Comments are enabled |
| *created\_at* | **Type**: string<date-time>  Date and time the page was created  *Example:* `2025-01-01T00:00:00Z` |
| *is\_readonly* | **Type**: boolean  The page is read-only |
| *lang* | **Type**: string  Page language (for example, `ru`, `en`)  *Example:* `example` |
| *modified\_at* | **Type**: string<date-time>  Date and time the page was last modified  *Example:* `2025-01-01T00:00:00Z` |
| *is\_collaborative* | **Type**: boolean  Collaborative editing is enabled |
| *is\_draft* | **Type**: boolean  The page is a draft |
| *keywords* | **Type**: string[]  Page keywords **Example** ``` [   "example" ] ``` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z",
  "lang": "example",
  "is_readonly": true,
  "comments_count": 0,
  "comments_enabled": true,
  "keywords": [
    "example"
  ],
  "is_collaborative": true,
  "is_draft": true
}
```

### PageAccessTypeAPI

Page access type:

- `inherited` — inherited from the parent page
- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `inherited`, `all_staff`, `custom`

### AccessTypeInheritedAPI

Inherited access type:

- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `all_staff`, `custom`

### RoleAllStaffAPI

Role for "all staff members" access:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`

### PageInviteStatus

Invitation link status:

- `0` — deleted
- `1` — enabled
- `2` — disabled

**Type**: integer

*Enum:* `0`, `1`, `2`

### AclPreviewInviteSchema

Information about the invitation link for page access

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **All of 1 type** - **PageInviteStatus**  **Type**: [PageInviteStatus](en/api-ref/pages/pages__append_content#entity-PageInviteStatus)  Invitation link status:    - `0` — deleted   - `1` — enabled   - `2` — disabled *Enum:* `0`, `1`, `2`  *Example:* `0`  Link status:   - 0 - deleted (not returned by the API) - 1 - enabled - 2 - disabled   *Example:* `0` |

**Example**

```
{
  "status": 0
}
```

### PageAccessPolicySchema

Page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__append_content#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__append_content#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access  *Example:* `reader` |
| *has\_external* | **Type**: boolean  Indicates that the page is accessible to external consultants. If None, the status is unknown |
| *inherited\_access\_type* | **All of 1 type** - **AccessTypeInheritedAPI**  **Type**: [AccessTypeInheritedAPI](en/api-ref/pages/pages__append_content#entity-AccessTypeInheritedAPI)  Inherited access type:    - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `all_staff`, `custom`  Inherited access type  *Example:* `all_staff` |
| *invite* | **All of 1 type** - **AclPreviewInviteSchema**  **Type**: [AclPreviewInviteSchema](en/api-ref/pages/pages__append_content#entity-AclPreviewInviteSchema)  Information about the invitation link for page access **Example** ```   {     "status": 0   }   ```  Information about the invitation link for page access **Example** ``` {   "status": 0 } ``` |

**Example**

```
{
  "access_type": "inherited",
  "inherited_access_type": "all_staff",
  "all_staff_role": "reader",
  "has_external": true,
  "invite": {
    "status": 0
  }
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages/pages__append_content#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages/pages__append_content#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages/pages__append_content#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages/pages__append_content#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages/pages__append_content#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages/pages__append_content#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

### PageAccessItem

A personal page access item

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages/pages__append_content#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__append_content#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages/pages__append_content#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__append_content#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

### PageAccessListsSchema

Page access lists

|  |  |
| --- | --- |
| **Name** | **Description** |
| *by\_link* | **Type**: [PageAccessItem](en/api-ref/pages/pages__append_content#entity-PageAccessItem)[]  Accesses via the invitation link **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *direct* | **Type**: [PageAccessItem](en/api-ref/pages/pages__append_content#entity-PageAccessItem)[]  Direct personal accesses to the page **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *inherited* | **Type**: [PageAccessItem](en/api-ref/pages/pages__append_content#entity-PageAccessItem)[]  Accesses inherited from parent pages **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |

**Example**

```
{
  "direct": [
    {
      "id": "example",
      "created_at": "2025-01-01T00:00:00Z",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "group": {
        "id": "example",
        "identity": null,
        "name": "example",
        "type": null,
        "metadata": null,
        "members_count": 0
      },
      "role": "reader",
      "inheritance": "inherited"
    }
  ],
  "by_link": [
    null
  ],
  "inherited": [
    null
  ]
}
```

### PageOwnerSchema

Page owner

|  |  |
| --- | --- |
| **Name** | **Description** |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__append_content#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  **(not implemented)** The group that owns the page **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__append_content#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who owns the page **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages_access/pagesaccess__delete_page_access -->

- [Request](en/api-ref/pages_access/pagesaccess__delete_page_access#request)
  - [Path parameters](en/api-ref/pages_access/pagesaccess__delete_page_access#path-parameters)
  - [Query parameters](en/api-ref/pages_access/pagesaccess__delete_page_access#query-parameters)
- [Responses](en/api-ref/pages_access/pagesaccess__delete_page_access#responses)
- [204 No Content](en/api-ref/pages_access/pagesaccess__delete_page_access#204-no-content)
  - [Body](en/api-ref/pages_access/pagesaccess__delete_page_access#body)

# Delete user/group access to a page

Deletes a specific personal access to a page by its identifier.

Use the `prevent_selflock=true` parameter to prevent accidentally locking the current user out of access.

## Request

DELETE

```
https://api.wiki.yandex.net/v1/pages/{idx}/access/{access_id}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_id* | **Type**: string  Access ID  *Example:* `` |
| *idx* | **Type**: integer  Page ID |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *prevent\_selflock* | **Type**: boolean  If `true`, an error is raised when deleting an access would cause the co-author to lose read access or access management permissions  *Default:* `false` |

## Responses

## 204 No Content

No Content

### Body

application/json

```
{}
```

|  |  |
| --- | --- |
| **Name** | **Description** |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__delete_page -->

- [Request](en/api-ref/pages/pages__delete_page#request)
  - [Path parameters](en/api-ref/pages/pages__delete_page#path-parameters)
  - [Query parameters](en/api-ref/pages/pages__delete_page#query-parameters)
- [Responses](en/api-ref/pages/pages__delete_page#responses)
- [200 OK](en/api-ref/pages/pages__delete_page#200-ok)
  - [Body](en/api-ref/pages/pages__delete_page#body)

# Delete Page

Deletes a page.

The response contains a `recovery_token` parameter that you can use to restore the page with the [Recover Page By Token](en/api-ref/recovery_tokens/recovery_tokens__recover_page_by_token) method.

## Request

DELETE

```
https://api.wiki.yandex.net/v1/pages/{idx}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *recursive* | **Type**: boolean  *Default:* `false` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "recovery_token": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *recovery\_token* | **Type**: string<uuid4>  *Example:* `example` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages_access/pagesaccess__create_page_access -->

- [Request](en/api-ref/pages_access/pagesaccess__create_page_access#request)
  - [Path parameters](en/api-ref/pages_access/pagesaccess__create_page_access#path-parameters)
  - [Body](en/api-ref/pages_access/pagesaccess__create_page_access#body)
  - [UserIdentity](en/api-ref/pages_access/pagesaccess__create_page_access#entity-UserIdentity)
  - [ComSource](en/api-ref/pages_access/pagesaccess__create_page_access#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-ComIdentitySchema)
  - [RoleAPI](en/api-ref/pages_access/pagesaccess__create_page_access#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages_access/pagesaccess__create_page_access#entity-InheritanceAPI)
- [Responses](en/api-ref/pages_access/pagesaccess__create_page_access#responses)
- [200 OK](en/api-ref/pages_access/pagesaccess__create_page_access#200-ok)
  - [Body](en/api-ref/pages_access/pagesaccess__create_page_access#body1)
  - [UserSchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-UserSchema)
  - [GroupType](en/api-ref/pages_access/pagesaccess__create_page_access#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages_access/pagesaccess__create_page_access#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages_access/pagesaccess__create_page_access#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-GroupSchema)

# Add user/group access to a page

Adds personal access to a page for the specified user or group.

Lets you grant access with one of the following roles:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}/access
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer  Page ID |

### Body

application/json

```
{
  "user": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "group": {
    "src": "dir",
    "id": "example"
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages_access/pagesaccess__create_page_access#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role: `reader` (read), `editor` (edit), `extra_editor` (extended editing), `author` (author)  *Example:* `reader` |
| *group* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  The identifier of the group to grant access to. Specify either `user` or `group` **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages_access/pagesaccess__create_page_access#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance for subpages: `inherited` (inherited), `not_inherited` (not inherited)  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages_access/pagesaccess__create_page_access#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  The identifier of the user to grant access to. Specify either `user` or `group` **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages_access/pagesaccess__create_page_access#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages_access/pagesaccess__create_page_access#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages_access/pagesaccess__create_page_access#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages_access/pagesaccess__create_page_access#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages_access/pagesaccess__create_page_access#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages_access/pagesaccess__create_page_access#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages_access/pagesaccess__create_page_access#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages_access/pagesaccess__create_page_access#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__get_page_details_by_id -->

- [Request](en/api-ref/pages/pages__get_page_details_by_id#request)
  - [Path parameters](en/api-ref/pages/pages__get_page_details_by_id#path-parameters)
  - [Query parameters](en/api-ref/pages/pages__get_page_details_by_id#query-parameters)
- [Responses](en/api-ref/pages/pages__get_page_details_by_id#responses)
- [200 OK](en/api-ref/pages/pages__get_page_details_by_id#200-ok)
  - [Body](en/api-ref/pages/pages__get_page_details_by_id#body)
  - [PageType](en/api-ref/pages/pages__get_page_details_by_id#entity-PageType)
  - [PageDetailsSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageDetailsSchema)
  - [RedirectSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-RedirectSchema)
  - [BreadcrumbSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-BreadcrumbSchema)
  - [PageAttributesSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAttributesSchema)
  - [PageAccessTypeAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessTypeAPI)
  - [AccessTypeInheritedAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-AccessTypeInheritedAPI)
  - [RoleAllStaffAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-RoleAllStaffAPI)
  - [PageInviteStatus](en/api-ref/pages/pages__get_page_details_by_id#entity-PageInviteStatus)
  - [AclPreviewInviteSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-AclPreviewInviteSchema)
  - [PageAccessPolicySchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessPolicySchema)
  - [UserIdentity](en/api-ref/pages/pages__get_page_details_by_id#entity-UserIdentity)
  - [UserSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-UserSchema)
  - [ComSource](en/api-ref/pages/pages__get_page_details_by_id#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages/pages__get_page_details_by_id#entity-ComIdentitySchema)
  - [GroupType](en/api-ref/pages/pages__get_page_details_by_id#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages/pages__get_page_details_by_id#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages/pages__get_page_details_by_id#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-GroupSchema)
  - [RoleAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-InheritanceAPI)
  - [PageAccessItem](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessItem)
  - [PageAccessListsSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessListsSchema)
  - [PageOwnerSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageOwnerSchema)

# Get Page Details By Id

Returns page details:

- `fields` — the additional response blocks to include; see the response format description
- `follow_redirects` — if the page has a redirect set, the request is redirected to the details of the target page

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *fields* | **Type**: string  *Example:* `` |
| *raise\_on\_redirect* | **Type**: boolean  *Default:* `false` |
| *revision\_id* | **Type**: integer |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page",
  "redirect": {
    "page_id": 0,
    "redirect_target": {
      "id": 0,
      "slug": "example",
      "title": "example",
      "page_type": null
    }
  },
  "breadcrumbs": [
    {
      "id": 0,
      "title": "example",
      "slug": "example",
      "page_exists": true
    }
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z",
    "lang": "example",
    "is_readonly": true,
    "comments_count": 0,
    "comments_enabled": true,
    "keywords": [
      "example"
    ],
    "is_collaborative": true,
    "is_draft": true
  },
  "content": "example",
  "access_policy": {
    "access_type": "inherited",
    "inherited_access_type": "all_staff",
    "all_staff_role": "reader",
    "has_external": true,
    "invite": {
      "status": null
    }
  },
  "access_lists": {
    "direct": [
      {
        "id": "example",
        "created_at": "2025-01-01T00:00:00Z",
        "user": null,
        "group": null,
        "role": null,
        "inheritance": null
      }
    ],
    "by_link": [
      null
    ],
    "inherited": [
      null
    ]
  },
  "owner": {
    "user": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "group": {
      "id": "example",
      "identity": null,
      "name": "example",
      "type": null,
      "metadata": null,
      "members_count": 0
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Unique page identifier |
| *page\_type* | **Type**: string  Page type  *Enum:* `page`, `grid`, `wysiwyg`, `template` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *access\_lists* | **All of 1 type** - **PageAccessListsSchema**  **Type**: [PageAccessListsSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessListsSchema)  Page access lists **Example** ```   {     "direct": [       {         "id": "example",         "created_at": "2025-01-01T00:00:00Z",         "user": {           "id": 0,           "identity": null,           "username": "example",           "display_name": "example",           "is_dismissed": true,           "affiliation": "example"         },         "group": {           "id": "example",           "identity": null,           "name": "example",           "type": null,           "metadata": null,           "members_count": 0         },         "role": "reader",         "inheritance": "inherited"       }     ],     "by_link": [       null     ],     "inherited": [       null     ]   }   ```  **Not returned by default**  Specify `access_lists` in the `?fields=access_lists, ...` list to include it in the response.  The page access lists **Example** ``` {   "direct": [     {       "id": "example",       "created_at": "2025-01-01T00:00:00Z",       "user": null,       "group": null,       "role": "reader",       "inheritance": "inherited"     }   ],   "by_link": [     null   ],   "inherited": [     null   ] } ``` |
| *access\_policy* | **All of 1 type** - **PageAccessPolicySchema**  **Type**: [PageAccessPolicySchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessPolicySchema)  Page access policy **Example** ```   {     "access_type": "inherited",     "inherited_access_type": "all_staff",     "all_staff_role": "reader",     "has_external": true,     "invite": {       "status": 0     }   }   ```  **Not returned by default**  Specify `access_policy` in the `?fields=access_policy, ...` list to include it in the response.  The page access settings **Example** ``` {   "access_type": "inherited",   "inherited_access_type": "all_staff",   "all_staff_role": "reader",   "has_external": true,   "invite": {     "status": 0   } } ``` |
| *attributes* | **All of 1 type** - **PageAttributesSchema**  **Type**: [PageAttributesSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAttributesSchema)  Additional page attributes **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z",     "lang": "example",     "is_readonly": true,     "comments_count": 0,     "comments_enabled": true,     "keywords": [       "example"     ],     "is_collaborative": true,     "is_draft": true   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z",   "lang": "example",   "is_readonly": true,   "comments_count": 0,   "comments_enabled": true,   "keywords": [     "example"   ],   "is_collaborative": true,   "is_draft": true } ``` |
| *breadcrumbs* | **Type**: [BreadcrumbSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-BreadcrumbSchema)[]  **Not returned by default**  Specify `breadcrumbs` in the `?fields=breadcrumbs, ...` list to include it in the response. **Example** ``` [   {     "id": 0,     "title": "example",     "slug": "example",     "page_exists": true   } ] ``` |
| *content* | **Type**: string  **Not returned by default**  Specify `content` in the `?fields=content, ...` list to include it in the response.  The page content as a string.  *Example:* `example` |
| *owner* | **All of 1 type** - **PageOwnerSchema**  **Type**: [PageOwnerSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageOwnerSchema)  Page owner **Example** ```   {     "user": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": {         "src": null,         "id": "example"       },       "name": "example",       "type": "wiki",       "metadata": {         "url": "example",         "externals_count": 0       },       "members_count": 0     }   }   ```  **Not returned by default**  Specify `owner` in the `?fields=owner, ...` list to include it in the response.  The page owner **Example** ``` {   "user": {     "id": 0,     "identity": null,     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "group": {     "id": "example",     "identity": null,     "name": "example",     "type": "wiki",     "metadata": {},     "members_count": 0   } } ``` |
| *redirect* | **All of 1 type** - **RedirectSchema**  **Type**: [RedirectSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-RedirectSchema)  Information about the page redirect **Example** ```   {     "page_id": 0,     "redirect_target": {       "id": 0,       "slug": "example",       "title": "example",       "page_type": "page"     }   }   ```  **Not returned by default**  Specify `redirect` in the `?fields=redirect, ...` list to include it in the response.  If no redirect is set, `null` is returned **Example** ``` {   "page_id": 0,   "redirect_target": {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   } } ``` |

### PageType

Page type:

- `page` — a regular page
- `grid` — a page with a table
- `cloud_page` — a cloud page
- `wysiwyg` — a page with the visual editor
- `template` — a page template

**Type**: string

*Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`

### PageDetailsSchema

Brief information about the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID |
| *page\_type* | **All of 1 type** - **PageType**  **Type**: [PageType](en/api-ref/pages/pages__get_page_details_by_id#entity-PageType)  Page type:    - `page` — a regular page   - `grid` — a page with a table   - `cloud_page` — a cloud page   - `wysiwyg` — a page with the visual editor   - `template` — a page template *Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`  Page type  *Example:* `page` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page"
}
```

### RedirectSchema

Information about the page redirect

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_id* | **Type**: integer  The ID of the page that the current page redirects to. |
| *redirect\_target* | **All of 1 type** - **PageDetailsSchema**  **Type**: [PageDetailsSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-PageDetailsSchema)  Brief information about the page **Example** ```   {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   }   ```  For example, given a redirect chain A->B->C->D, for A, B, and C this will be page D **Example** ``` {   "id": 0,   "slug": "example",   "title": "example",   "page_type": "page" } ``` |

**Example**

```
{
  "page_id": 0,
  "redirect_target": {
    "id": 0,
    "slug": "example",
    "title": "example",
    "page_type": "page"
  }
}
```

### BreadcrumbSchema

A breadcrumb item (navigation trail)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_exists* | **Type**: boolean  Whether the page exists |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *id* | **Type**: integer  Page ID (if the page exists) |

**Example**

```
{
  "id": 0,
  "title": "example",
  "slug": "example",
  "page_exists": true
}
```

### PageAttributesSchema

Additional page attributes

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comments\_count* | **Type**: integer  Number of comments on the page |
| *comments\_enabled* | **Type**: boolean  Comments are enabled |
| *created\_at* | **Type**: string<date-time>  Date and time the page was created  *Example:* `2025-01-01T00:00:00Z` |
| *is\_readonly* | **Type**: boolean  The page is read-only |
| *lang* | **Type**: string  Page language (for example, `ru`, `en`)  *Example:* `example` |
| *modified\_at* | **Type**: string<date-time>  Date and time the page was last modified  *Example:* `2025-01-01T00:00:00Z` |
| *is\_collaborative* | **Type**: boolean  Collaborative editing is enabled |
| *is\_draft* | **Type**: boolean  The page is a draft |
| *keywords* | **Type**: string[]  Page keywords **Example** ``` [   "example" ] ``` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z",
  "lang": "example",
  "is_readonly": true,
  "comments_count": 0,
  "comments_enabled": true,
  "keywords": [
    "example"
  ],
  "is_collaborative": true,
  "is_draft": true
}
```

### PageAccessTypeAPI

Page access type:

- `inherited` — inherited from the parent page
- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `inherited`, `all_staff`, `custom`

### AccessTypeInheritedAPI

Inherited access type:

- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `all_staff`, `custom`

### RoleAllStaffAPI

Role for "all staff members" access:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`

### PageInviteStatus

Invitation link status:

- `0` — deleted
- `1` — enabled
- `2` — disabled

**Type**: integer

*Enum:* `0`, `1`, `2`

### AclPreviewInviteSchema

Information about the invitation link for page access

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **All of 1 type** - **PageInviteStatus**  **Type**: [PageInviteStatus](en/api-ref/pages/pages__get_page_details_by_id#entity-PageInviteStatus)  Invitation link status:    - `0` — deleted   - `1` — enabled   - `2` — disabled *Enum:* `0`, `1`, `2`  *Example:* `0`  Link status:   - 0 - deleted (not returned by the API) - 1 - enabled - 2 - disabled   *Example:* `0` |

**Example**

```
{
  "status": 0
}
```

### PageAccessPolicySchema

Page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access  *Example:* `reader` |
| *has\_external* | **Type**: boolean  Indicates that the page is accessible to external consultants. If None, the status is unknown |
| *inherited\_access\_type* | **All of 1 type** - **AccessTypeInheritedAPI**  **Type**: [AccessTypeInheritedAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-AccessTypeInheritedAPI)  Inherited access type:    - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `all_staff`, `custom`  Inherited access type  *Example:* `all_staff` |
| *invite* | **All of 1 type** - **AclPreviewInviteSchema**  **Type**: [AclPreviewInviteSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-AclPreviewInviteSchema)  Information about the invitation link for page access **Example** ```   {     "status": 0   }   ```  Information about the invitation link for page access **Example** ``` {   "status": 0 } ``` |

**Example**

```
{
  "access_type": "inherited",
  "inherited_access_type": "all_staff",
  "all_staff_role": "reader",
  "has_external": true,
  "invite": {
    "status": 0
  }
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages/pages__get_page_details_by_id#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages/pages__get_page_details_by_id#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages/pages__get_page_details_by_id#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages/pages__get_page_details_by_id#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages/pages__get_page_details_by_id#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages/pages__get_page_details_by_id#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

### PageAccessItem

A personal page access item

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages/pages__get_page_details_by_id#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

### PageAccessListsSchema

Page access lists

|  |  |
| --- | --- |
| **Name** | **Description** |
| *by\_link* | **Type**: [PageAccessItem](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessItem)[]  Accesses via the invitation link **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *direct* | **Type**: [PageAccessItem](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessItem)[]  Direct personal accesses to the page **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *inherited* | **Type**: [PageAccessItem](en/api-ref/pages/pages__get_page_details_by_id#entity-PageAccessItem)[]  Accesses inherited from parent pages **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |

**Example**

```
{
  "direct": [
    {
      "id": "example",
      "created_at": "2025-01-01T00:00:00Z",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "group": {
        "id": "example",
        "identity": null,
        "name": "example",
        "type": null,
        "metadata": null,
        "members_count": 0
      },
      "role": "reader",
      "inheritance": "inherited"
    }
  ],
  "by_link": [
    null
  ],
  "inherited": [
    null
  ]
}
```

### PageOwnerSchema

Page owner

|  |  |
| --- | --- |
| **Name** | **Description** |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  **(not implemented)** The group that owns the page **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__get_page_details_by_id#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who owns the page **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__descendants_by_id -->

- [Request](en/api-ref/pages/pages__descendants_by_id#request)
  - [Path parameters](en/api-ref/pages/pages__descendants_by_id#path-parameters)
  - [Query parameters](en/api-ref/pages/pages__descendants_by_id#query-parameters)
- [Responses](en/api-ref/pages/pages__descendants_by_id#responses)
- [200 OK](en/api-ref/pages/pages__descendants_by_id#200-ok)
  - [Body](en/api-ref/pages/pages__descendants_by_id#body)
  - [PageSchema](en/api-ref/pages/pages__descendants_by_id#entity-PageSchema)

# Get Page Descendants

Returns all subpages (at all levels, not just the first level) of the given page that are accessible to the current user.  
The response may contain fewer results than page\_size, depending on how many pages the user has access to.

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/descendants
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *actuality* | **Type**: string  An enumeration.  *Enum:* `actual`, `obsolete` |
| *cursor* | **Type**: string  *Example:* `` |
| *include\_self* | **Type**: boolean  Include the current page in the response  *Default:* `false` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": 0,
      "slug": "example"
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *results* | **Type**: [PageSchema](en/api-ref/pages/pages__descendants_by_id#entity-PageSchema)[] **Example** ``` [   {     "id": 0,     "slug": "example"   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### PageSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer |
| *slug* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/upload_sessions/upload_sessions__abort_all -->

- [Request](en/api-ref/upload_sessions/upload_sessions__abort_all#request)
- [Responses](en/api-ref/upload_sessions/upload_sessions__abort_all#responses)
- [200 OK](en/api-ref/upload_sessions/upload_sessions__abort_all#200-ok)
  - [Body](en/api-ref/upload_sessions/upload_sessions__abort_all#body)

# Abort All

Cancel all of the user's active file upload sessions to free up quota

## Request

POST

```
https://api.wiki.yandex.net/v1/upload_sessions/abort_active_uploads
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "status": "ok"
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **Type**: string  *Default:* `ok` |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages_access/pagesaccess__delete_page_accesses -->

- [Request](en/api-ref/pages_access/pagesaccess__delete_page_accesses#request)
  - [Path parameters](en/api-ref/pages_access/pagesaccess__delete_page_accesses#path-parameters)
  - [Query parameters](en/api-ref/pages_access/pagesaccess__delete_page_accesses#query-parameters)
- [Responses](en/api-ref/pages_access/pagesaccess__delete_page_accesses#responses)
- [204 No Content](en/api-ref/pages_access/pagesaccess__delete_page_accesses#204-no-content)
  - [Body](en/api-ref/pages_access/pagesaccess__delete_page_accesses#body)

# Delete all personal page accesses

Deletes all personal page accesses.

Use the `prevent_selflock=true` parameter to prevent accidentally locking the current user out of access.

## Request

DELETE

```
https://api.wiki.yandex.net/v1/pages/{idx}/access
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer  Page ID |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *prevent\_selflock* | **Type**: boolean  If `true`, an error is raised when deleting an access would cause the co-author to lose read access or access management permissions  *Default:* `false` |

## Responses

## 204 No Content

No Content

### Body

application/json

```
{}
```

|  |  |
| --- | --- |
| **Name** | **Description** |


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__get_page_details -->

- [Request](en/api-ref/pages/pages__get_page_details#request)
  - [Query parameters](en/api-ref/pages/pages__get_page_details#query-parameters)
- [Responses](en/api-ref/pages/pages__get_page_details#responses)
- [200 OK](en/api-ref/pages/pages__get_page_details#200-ok)
  - [Body](en/api-ref/pages/pages__get_page_details#body)
  - [PageType](en/api-ref/pages/pages__get_page_details#entity-PageType)
  - [PageDetailsSchema](en/api-ref/pages/pages__get_page_details#entity-PageDetailsSchema)
  - [RedirectSchema](en/api-ref/pages/pages__get_page_details#entity-RedirectSchema)
  - [BreadcrumbSchema](en/api-ref/pages/pages__get_page_details#entity-BreadcrumbSchema)
  - [PageAttributesSchema](en/api-ref/pages/pages__get_page_details#entity-PageAttributesSchema)
  - [PageAccessTypeAPI](en/api-ref/pages/pages__get_page_details#entity-PageAccessTypeAPI)
  - [AccessTypeInheritedAPI](en/api-ref/pages/pages__get_page_details#entity-AccessTypeInheritedAPI)
  - [RoleAllStaffAPI](en/api-ref/pages/pages__get_page_details#entity-RoleAllStaffAPI)
  - [PageInviteStatus](en/api-ref/pages/pages__get_page_details#entity-PageInviteStatus)
  - [AclPreviewInviteSchema](en/api-ref/pages/pages__get_page_details#entity-AclPreviewInviteSchema)
  - [PageAccessPolicySchema](en/api-ref/pages/pages__get_page_details#entity-PageAccessPolicySchema)
  - [UserIdentity](en/api-ref/pages/pages__get_page_details#entity-UserIdentity)
  - [UserSchema](en/api-ref/pages/pages__get_page_details#entity-UserSchema)
  - [ComSource](en/api-ref/pages/pages__get_page_details#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages/pages__get_page_details#entity-ComIdentitySchema)
  - [GroupType](en/api-ref/pages/pages__get_page_details#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages/pages__get_page_details#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages/pages__get_page_details#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages/pages__get_page_details#entity-GroupSchema)
  - [RoleAPI](en/api-ref/pages/pages__get_page_details#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages/pages__get_page_details#entity-InheritanceAPI)
  - [PageAccessItem](en/api-ref/pages/pages__get_page_details#entity-PageAccessItem)
  - [PageAccessListsSchema](en/api-ref/pages/pages__get_page_details#entity-PageAccessListsSchema)
  - [PageOwnerSchema](en/api-ref/pages/pages__get_page_details#entity-PageOwnerSchema)

# Get Page Details

Returns page details.

- `slug` — the non-normalized page slug, for example users/something/abc
- `fields` — the additional response blocks to include, comma-separated; see the response format description
- `raise_on_redirect` — if the page has a redirect set, an error is returned

## Request

GET

```
https://api.wiki.yandex.net/v1/pages
```

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *slug* | **Type**: string  *Example:* `` |
| *fields* | **Type**: string  *Example:* `` |
| *raise\_on\_redirect* | **Type**: boolean  *Default:* `false` |
| *revision\_id* | **Type**: integer |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page",
  "redirect": {
    "page_id": 0,
    "redirect_target": {
      "id": 0,
      "slug": "example",
      "title": "example",
      "page_type": null
    }
  },
  "breadcrumbs": [
    {
      "id": 0,
      "title": "example",
      "slug": "example",
      "page_exists": true
    }
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z",
    "lang": "example",
    "is_readonly": true,
    "comments_count": 0,
    "comments_enabled": true,
    "keywords": [
      "example"
    ],
    "is_collaborative": true,
    "is_draft": true
  },
  "content": "example",
  "access_policy": {
    "access_type": "inherited",
    "inherited_access_type": "all_staff",
    "all_staff_role": "reader",
    "has_external": true,
    "invite": {
      "status": null
    }
  },
  "access_lists": {
    "direct": [
      {
        "id": "example",
        "created_at": "2025-01-01T00:00:00Z",
        "user": null,
        "group": null,
        "role": null,
        "inheritance": null
      }
    ],
    "by_link": [
      null
    ],
    "inherited": [
      null
    ]
  },
  "owner": {
    "user": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "group": {
      "id": "example",
      "identity": null,
      "name": "example",
      "type": null,
      "metadata": null,
      "members_count": 0
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Unique page identifier |
| *page\_type* | **Type**: string  Page type  *Enum:* `page`, `grid`, `wysiwyg`, `template` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *access\_lists* | **All of 1 type** - **PageAccessListsSchema**  **Type**: [PageAccessListsSchema](en/api-ref/pages/pages__get_page_details#entity-PageAccessListsSchema)  Page access lists **Example** ```   {     "direct": [       {         "id": "example",         "created_at": "2025-01-01T00:00:00Z",         "user": {           "id": 0,           "identity": null,           "username": "example",           "display_name": "example",           "is_dismissed": true,           "affiliation": "example"         },         "group": {           "id": "example",           "identity": null,           "name": "example",           "type": null,           "metadata": null,           "members_count": 0         },         "role": "reader",         "inheritance": "inherited"       }     ],     "by_link": [       null     ],     "inherited": [       null     ]   }   ```  **Not returned by default**  Specify `access_lists` in the `?fields=access_lists, ...` list to include it in the response.  The page access lists **Example** ``` {   "direct": [     {       "id": "example",       "created_at": "2025-01-01T00:00:00Z",       "user": null,       "group": null,       "role": "reader",       "inheritance": "inherited"     }   ],   "by_link": [     null   ],   "inherited": [     null   ] } ``` |
| *access\_policy* | **All of 1 type** - **PageAccessPolicySchema**  **Type**: [PageAccessPolicySchema](en/api-ref/pages/pages__get_page_details#entity-PageAccessPolicySchema)  Page access policy **Example** ```   {     "access_type": "inherited",     "inherited_access_type": "all_staff",     "all_staff_role": "reader",     "has_external": true,     "invite": {       "status": 0     }   }   ```  **Not returned by default**  Specify `access_policy` in the `?fields=access_policy, ...` list to include it in the response.  The page access settings **Example** ``` {   "access_type": "inherited",   "inherited_access_type": "all_staff",   "all_staff_role": "reader",   "has_external": true,   "invite": {     "status": 0   } } ``` |
| *attributes* | **All of 1 type** - **PageAttributesSchema**  **Type**: [PageAttributesSchema](en/api-ref/pages/pages__get_page_details#entity-PageAttributesSchema)  Additional page attributes **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z",     "lang": "example",     "is_readonly": true,     "comments_count": 0,     "comments_enabled": true,     "keywords": [       "example"     ],     "is_collaborative": true,     "is_draft": true   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z",   "lang": "example",   "is_readonly": true,   "comments_count": 0,   "comments_enabled": true,   "keywords": [     "example"   ],   "is_collaborative": true,   "is_draft": true } ``` |
| *breadcrumbs* | **Type**: [BreadcrumbSchema](en/api-ref/pages/pages__get_page_details#entity-BreadcrumbSchema)[]  **Not returned by default**  Specify `breadcrumbs` in the `?fields=breadcrumbs, ...` list to include it in the response. **Example** ``` [   {     "id": 0,     "title": "example",     "slug": "example",     "page_exists": true   } ] ``` |
| *content* | **Type**: string  **Not returned by default**  Specify `content` in the `?fields=content, ...` list to include it in the response.  The page content as a string.  *Example:* `example` |
| *owner* | **All of 1 type** - **PageOwnerSchema**  **Type**: [PageOwnerSchema](en/api-ref/pages/pages__get_page_details#entity-PageOwnerSchema)  Page owner **Example** ```   {     "user": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": {         "src": null,         "id": "example"       },       "name": "example",       "type": "wiki",       "metadata": {         "url": "example",         "externals_count": 0       },       "members_count": 0     }   }   ```  **Not returned by default**  Specify `owner` in the `?fields=owner, ...` list to include it in the response.  The page owner **Example** ``` {   "user": {     "id": 0,     "identity": null,     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "group": {     "id": "example",     "identity": null,     "name": "example",     "type": "wiki",     "metadata": {},     "members_count": 0   } } ``` |
| *redirect* | **All of 1 type** - **RedirectSchema**  **Type**: [RedirectSchema](en/api-ref/pages/pages__get_page_details#entity-RedirectSchema)  Information about the page redirect **Example** ```   {     "page_id": 0,     "redirect_target": {       "id": 0,       "slug": "example",       "title": "example",       "page_type": "page"     }   }   ```  **Not returned by default**  Specify `redirect` in the `?fields=redirect, ...` list to include it in the response.  If no redirect is set, `null` is returned **Example** ``` {   "page_id": 0,   "redirect_target": {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   } } ``` |

### PageType

Page type:

- `page` — a regular page
- `grid` — a page with a table
- `cloud_page` — a cloud page
- `wysiwyg` — a page with the visual editor
- `template` — a page template

**Type**: string

*Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`

### PageDetailsSchema

Brief information about the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID |
| *page\_type* | **All of 1 type** - **PageType**  **Type**: [PageType](en/api-ref/pages/pages__get_page_details#entity-PageType)  Page type:    - `page` — a regular page   - `grid` — a page with a table   - `cloud_page` — a cloud page   - `wysiwyg` — a page with the visual editor   - `template` — a page template *Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`  Page type  *Example:* `page` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page"
}
```

### RedirectSchema

Information about the page redirect

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_id* | **Type**: integer  The ID of the page that the current page redirects to. |
| *redirect\_target* | **All of 1 type** - **PageDetailsSchema**  **Type**: [PageDetailsSchema](en/api-ref/pages/pages__get_page_details#entity-PageDetailsSchema)  Brief information about the page **Example** ```   {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   }   ```  For example, given a redirect chain A->B->C->D, for A, B, and C this will be page D **Example** ``` {   "id": 0,   "slug": "example",   "title": "example",   "page_type": "page" } ``` |

**Example**

```
{
  "page_id": 0,
  "redirect_target": {
    "id": 0,
    "slug": "example",
    "title": "example",
    "page_type": "page"
  }
}
```

### BreadcrumbSchema

A breadcrumb item (navigation trail)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_exists* | **Type**: boolean  Whether the page exists |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *id* | **Type**: integer  Page ID (if the page exists) |

**Example**

```
{
  "id": 0,
  "title": "example",
  "slug": "example",
  "page_exists": true
}
```

### PageAttributesSchema

Additional page attributes

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comments\_count* | **Type**: integer  Number of comments on the page |
| *comments\_enabled* | **Type**: boolean  Comments are enabled |
| *created\_at* | **Type**: string<date-time>  Date and time the page was created  *Example:* `2025-01-01T00:00:00Z` |
| *is\_readonly* | **Type**: boolean  The page is read-only |
| *lang* | **Type**: string  Page language (for example, `ru`, `en`)  *Example:* `example` |
| *modified\_at* | **Type**: string<date-time>  Date and time the page was last modified  *Example:* `2025-01-01T00:00:00Z` |
| *is\_collaborative* | **Type**: boolean  Collaborative editing is enabled |
| *is\_draft* | **Type**: boolean  The page is a draft |
| *keywords* | **Type**: string[]  Page keywords **Example** ``` [   "example" ] ``` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z",
  "lang": "example",
  "is_readonly": true,
  "comments_count": 0,
  "comments_enabled": true,
  "keywords": [
    "example"
  ],
  "is_collaborative": true,
  "is_draft": true
}
```

### PageAccessTypeAPI

Page access type:

- `inherited` — inherited from the parent page
- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `inherited`, `all_staff`, `custom`

### AccessTypeInheritedAPI

Inherited access type:

- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `all_staff`, `custom`

### RoleAllStaffAPI

Role for "all staff members" access:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`

### PageInviteStatus

Invitation link status:

- `0` — deleted
- `1` — enabled
- `2` — disabled

**Type**: integer

*Enum:* `0`, `1`, `2`

### AclPreviewInviteSchema

Information about the invitation link for page access

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **All of 1 type** - **PageInviteStatus**  **Type**: [PageInviteStatus](en/api-ref/pages/pages__get_page_details#entity-PageInviteStatus)  Invitation link status:    - `0` — deleted   - `1` — enabled   - `2` — disabled *Enum:* `0`, `1`, `2`  *Example:* `0`  Link status:   - 0 - deleted (not returned by the API) - 1 - enabled - 2 - disabled   *Example:* `0` |

**Example**

```
{
  "status": 0
}
```

### PageAccessPolicySchema

Page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__get_page_details#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__get_page_details#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access  *Example:* `reader` |
| *has\_external* | **Type**: boolean  Indicates that the page is accessible to external consultants. If None, the status is unknown |
| *inherited\_access\_type* | **All of 1 type** - **AccessTypeInheritedAPI**  **Type**: [AccessTypeInheritedAPI](en/api-ref/pages/pages__get_page_details#entity-AccessTypeInheritedAPI)  Inherited access type:    - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `all_staff`, `custom`  Inherited access type  *Example:* `all_staff` |
| *invite* | **All of 1 type** - **AclPreviewInviteSchema**  **Type**: [AclPreviewInviteSchema](en/api-ref/pages/pages__get_page_details#entity-AclPreviewInviteSchema)  Information about the invitation link for page access **Example** ```   {     "status": 0   }   ```  Information about the invitation link for page access **Example** ``` {   "status": 0 } ``` |

**Example**

```
{
  "access_type": "inherited",
  "inherited_access_type": "all_staff",
  "all_staff_role": "reader",
  "has_external": true,
  "invite": {
    "status": 0
  }
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages/pages__get_page_details#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages/pages__get_page_details#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages/pages__get_page_details#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages/pages__get_page_details#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages/pages__get_page_details#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages/pages__get_page_details#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

### PageAccessItem

A personal page access item

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages/pages__get_page_details#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__get_page_details#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages/pages__get_page_details#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__get_page_details#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

### PageAccessListsSchema

Page access lists

|  |  |
| --- | --- |
| **Name** | **Description** |
| *by\_link* | **Type**: [PageAccessItem](en/api-ref/pages/pages__get_page_details#entity-PageAccessItem)[]  Accesses via the invitation link **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *direct* | **Type**: [PageAccessItem](en/api-ref/pages/pages__get_page_details#entity-PageAccessItem)[]  Direct personal accesses to the page **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *inherited* | **Type**: [PageAccessItem](en/api-ref/pages/pages__get_page_details#entity-PageAccessItem)[]  Accesses inherited from parent pages **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |

**Example**

```
{
  "direct": [
    {
      "id": "example",
      "created_at": "2025-01-01T00:00:00Z",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "group": {
        "id": "example",
        "identity": null,
        "name": "example",
        "type": null,
        "metadata": null,
        "members_count": 0
      },
      "role": "reader",
      "inheritance": "inherited"
    }
  ],
  "by_link": [
    null
  ],
  "inherited": [
    null
  ]
}
```

### PageOwnerSchema

Page owner

|  |  |
| --- | --- |
| **Name** | **Description** |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__get_page_details#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  **(not implemented)** The group that owns the page **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__get_page_details#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who owns the page **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__update_page_details -->

- [Request](en/api-ref/pages/pages__update_page_details#request)
  - [Path parameters](en/api-ref/pages/pages__update_page_details#path-parameters)
  - [Query parameters](en/api-ref/pages/pages__update_page_details#query-parameters)
  - [Body](en/api-ref/pages/pages__update_page_details#body)
  - [PageIdentity](en/api-ref/pages/pages__update_page_details#entity-PageIdentity)
  - [RedirectUpdateSchema](en/api-ref/pages/pages__update_page_details#entity-RedirectUpdateSchema)
  - [PageAccessTypeAPI](en/api-ref/pages/pages__update_page_details#entity-PageAccessTypeAPI)
  - [RoleAllStaffAPI](en/api-ref/pages/pages__update_page_details#entity-RoleAllStaffAPI)
  - [AccessPolicyUpdateSchema](en/api-ref/pages/pages__update_page_details#entity-AccessPolicyUpdateSchema)
  - [UserIdentity](en/api-ref/pages/pages__update_page_details#entity-UserIdentity)
  - [ComSource](en/api-ref/pages/pages__update_page_details#entity-ComSource)
  - [ComIdentitySchema](en/api-ref/pages/pages__update_page_details#entity-ComIdentitySchema)
  - [UpdatePageOwnerSchema](en/api-ref/pages/pages__update_page_details#entity-UpdatePageOwnerSchema)
- [Responses](en/api-ref/pages/pages__update_page_details#responses)
- [200 OK](en/api-ref/pages/pages__update_page_details#200-ok)
  - [Body](en/api-ref/pages/pages__update_page_details#body1)
  - [PageType](en/api-ref/pages/pages__update_page_details#entity-PageType)
  - [PageDetailsSchema](en/api-ref/pages/pages__update_page_details#entity-PageDetailsSchema)
  - [RedirectSchema](en/api-ref/pages/pages__update_page_details#entity-RedirectSchema)
  - [BreadcrumbSchema](en/api-ref/pages/pages__update_page_details#entity-BreadcrumbSchema)
  - [PageAttributesSchema](en/api-ref/pages/pages__update_page_details#entity-PageAttributesSchema)
  - [AccessTypeInheritedAPI](en/api-ref/pages/pages__update_page_details#entity-AccessTypeInheritedAPI)
  - [PageInviteStatus](en/api-ref/pages/pages__update_page_details#entity-PageInviteStatus)
  - [AclPreviewInviteSchema](en/api-ref/pages/pages__update_page_details#entity-AclPreviewInviteSchema)
  - [PageAccessPolicySchema](en/api-ref/pages/pages__update_page_details#entity-PageAccessPolicySchema)
  - [UserSchema](en/api-ref/pages/pages__update_page_details#entity-UserSchema)
  - [GroupType](en/api-ref/pages/pages__update_page_details#entity-GroupType)
  - [IntranetGroupMetadata](en/api-ref/pages/pages__update_page_details#entity-IntranetGroupMetadata)
  - [IamGroupMetadata](en/api-ref/pages/pages__update_page_details#entity-IamGroupMetadata)
  - [GroupSchema](en/api-ref/pages/pages__update_page_details#entity-GroupSchema)
  - [RoleAPI](en/api-ref/pages/pages__update_page_details#entity-RoleAPI)
  - [InheritanceAPI](en/api-ref/pages/pages__update_page_details#entity-InheritanceAPI)
  - [PageAccessItem](en/api-ref/pages/pages__update_page_details#entity-PageAccessItem)
  - [PageAccessListsSchema](en/api-ref/pages/pages__update_page_details#entity-PageAccessListsSchema)
  - [PageOwnerSchema](en/api-ref/pages/pages__update_page_details#entity-PageOwnerSchema)

# Update Page

## Request

POST

```
https://api.wiki.yandex.net/v1/pages/{idx}
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *allow\_merge* | **Type**: boolean  If True, concurrent edits are merged using the 3-way merge algorithm; otherwise, a conflict is returned  *Default:* `false` |
| *fields* | **Type**: string  The additional response blocks to return in the response. See the response format description.  *Example:* `` |
| *is\_silent* | **Type**: boolean  Do not send a page update notification to subscribers  *Default:* `false` |

### Body

application/json

```
{
  "title": "example",
  "content": "example",
  "redirect": {
    "page": {
      "id": 0,
      "slug": "example"
    }
  },
  "access_policy": {
    "access_type": "inherited",
    "all_staff_role": "reader"
  },
  "owner": {
    "user": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "group": {
      "src": null,
      "id": "example"
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_policy* | **All of 1 type** - **AccessPolicyUpdateSchema**  **Type**: [AccessPolicyUpdateSchema](en/api-ref/pages/pages__update_page_details#entity-AccessPolicyUpdateSchema)  Schema for updating the page access policy **Example** ```   {     "access_type": "inherited",     "all_staff_role": "reader"   }   ```  The page access settings **Example** ``` {   "access_type": "inherited",   "all_staff_role": "reader" } ``` |
| *content* | **Type**: string  *Example:* `example` |
| *owner* | **All of 1 type** - **UpdatePageOwnerSchema**  **Type**: [UpdatePageOwnerSchema](en/api-ref/pages/pages__update_page_details#entity-UpdatePageOwnerSchema)  Schema for updating the page owner **Example** ```   {     "user": {       "uid": "example",       "cloud_uid": "example"     },     "group": {       "src": "dir",       "id": "example"     }   }   ```  The page owner **Example** ``` {   "user": {     "uid": "example",     "cloud_uid": "example"   },   "group": {     "src": "dir",     "id": "example"   } } ``` |
| *redirect* | **Type**: [RedirectUpdateSchema](en/api-ref/pages/pages__update_page_details#entity-RedirectUpdateSchema) **Example** ``` {   "page": {     "id": 0,     "slug": "example"   } } ``` |
| *title* | **Type**: string  *Min length:* `1`  *Max length:* `255`  *Example:* `example` |

### PageIdentity

Page identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID. Either `id` or `slug` is required. If both are provided, `id` takes priority and `slug` is ignored |
| *slug* | **Type**: string  Page address (slug). Either `id` or `slug` is required  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example"
}
```

### RedirectUpdateSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page* | **All of 1 type** - **PageIdentity**  **Type**: [PageIdentity](en/api-ref/pages/pages__update_page_details#entity-PageIdentity)  Page identifier **Example** ```   {     "id": 0,     "slug": "example"   }   ```  The page to redirect to. Set to `null` to remove the redirect. **Example** ``` {   "id": 0,   "slug": "example" } ``` |

**Example**

```
{
  "page": {
    "id": 0,
    "slug": "example"
  }
}
```

### PageAccessTypeAPI

Page access type:

- `inherited` — inherited from the parent page
- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `inherited`, `all_staff`, `custom`

### RoleAllStaffAPI

Role for "all staff members" access:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`

### AccessPolicyUpdateSchema

Schema for updating the page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__update_page_details#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Page access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__update_page_details#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access (temporarily, only the `editor` role is available)  *Example:* `reader` |

**Example**

```
{
  "access_type": "inherited",
  "all_staff_role": "reader"
}
```

### UserIdentity

User identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cloud\_uid* | **Type**: string  User identifier in the cloud (for the external instance)  *Example:* `example` |
| *uid* | **Type**: string  User identifier in Yandex (for the internal instance)  *Example:* `example` |

**Example**

```
{
  "uid": "example",
  "cloud_uid": "example"
}
```

### ComSource

Group identifier source:

- `dir` — IAM
- `cloud` — Yandex Cloud
- `com` — local database
- `staff` — Staff (internal employee directory)

**Type**: string

*Enum:* `dir`, `cloud`, `com`, `staff`

### ComIdentitySchema

Group identifier

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Group identifier in the specified source  *Example:* `example` |
| *src* | **All of 1 type** - **ComSource**  **Type**: [ComSource](en/api-ref/pages/pages__update_page_details#entity-ComSource)  Group identifier source:    - `dir` — IAM   - `cloud` — Yandex Cloud   - `com` — local database   - `staff` — Staff (internal employee directory) *Enum:* `dir`, `cloud`, `com`, `staff`  Identifier source  *Example:* `dir` |

**Example**

```
{
  "src": "dir",
  "id": "example"
}
```

### UpdatePageOwnerSchema

Schema for updating the page owner

|  |  |
| --- | --- |
| **Name** | **Description** |
| *group* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages/pages__update_page_details#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  The group that owns the page. Specify either `user` or `group` **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *user* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages/pages__update_page_details#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  The user who owns the page. Specify either `user` or `group` **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "user": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "group": {
    "src": "dir",
    "id": "example"
  }
}
```

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page",
  "redirect": {
    "page_id": 0,
    "redirect_target": {
      "id": 0,
      "slug": "example",
      "title": "example",
      "page_type": null
    }
  },
  "breadcrumbs": [
    {
      "id": 0,
      "title": "example",
      "slug": "example",
      "page_exists": true
    }
  ],
  "attributes": {
    "created_at": "2025-01-01T00:00:00Z",
    "modified_at": "2025-01-01T00:00:00Z",
    "lang": "example",
    "is_readonly": true,
    "comments_count": 0,
    "comments_enabled": true,
    "keywords": [
      "example"
    ],
    "is_collaborative": true,
    "is_draft": true
  },
  "content": "example",
  "access_policy": {
    "access_type": "inherited",
    "inherited_access_type": "all_staff",
    "all_staff_role": "reader",
    "has_external": true,
    "invite": {
      "status": null
    }
  },
  "access_lists": {
    "direct": [
      {
        "id": "example",
        "created_at": "2025-01-01T00:00:00Z",
        "user": null,
        "group": null,
        "role": null,
        "inheritance": null
      }
    ],
    "by_link": [
      null
    ],
    "inherited": [
      null
    ]
  },
  "owner": {
    "user": {
      "id": 0,
      "identity": null,
      "username": "example",
      "display_name": "example",
      "is_dismissed": true,
      "affiliation": "example"
    },
    "group": {
      "id": "example",
      "identity": null,
      "name": "example",
      "type": null,
      "metadata": null,
      "members_count": 0
    }
  }
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Unique page identifier |
| *page\_type* | **Type**: string  Page type  *Enum:* `page`, `grid`, `wysiwyg`, `template` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *access\_lists* | **All of 1 type** - **PageAccessListsSchema**  **Type**: [PageAccessListsSchema](en/api-ref/pages/pages__update_page_details#entity-PageAccessListsSchema)  Page access lists **Example** ```   {     "direct": [       {         "id": "example",         "created_at": "2025-01-01T00:00:00Z",         "user": {           "id": 0,           "identity": null,           "username": "example",           "display_name": "example",           "is_dismissed": true,           "affiliation": "example"         },         "group": {           "id": "example",           "identity": null,           "name": "example",           "type": null,           "metadata": null,           "members_count": 0         },         "role": "reader",         "inheritance": "inherited"       }     ],     "by_link": [       null     ],     "inherited": [       null     ]   }   ```  **Not returned by default**  Specify `access_lists` in the `?fields=access_lists, ...` list to include it in the response.  The page access lists **Example** ``` {   "direct": [     {       "id": "example",       "created_at": "2025-01-01T00:00:00Z",       "user": null,       "group": null,       "role": "reader",       "inheritance": "inherited"     }   ],   "by_link": [     null   ],   "inherited": [     null   ] } ``` |
| *access\_policy* | **All of 1 type** - **PageAccessPolicySchema**  **Type**: [PageAccessPolicySchema](en/api-ref/pages/pages__update_page_details#entity-PageAccessPolicySchema)  Page access policy **Example** ```   {     "access_type": "inherited",     "inherited_access_type": "all_staff",     "all_staff_role": "reader",     "has_external": true,     "invite": {       "status": 0     }   }   ```  **Not returned by default**  Specify `access_policy` in the `?fields=access_policy, ...` list to include it in the response.  The page access settings **Example** ``` {   "access_type": "inherited",   "inherited_access_type": "all_staff",   "all_staff_role": "reader",   "has_external": true,   "invite": {     "status": 0   } } ``` |
| *attributes* | **All of 1 type** - **PageAttributesSchema**  **Type**: [PageAttributesSchema](en/api-ref/pages/pages__update_page_details#entity-PageAttributesSchema)  Additional page attributes **Example** ```   {     "created_at": "2025-01-01T00:00:00Z",     "modified_at": "2025-01-01T00:00:00Z",     "lang": "example",     "is_readonly": true,     "comments_count": 0,     "comments_enabled": true,     "keywords": [       "example"     ],     "is_collaborative": true,     "is_draft": true   }   ```  **Not returned by default**  Specify `attributes` in the `?fields=attributes, ...` list to include it in the response. **Example** ``` {   "created_at": "2025-01-01T00:00:00Z",   "modified_at": "2025-01-01T00:00:00Z",   "lang": "example",   "is_readonly": true,   "comments_count": 0,   "comments_enabled": true,   "keywords": [     "example"   ],   "is_collaborative": true,   "is_draft": true } ``` |
| *breadcrumbs* | **Type**: [BreadcrumbSchema](en/api-ref/pages/pages__update_page_details#entity-BreadcrumbSchema)[]  **Not returned by default**  Specify `breadcrumbs` in the `?fields=breadcrumbs, ...` list to include it in the response. **Example** ``` [   {     "id": 0,     "title": "example",     "slug": "example",     "page_exists": true   } ] ``` |
| *content* | **Type**: string  **Not returned by default**  Specify `content` in the `?fields=content, ...` list to include it in the response.  The page content as a string.  *Example:* `example` |
| *owner* | **All of 1 type** - **PageOwnerSchema**  **Type**: [PageOwnerSchema](en/api-ref/pages/pages__update_page_details#entity-PageOwnerSchema)  Page owner **Example** ```   {     "user": {       "id": 0,       "identity": {         "uid": "example",         "cloud_uid": "example"       },       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": {         "src": null,         "id": "example"       },       "name": "example",       "type": "wiki",       "metadata": {         "url": "example",         "externals_count": 0       },       "members_count": 0     }   }   ```  **Not returned by default**  Specify `owner` in the `?fields=owner, ...` list to include it in the response.  The page owner **Example** ``` {   "user": {     "id": 0,     "identity": null,     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   },   "group": {     "id": "example",     "identity": null,     "name": "example",     "type": "wiki",     "metadata": {},     "members_count": 0   } } ``` |
| *redirect* | **All of 1 type** - **RedirectSchema**  **Type**: [RedirectSchema](en/api-ref/pages/pages__update_page_details#entity-RedirectSchema)  Information about the page redirect **Example** ```   {     "page_id": 0,     "redirect_target": {       "id": 0,       "slug": "example",       "title": "example",       "page_type": "page"     }   }   ```  **Not returned by default**  Specify `redirect` in the `?fields=redirect, ...` list to include it in the response.  If no redirect is set, `null` is returned **Example** ``` {   "page_id": 0,   "redirect_target": {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   } } ``` |

### PageType

Page type:

- `page` — a regular page
- `grid` — a page with a table
- `cloud_page` — a cloud page
- `wysiwyg` — a page with the visual editor
- `template` — a page template

**Type**: string

*Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`

### PageDetailsSchema

Brief information about the page

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: integer  Page ID |
| *page\_type* | **All of 1 type** - **PageType**  **Type**: [PageType](en/api-ref/pages/pages__update_page_details#entity-PageType)  Page type:    - `page` — a regular page   - `grid` — a page with a table   - `cloud_page` — a cloud page   - `wysiwyg` — a page with the visual editor   - `template` — a page template *Enum:* `page`, `grid`, `cloud_page`, `wysiwyg`, `template`  Page type  *Example:* `page` |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |

**Example**

```
{
  "id": 0,
  "slug": "example",
  "title": "example",
  "page_type": "page"
}
```

### RedirectSchema

Information about the page redirect

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_id* | **Type**: integer  The ID of the page that the current page redirects to. |
| *redirect\_target* | **All of 1 type** - **PageDetailsSchema**  **Type**: [PageDetailsSchema](en/api-ref/pages/pages__update_page_details#entity-PageDetailsSchema)  Brief information about the page **Example** ```   {     "id": 0,     "slug": "example",     "title": "example",     "page_type": "page"   }   ```  For example, given a redirect chain A->B->C->D, for A, B, and C this will be page D **Example** ``` {   "id": 0,   "slug": "example",   "title": "example",   "page_type": "page" } ``` |

**Example**

```
{
  "page_id": 0,
  "redirect_target": {
    "id": 0,
    "slug": "example",
    "title": "example",
    "page_type": "page"
  }
}
```

### BreadcrumbSchema

A breadcrumb item (navigation trail)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *page\_exists* | **Type**: boolean  Whether the page exists |
| *slug* | **Type**: string  Page address (slug)  *Example:* `example` |
| *title* | **Type**: string  Page title  *Example:* `example` |
| *id* | **Type**: integer  Page ID (if the page exists) |

**Example**

```
{
  "id": 0,
  "title": "example",
  "slug": "example",
  "page_exists": true
}
```

### PageAttributesSchema

Additional page attributes

|  |  |
| --- | --- |
| **Name** | **Description** |
| *comments\_count* | **Type**: integer  Number of comments on the page |
| *comments\_enabled* | **Type**: boolean  Comments are enabled |
| *created\_at* | **Type**: string<date-time>  Date and time the page was created  *Example:* `2025-01-01T00:00:00Z` |
| *is\_readonly* | **Type**: boolean  The page is read-only |
| *lang* | **Type**: string  Page language (for example, `ru`, `en`)  *Example:* `example` |
| *modified\_at* | **Type**: string<date-time>  Date and time the page was last modified  *Example:* `2025-01-01T00:00:00Z` |
| *is\_collaborative* | **Type**: boolean  Collaborative editing is enabled |
| *is\_draft* | **Type**: boolean  The page is a draft |
| *keywords* | **Type**: string[]  Page keywords **Example** ``` [   "example" ] ``` |

**Example**

```
{
  "created_at": "2025-01-01T00:00:00Z",
  "modified_at": "2025-01-01T00:00:00Z",
  "lang": "example",
  "is_readonly": true,
  "comments_count": 0,
  "comments_enabled": true,
  "keywords": [
    "example"
  ],
  "is_collaborative": true,
  "is_draft": true
}
```

### AccessTypeInheritedAPI

Inherited access type:

- `all_staff` — access for all staff members
- `custom` — personal accesses

**Type**: string

*Enum:* `all_staff`, `custom`

### PageInviteStatus

Invitation link status:

- `0` — deleted
- `1` — enabled
- `2` — disabled

**Type**: integer

*Enum:* `0`, `1`, `2`

### AclPreviewInviteSchema

Information about the invitation link for page access

|  |  |
| --- | --- |
| **Name** | **Description** |
| *status* | **All of 1 type** - **PageInviteStatus**  **Type**: [PageInviteStatus](en/api-ref/pages/pages__update_page_details#entity-PageInviteStatus)  Invitation link status:    - `0` — deleted   - `1` — enabled   - `2` — disabled *Enum:* `0`, `1`, `2`  *Example:* `0`  Link status:   - 0 - deleted (not returned by the API) - 1 - enabled - 2 - disabled   *Example:* `0` |

**Example**

```
{
  "status": 0
}
```

### PageAccessPolicySchema

Page access policy

|  |  |
| --- | --- |
| **Name** | **Description** |
| *access\_type* | **All of 1 type** - **PageAccessTypeAPI**  **Type**: [PageAccessTypeAPI](en/api-ref/pages/pages__update_page_details#entity-PageAccessTypeAPI)  Page access type:    - `inherited` — inherited from the parent page   - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `inherited`, `all_staff`, `custom`  Access type  *Example:* `inherited` |
| *all\_staff\_role* | **All of 1 type** - **RoleAllStaffAPI**  **Type**: [RoleAllStaffAPI](en/api-ref/pages/pages__update_page_details#entity-RoleAllStaffAPI)  Role for "all staff members" access:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management) *Enum:* `reader`, `editor`, `extra_editor`  Role for "all staff members" access  *Example:* `reader` |
| *has\_external* | **Type**: boolean  Indicates that the page is accessible to external consultants. If None, the status is unknown |
| *inherited\_access\_type* | **All of 1 type** - **AccessTypeInheritedAPI**  **Type**: [AccessTypeInheritedAPI](en/api-ref/pages/pages__update_page_details#entity-AccessTypeInheritedAPI)  Inherited access type:    - `all_staff` — access for all staff members   - `custom` — personal accesses *Enum:* `all_staff`, `custom`  Inherited access type  *Example:* `all_staff` |
| *invite* | **All of 1 type** - **AclPreviewInviteSchema**  **Type**: [AclPreviewInviteSchema](en/api-ref/pages/pages__update_page_details#entity-AclPreviewInviteSchema)  Information about the invitation link for page access **Example** ```   {     "status": 0   }   ```  Information about the invitation link for page access **Example** ``` {   "status": 0 } ``` |

**Example**

```
{
  "access_type": "inherited",
  "inherited_access_type": "all_staff",
  "all_staff_role": "reader",
  "has_external": true,
  "invite": {
    "status": 0
  }
}
```

### UserSchema

Information about the user

|  |  |
| --- | --- |
| **Name** | **Description** |
| *affiliation* | **Type**: string  User affiliation (for example, `yandex`, `external`)  *Example:* `example` |
| *display\_name* | **Type**: string  User display name  *Example:* `example` |
| *id* | **Type**: integer  Internal user identifier |
| *is\_dismissed* | **Type**: boolean  The user has been dismissed |
| *username* | **Type**: string  User login  *Example:* `example` |
| *identity* | **All of 1 type** - **UserIdentity**  **Type**: [UserIdentity](en/api-ref/pages/pages__update_page_details#entity-UserIdentity)  User identifier **Example** ```   {     "uid": "example",     "cloud_uid": "example"   }   ```  User identifier in the system **Example** ``` {   "uid": "example",   "cloud_uid": "example" } ``` |

**Example**

```
{
  "id": 0,
  "identity": {
    "uid": "example",
    "cloud_uid": "example"
  },
  "username": "example",
  "display_name": "example",
  "is_dismissed": true,
  "affiliation": "example"
}
```

### GroupType

Group type:

- `wiki` — a Wiki group
- `service` — a service group
- `servicerole` — a service role
- `group` — a regular group
- `department` — a department

**Type**: string

*Enum:* `wiki`, `service`, `servicerole`, `group`, `department`

### IntranetGroupMetadata

Group metadata from the internal directory

|  |  |
| --- | --- |
| **Name** | **Description** |
| *externals\_count* | **Type**: integer  Number of external consultants in the group |
| *url* | **Type**: string  Group URL in the directory  *Example:* `example` |

**Example**

```
{
  "url": "example",
  "externals_count": 0
}
```

### IamGroupMetadata

Group metadata from IAM (Identity and Access Management)

|  |  |
| --- | --- |
| **Name** | **Description** |
| *dir\_id* | **Type**: string  Directory identifier  *Example:* `example` |

**Example**

```
{
  "dir_id": "example"
}
```

### GroupSchema

Information about the group

|  |  |
| --- | --- |
| **Name** | **Description** |
| *identity* | **All of 1 type** - **ComIdentitySchema**  **Type**: [ComIdentitySchema](en/api-ref/pages/pages__update_page_details#entity-ComIdentitySchema)  Group identifier **Example** ```   {     "src": "dir",     "id": "example"   }   ```  Group identifier in the system **Example** ``` {   "src": "dir",   "id": "example" } ``` |
| *name* | **Type**: string  Group name  *Example:* `example` |
| *type* | **All of 1 type** - **GroupType**  **Type**: [GroupType](en/api-ref/pages/pages__update_page_details#entity-GroupType)  Group type:    - `wiki` — a Wiki group   - `service` — a service group   - `servicerole` — a service role   - `group` — a regular group   - `department` — a department *Enum:* `wiki`, `service`, `servicerole`, `group`, `department`  Group type  *Example:* `wiki` |
| *id* | **Type**: string  Group identifier. For the external instance, dir\_id; for the internal instance, staff\_id  *Example:* `example` |
| *members\_count* | **Type**: integer  Number of group members  *Default:* `0` |
| *metadata* | **Any of 2 types** - **IntranetGroupMetadata**  **Type**: [IntranetGroupMetadata](en/api-ref/pages/pages__update_page_details#entity-IntranetGroupMetadata)  Group metadata from the internal directory **Example** ```   {     "url": "example",     "externals_count": 0   }   ``` - **IamGroupMetadata**  **Type**: [IamGroupMetadata](en/api-ref/pages/pages__update_page_details#entity-IamGroupMetadata)  Group metadata from IAM (Identity and Access Management) **Example** ```   {     "dir_id": "example"   }   ```  Additional group metadata **Example** ``` {   "url": "example",   "externals_count": 0 } ``` |

**Example**

```
{
  "id": "example",
  "identity": {
    "src": "dir",
    "id": "example"
  },
  "name": "example",
  "type": "wiki",
  "metadata": {
    "url": "example",
    "externals_count": 0
  },
  "members_count": 0
}
```

### RoleAPI

Page access role:

- `reader` — read
- `editor` — edit
- `extra_editor` — extended editing (access management)
- `author` — author (full access)

**Type**: string

*Enum:* `reader`, `editor`, `extra_editor`, `author`

### InheritanceAPI

Access inheritance for subpages:

- `inherited` — access is inherited by subpages
- `not_inherited` — access is not inherited by subpages

**Type**: string

*Enum:* `inherited`, `not_inherited`

### PageAccessItem

A personal page access item

|  |  |
| --- | --- |
| **Name** | **Description** |
| *id* | **Type**: string  Unique access identifier  *Example:* `example` |
| *role* | **All of 1 type** - **RoleAPI**  **Type**: [RoleAPI](en/api-ref/pages/pages__update_page_details#entity-RoleAPI)  Page access role:    - `reader` — read   - `editor` — edit   - `extra_editor` — extended editing (access management)   - `author` — author (full access) *Enum:* `reader`, `editor`, `extra_editor`, `author`  Access role  *Example:* `reader` |
| *created\_at* | **Type**: string<date-time>  Date and time the access was created  *Example:* `2025-01-01T00:00:00Z` |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__update_page_details#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  The group the access is granted to (populated if the access is granted to a group) **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *inheritance* | **All of 1 type** - **InheritanceAPI**  **Type**: [InheritanceAPI](en/api-ref/pages/pages__update_page_details#entity-InheritanceAPI)  Access inheritance for subpages:    - `inherited` — access is inherited by subpages   - `not_inherited` — access is not inherited by subpages *Enum:* `inherited`, `not_inherited`  Access inheritance setting for subpages  *Example:* `inherited` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__update_page_details#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user the access is granted to (populated if the access is granted to a user) **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "id": "example",
  "created_at": "2025-01-01T00:00:00Z",
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  },
  "role": "reader",
  "inheritance": "inherited"
}
```

### PageAccessListsSchema

Page access lists

|  |  |
| --- | --- |
| **Name** | **Description** |
| *by\_link* | **Type**: [PageAccessItem](en/api-ref/pages/pages__update_page_details#entity-PageAccessItem)[]  Accesses via the invitation link **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *direct* | **Type**: [PageAccessItem](en/api-ref/pages/pages__update_page_details#entity-PageAccessItem)[]  Direct personal accesses to the page **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |
| *inherited* | **Type**: [PageAccessItem](en/api-ref/pages/pages__update_page_details#entity-PageAccessItem)[]  Accesses inherited from parent pages **Example** ``` [   {     "id": "example",     "created_at": "2025-01-01T00:00:00Z",     "user": {       "id": 0,       "identity": null,       "username": "example",       "display_name": "example",       "is_dismissed": true,       "affiliation": "example"     },     "group": {       "id": "example",       "identity": null,       "name": "example",       "type": "wiki",       "metadata": {},       "members_count": 0     },     "role": "reader",     "inheritance": "inherited"   } ] ``` |

**Example**

```
{
  "direct": [
    {
      "id": "example",
      "created_at": "2025-01-01T00:00:00Z",
      "user": {
        "id": 0,
        "identity": null,
        "username": "example",
        "display_name": "example",
        "is_dismissed": true,
        "affiliation": "example"
      },
      "group": {
        "id": "example",
        "identity": null,
        "name": "example",
        "type": null,
        "metadata": null,
        "members_count": 0
      },
      "role": "reader",
      "inheritance": "inherited"
    }
  ],
  "by_link": [
    null
  ],
  "inherited": [
    null
  ]
}
```

### PageOwnerSchema

Page owner

|  |  |
| --- | --- |
| **Name** | **Description** |
| *group* | **All of 1 type** - **GroupSchema**  **Type**: [GroupSchema](en/api-ref/pages/pages__update_page_details#entity-GroupSchema)  Information about the group **Example** ```   {     "id": "example",     "identity": {       "src": "dir",       "id": "example"     },     "name": "example",     "type": "wiki",     "metadata": {       "url": "example",       "externals_count": 0     },     "members_count": 0   }   ```  **(not implemented)** The group that owns the page **Example** ``` {   "id": "example",   "identity": {     "src": "dir",     "id": "example"   },   "name": "example",   "type": "wiki",   "metadata": {     "url": "example",     "externals_count": 0   },   "members_count": 0 } ``` |
| *user* | **All of 1 type** - **UserSchema**  **Type**: [UserSchema](en/api-ref/pages/pages__update_page_details#entity-UserSchema)  Information about the user **Example** ```   {     "id": 0,     "identity": {       "uid": "example",       "cloud_uid": "example"     },     "username": "example",     "display_name": "example",     "is_dismissed": true,     "affiliation": "example"   }   ```  The user who owns the page **Example** ``` {   "id": 0,   "identity": {     "uid": "example",     "cloud_uid": "example"   },   "username": "example",   "display_name": "example",   "is_dismissed": true,   "affiliation": "example" } ``` |

**Example**

```
{
  "user": {
    "id": 0,
    "identity": {
      "uid": "example",
      "cloud_uid": "example"
    },
    "username": "example",
    "display_name": "example",
    "is_dismissed": true,
    "affiliation": "example"
  },
  "group": {
    "id": "example",
    "identity": {
      "src": null,
      "id": "example"
    },
    "name": "example",
    "type": "wiki",
    "metadata": {
      "url": "example",
      "externals_count": 0
    },
    "members_count": 0
  }
}
```


---

<!-- source: https://yandex.ru/support/wiki/en/api-ref/pages/pages__page_grids -->

- [Request](en/api-ref/pages/pages__page_grids#request)
  - [Path parameters](en/api-ref/pages/pages__page_grids#path-parameters)
  - [Query parameters](en/api-ref/pages/pages__page_grids#query-parameters)
- [Responses](en/api-ref/pages/pages__page_grids#responses)
- [200 OK](en/api-ref/pages/pages__page_grids#200-ok)
  - [Body](en/api-ref/pages/pages__page_grids#body)
  - [PageGridsSchema](en/api-ref/pages/pages__page_grids#entity-PageGridsSchema)

# Page Grids

Returns the list of dynamic tables attached to the page

## Request

GET

```
https://api.wiki.yandex.net/v1/pages/{idx}/grids
```

### Path parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *idx* | **Type**: integer |

### Query parameters

|  |  |
| --- | --- |
| **Name** | **Description** |
| *cursor* | **Type**: string  *Example:* `` |
| *order\_by* | **Type**: string  If specified, sort the results by this field in the `direction` direction  *Enum:* `title`, `created_at` |
| *order\_direction* | **All of**: OrderDirection - **OrderDirection**  **Type**: string  An enumeration.  *Enum:* `asc`, `desc`  If the `order_by` field is specified, the sort direction  *Default:* `asc`  *Example:* `` |
| *page\_id* | **Type**: integer  `legacy` Page number in the result set  *Default:* `1`  *Min value:* `1` |
| *page\_size* | **Type**: integer  Number of results per page.  *Default:* `50`  *Min value:* `1`  *Max value:* `100` |

## Responses

## 200 OK

OK

### Body

application/json

```
{
  "results": [
    {
      "id": "example",
      "title": "example",
      "created_at": "2025-01-01T00:00:00Z"
    }
  ],
  "next_cursor": "example",
  "prev_cursor": "example",
  "has_next": true,
  "page_id": 0
}
```

|  |  |
| --- | --- |
| **Name** | **Description** |
| *has\_next* | **Type**: boolean  For backward compatibility: if a cursor is set, check `..._cursor` instead |
| *page\_id* | **Type**: integer  For backward compatibility: always equals 1 when a cursor is set |
| *results* | **Type**: [PageGridsSchema](en/api-ref/pages/pages__page_grids#entity-PageGridsSchema)[] **Example** ``` [   {     "id": "example",     "title": "example",     "created_at": "2025-01-01T00:00:00Z"   } ] ``` |
| *next\_cursor* | **Type**: string  *Example:* `example` |
| *prev\_cursor* | **Type**: string  *Example:* `example` |

### PageGridsSchema

|  |  |
| --- | --- |
| **Name** | **Description** |
| *created\_at* | **Type**: string<date-time>  *Example:* `2025-01-01T00:00:00Z` |
| *id* | **Type**: string<uuid4>  *Example:* `example` |
| *title* | **Type**: string  *Example:* `example` |

**Example**

```
{
  "id": "example",
  "title": "example",
  "created_at": "2025-01-01T00:00:00Z"
}
```

# -*- coding: utf-8 -*-
"""Настройка логирования.

Требование ТЗ: подробный консольный лог на каждый запуск — для каждой
успешной и неуспешной операции по каждому пользователю с указанием этапа
и правила, по которому принято решение о выдаче.
"""

import logging
import os
import sys
from datetime import datetime

_LOG_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(message)s"
)
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Каталог для датированных лог-файлов. Создаётся при необходимости, чтобы
# логирование в файл не падало из-за отсутствия директории.
_LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")


def _file_handler() -> logging.FileHandler:
    """Вернуть FileHandler в датированный лог-файл.

    Лог пишется в файл, а не только в консоль, поэтому при внезапном
    обрыве или падении скрипта лог не теряется: FileHandler держит файл
    открытым и сохраняет все записи на диске.
    """
    os.makedirs(_LOG_DIR, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    path = os.path.join(_LOG_DIR, f"tracker-{today}.log")
    return logging.FileHandler(path, encoding="utf-8")


def setup_logging(level=logging.INFO):
    logger = logging.getLogger("tracker_permissions")
    if logger.handlers:
        return logger
    logger.setLevel(level)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT))
    logger.addHandler(stream)
    logger.addHandler(_file_handler())
    logger.propagate = False
    return logger


log = setup_logging()